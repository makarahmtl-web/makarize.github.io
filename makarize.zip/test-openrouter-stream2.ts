import { OpenRouter } from '@openrouter/sdk';

async function run() {
  const client = new OpenRouter({ apiKey: process.env.OPENROUTER_API_KEY || 'sk-or-v1-fake' });
  try {
    const result = await client.chat.send({
      chatRequest: {
        model: 'openai/gpt-3.5-turbo',
        messages: [{ role: 'user', content: 'hi' }],
        stream: true,
      }
    });
    console.log(result.constructor.name);
    // Is it an async iterator?
    if (Symbol.asyncIterator in result) {
       console.log('Async Iterator!');
    }
  } catch (e) {
    console.log(e);
  }
}
run();
