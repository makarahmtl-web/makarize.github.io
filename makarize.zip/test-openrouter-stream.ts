import { OpenRouter } from '@openrouter/sdk';

async function run() {
  const client = new OpenRouter({ apiKey: 'fake' });
  const result = await client.chat.send({
    chatRequest: {
      model: 'openai/gpt-3.5-turbo',
      messages: [{ role: 'user', content: 'hi' }],
      stream: true,
    }
  });
  console.log(result.constructor.name, Object.keys(result));
}
run();
