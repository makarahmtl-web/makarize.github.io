import { OpenRouter } from '@openrouter/sdk';
const client = new OpenRouter({ apiKey: 'fake' });
console.log(Object.keys(client));
console.log(client.chat ? Object.keys(client.chat) : 'no chat');
