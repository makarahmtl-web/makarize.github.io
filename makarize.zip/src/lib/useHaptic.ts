import { useCallback } from 'react';

export type HapticPatternType =
  | 'light'
  | 'medium'
  | 'heavy'
  | 'success'
  | 'warning'
  | 'error'
  | 'selection'
  | 'sheetOpen'
  | 'sheetClose';

const HAPTIC_PATTERNS: Record<HapticPatternType, number | number[]> = {
  light: 12,
  selection: 8,
  medium: 25,
  heavy: 45,
  sheetOpen: [15, 40, 20],
  sheetClose: 18,
  success: [15, 60, 25],
  warning: [30, 50, 30],
  error: [40, 60, 40, 60, 45],
};

/**
 * Custom React hook for triggering browser haptic feedback (navigator.vibrate).
 * Safely guards against environments without vibration API support.
 */
export function useHaptic(enabled = true) {
  const trigger = useCallback(
    (type: HapticPatternType | number | number[] = 'medium') => {
      if (!enabled) return false;

      if (typeof window === 'undefined' || !('navigator' in window) || !navigator.vibrate) {
        return false;
      }

      try {
        let pattern: number | number[];
        if (typeof type === 'string') {
          pattern = HAPTIC_PATTERNS[type] ?? 20;
        } else {
          pattern = type;
        }

        return navigator.vibrate(pattern);
      } catch (err) {
        // Silently catch any browser permission restrictions
        return false;
      }
    },
    [enabled]
  );

  const triggerLight = useCallback(() => trigger('light'), [trigger]);
  const triggerSelection = useCallback(() => trigger('selection'), [trigger]);
  const triggerMedium = useCallback(() => trigger('medium'), [trigger]);
  const triggerHeavy = useCallback(() => trigger('heavy'), [trigger]);
  const triggerSuccess = useCallback(() => trigger('success'), [trigger]);
  const triggerWarning = useCallback(() => trigger('warning'), [trigger]);
  const triggerError = useCallback(() => trigger('error'), [trigger]);
  const triggerSheetOpen = useCallback(() => trigger('sheetOpen'), [trigger]);
  const triggerSheetClose = useCallback(() => trigger('sheetClose'), [trigger]);

  /**
   * Helper to wrap click handlers with automatic haptic feedback.
   */
  const withHaptic = useCallback(
    <E extends React.SyntheticEvent | Event>(
      handler?: (e: E) => void,
      type: HapticPatternType | number | number[] = 'medium'
    ) => {
      return (e: E) => {
        trigger(type);
        if (handler) {
          handler(e);
        }
      };
    },
    [trigger]
  );

  return {
    trigger,
    triggerLight,
    triggerSelection,
    triggerMedium,
    triggerHeavy,
    triggerSuccess,
    triggerWarning,
    triggerError,
    triggerSheetOpen,
    triggerSheetClose,
    withHaptic,
    isSupported: typeof window !== 'undefined' && 'navigator' in window && !!navigator.vibrate,
  };
}

export default useHaptic;
