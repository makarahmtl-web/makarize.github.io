import { motion, AnimatePresence } from 'motion/react';
import { X, FileText, FileCode, FileSpreadsheet, Film, Music, File as FileIcon } from 'lucide-react';
import { Attachment } from '../types';
import { formatBytes, getFileExtension } from '../lib/fileUtils';

interface AttachmentPreviewProps {
  attachments: Attachment[];
  onRemove: (id: string) => void;
  className?: string;
}

export default function AttachmentPreview({ attachments, onRemove, className = '' }: AttachmentPreviewProps) {
  if (attachments.length === 0) return null;

  const renderIcon = (att: Attachment) => {
    switch (att.typeCategory) {
      case 'pdf':
        return <FileText className="text-[#ea4335]" size={22} />;
      case 'code':
        return <FileCode className="text-[#34a853]" size={22} />;
      case 'document':
        if (att.name.endsWith('.csv') || att.name.endsWith('.xlsx') || att.name.endsWith('.xls')) {
          return <FileSpreadsheet className="text-[#34a853]" size={22} />;
        }
        return <FileText className="text-[#4285f4]" size={22} />;
      case 'video':
        return <Film className="text-[#9b72cb]" size={22} />;
      case 'audio':
        return <Music className="text-[#fbbc04]" size={22} />;
      default:
        return <FileIcon className="text-[#8e918f]" size={22} />;
    }
  };

  const getBadgeColor = (att: Attachment) => {
    switch (att.typeCategory) {
      case 'pdf':
        return 'bg-[#ea4335]/20 text-[#ea4335] border-[#ea4335]/30';
      case 'code':
        return 'bg-[#34a853]/20 text-[#34a853] border-[#34a853]/30';
      case 'document':
        return 'bg-[#4285f4]/20 text-[#4285f4] border-[#4285f4]/30';
      case 'video':
        return 'bg-[#9b72cb]/20 text-[#9b72cb] border-[#9b72cb]/30';
      case 'audio':
        return 'bg-[#fbbc04]/20 text-[#fbbc04] border-[#fbbc04]/30';
      default:
        return 'bg-white/10 text-[#e3e3e3] border-white/10';
    }
  };

  return (
    <div className={`mb-3 flex flex-wrap gap-2.5 px-4 sm:px-6 ${className}`}>
      <AnimatePresence mode="popLayout">
        {attachments.map((att) => (
          <motion.div
            key={att.id}
            layout
            initial={{ opacity: 0, scale: 0.85, y: 6 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.15 } }}
            className="group relative flex items-center gap-3 overflow-hidden rounded-2xl border border-[#3c4043] bg-[#1e1f20] p-2 pr-3 shadow-lg transition-colors hover:border-[#5f6368] hover:bg-[#28292a]"
          >
            {/* Image Preview */}
            {att.typeCategory === 'image' ? (
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-[#131314]">
                <img
                  src={att.previewUrl}
                  alt={att.name}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute bottom-1 left-1 rounded bg-black/70 px-1 py-0.5 text-[9px] font-semibold text-white/90 uppercase backdrop-blur-sm">
                  {getFileExtension(att.name)}
                </div>
              </div>
            ) : (
              /* Non-Image File Icon Card */
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-[#131314]/80 p-2">
                {renderIcon(att)}
              </div>
            )}

            {/* File Info */}
            <div className="flex min-w-0 max-w-[160px] sm:max-w-[200px] flex-col justify-center">
              <span className="truncate text-xs font-medium text-[#e3e3e3]" title={att.name}>
                {att.name}
              </span>
              <div className="mt-1 flex items-center gap-1.5">
                <span
                  className={`inline-flex items-center rounded border px-1.5 py-0.2 text-[10px] font-bold uppercase ${getBadgeColor(
                    att
                  )}`}
                >
                  {getFileExtension(att.name)}
                </span>
                <span className="text-[11px] text-[#8e918f]">{formatBytes(att.size)}</span>
              </div>
            </div>

            {/* Remove Attachment Button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onRemove(att.id);
              }}
              title="Remove attachment"
              className="ml-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#3c4043] text-[#c4c7c5] opacity-80 transition-all hover:bg-[#ea4335] hover:text-white hover:opacity-100 group-hover:opacity-100"
            >
              <X size={13} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
