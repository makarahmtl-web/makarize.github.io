import React from 'react';

interface MakarizeLogoProps {
  className?: string;
  size?: number;
}

export default function MakarizeLogo({ className = '', size = 32 }: MakarizeLogoProps) {
  return (
    <div
      className={`relative flex items-center justify-center shrink-0 select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 100 100"
        width={size}
        height={size}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-md"
      >
        <defs>
          {/* Back bubble gradient (Deep Violet/Purple) */}
          <linearGradient id="makarizeBackGrad" x1="10%" y1="10%" x2="90%" y2="90%">
            <stop offset="0%" stopColor="#9333ea" />
            <stop offset="50%" stopColor="#7e22ce" />
            <stop offset="100%" stopColor="#581c87" />
          </linearGradient>

          {/* Front bubble gradient (Vibrant Lilac / Lavender Frosted Glass) */}
          <linearGradient id="makarizeFrontGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#d8b4fe" stopOpacity="0.95" />
            <stop offset="40%" stopColor="#c084fc" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#a855f7" stopOpacity="0.85" />
          </linearGradient>

          {/* Gloss highlight */}
          <linearGradient id="makarizeGloss" x1="20%" y1="0%" x2="80%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
            <stop offset="60%" stopColor="#ffffff" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </linearGradient>

          {/* Drop shadow filter */}
          <filter id="makarizeShadow" x="-10%" y="-10%" width="130%" height="130%">
            <feDropShadow dx="2" dy="4" stdDeviation="4" floodColor="#3b0764" floodOpacity="0.4" />
          </filter>
        </defs>

        {/* Back Bubble */}
        <g filter="url(#makarizeShadow)">
          <path
            d="M 22 18 C 12 18 6 25 6 36 L 6 56 C 6 67 13 74 24 74 L 24 86 C 24 88 27 90 29 88 L 41 74 L 62 74 C 73 74 80 67 80 56 L 80 36 C 80 25 73 18 62 18 Z"
            fill="url(#makarizeBackGrad)"
          />
        </g>

        {/* Front Bubble (Overlapping Frosted Glass Bubble) */}
        <g filter="url(#makarizeShadow)">
          <path
            d="M 38 32 C 28 32 22 38 22 48 L 22 66 C 22 76 29 82 40 82 L 64 82 L 76 93 C 78 95 81 93 81 91 L 81 82 C 90 82 96 76 96 66 L 96 48 C 96 38 89 32 78 32 Z"
            fill="url(#makarizeFrontGrad)"
          />
          {/* Glass Rim Highlight */}
          <path
            d="M 38 33 C 29 33 23.5 38.5 23.5 48 L 23.5 66 C 23.5 75 29.5 80.5 40 80.5 L 64 80.5 L 76 91.5 C 77 92.5 79.5 91.5 79.5 90 L 79.5 80.5 C 89 80.5 94.5 75 94.5 66 L 94.5 48 C 94.5 38.5 88 33 78 33 Z"
            stroke="url(#makarizeGloss)"
            strokeWidth="1.5"
            fill="none"
          />
        </g>

        {/* Three white dots on front bubble */}
        <circle cx="48" cy="57" r="4.5" fill="#ffffff" />
        <circle cx="60" cy="57" r="4.5" fill="#ffffff" />
        <circle cx="72" cy="57" r="4.5" fill="#ffffff" />
      </svg>
    </div>
  );
}
