import { useState, useEffect } from 'react';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export default function ApiSettings() {
  const [apiKeys, setApiKeys] = useState({ geminiApiKey: '', groqApiKey: '', openRouterApiKey: '' });
  const [savingKeys, setSavingKeys] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    try {
      const storedKeys = localStorage.getItem('makarize_user_api_keys');
      if (storedKeys) {
        setApiKeys(JSON.parse(storedKeys));
      }
    } catch (err) {
      console.warn('Could not load api keys from local storage:', err);
    }
  }, []);

  const handleSave = () => {
    setSavingKeys(true);
    setSaveSuccess(false);
    try {
      localStorage.setItem('makarize_user_api_keys', JSON.stringify(apiKeys));
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      console.error('Failed to save API keys:', err);
      alert('Failed to save keys: ' + err.message);
    } finally {
      setSavingKeys(false);
    }
  };

  const getStatus = (keyType: string, value: string) => {
    if (!value) return null;
    if (keyType === 'geminiApiKey' && value.startsWith('AIza')) return 'valid';
    if (keyType === 'groqApiKey' && value.startsWith('gsk_')) return 'valid';
    if (keyType === 'openRouterApiKey' && value.startsWith('sk-or-v1-')) return 'valid';
    return 'unknown';
  };

  return (
    <div className="flex flex-col gap-4">
      <p className="text-xs text-[#8e918f] leading-relaxed">
        Securely configure your own API keys for active models to bypass rate limits. These are stored securely in your browser's local storage and are never saved to our database.
      </p>
      
      <div className="flex flex-col gap-4">
        {[
          { key: 'geminiApiKey', name: 'Gemini API Key', placeholder: 'AIzaSy...' },
          { key: 'groqApiKey', name: 'Groq API Key', placeholder: 'gsk_...' },
          { key: 'openRouterApiKey', name: 'OpenRouter API Key', placeholder: 'sk-or-v1-...' },
        ].map((k) => {
          const value = (apiKeys as any)[k.key] || '';
          const status = getStatus(k.key, value);
          
          return (
            <div key={k.key} className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-[#e3e3e3]">{k.name}</label>
                {status === 'valid' && (
                  <div className="flex items-center gap-1 text-[10px] text-[#34a853]">
                    <CheckCircle2 size={12} />
                    <span className="uppercase tracking-wider font-semibold">Valid Format</span>
                  </div>
                )}
              </div>
              <div className="relative">
                <input
                  type="password"
                  value={value}
                  onChange={(e) => setApiKeys({ ...apiKeys, [k.key]: e.target.value })}
                  className="w-full rounded-xl border border-[#3c4043] bg-[#18191a] p-3 text-sm text-[#e3e3e3] focus:border-[#9333ea] focus:outline-none focus:ring-1 focus:ring-[#9333ea]"
                  placeholder={`Enter your ${k.name}`}
                />
              </div>
            </div>
          );
        })}
        
        <button
          type="button"
          onClick={handleSave}
          className="mt-2 w-full rounded-xl bg-[#9333ea] px-4 py-3 text-xs font-semibold text-white transition-all hover:bg-[#7e22ce] flex items-center justify-center gap-2"
        >
          {savingKeys ? 'Saving...' : saveSuccess ? (
            <>
              <CheckCircle2 size={16} />
              Keys Saved Successfully!
            </>
          ) : (
            'Save API Keys'
          )}
        </button>
      </div>
    </div>
  );
}
