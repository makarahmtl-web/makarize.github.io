import React, { useState } from 'react';
import {
  Presentation,
  LayoutTemplate,
  Sparkles,
  Layers,
  Palette,
  Check,
  Send,
  FileText,
  Briefcase,
  GraduationCap,
  Code2,
  Zap,
  Flame,
  Globe,
  SlidersHorizontal,
  ChevronRight,
  BookOpen,
  PieChart,
  Lightbulb,
} from 'lucide-react';
import BottomSheet from './BottomSheet';
import { cn } from '../lib/utils';
import { useHaptic } from '../lib/useHaptic';

export interface SlideStyleOption {
  id: string;
  name: string;
  nameKhmer: string;
  category: 'business' | 'creative' | 'educational' | 'technical' | 'minimal';
  icon: React.ReactNode;
  tagline: string;
  taglineKhmer: string;
  structure: string[];
  recommendedSlides: number;
  badge: string;
  badgeColor: string;
}

export interface SlideThemeOption {
  id: string;
  name: string;
  nameKhmer: string;
  previewColor: string;
  accentColor: string;
  bgDesc: string;
  fontPairing: string;
}

export interface SlideFormatOption {
  id: 'markdown' | 'outline' | 'html' | 'vba_powerpoint';
  label: string;
  labelKhmer: string;
  description: string;
}

export const SLIDE_STYLES: SlideStyleOption[] = [
  {
    id: 'pitch_deck',
    name: 'Executive Pitch Deck',
    nameKhmer: 'ស្តាយ Pitch Deck វិនិយោគ & Startup',
    category: 'business',
    icon: <Briefcase size={20} className="text-amber-400" />,
    tagline: 'High-conviction investor presentation structured for funding and venture capital',
    taglineKhmer: 'រចនាសម្ព័ន្ធទាក់ទាញវិនិយោគិន៖ បញ្ហា, ដំណោះស្រាយ, ទីផ្សារ, ម៉ូដែលអាជីវកម្ម & ថវិកា',
    structure: [
      'Slide 1: Hook & Vision Statement',
      'Slide 2: The Core Problem & Market Pain',
      'Slide 3: Value Proposition & Product Solution',
      'Slide 4: Total Addressable Market (TAM/SAM/SOM)',
      'Slide 5: Business Model & Monetization',
      'Slide 6: Traction, Metrics & Growth Milestones',
      'Slide 7: Competitive Moat & Advantage',
      'Slide 8: The Ask & Capital Allocation',
    ],
    recommendedSlides: 8,
    badge: 'Investor Ready',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
  },
  {
    id: 'strategy_report',
    name: 'Business Strategy & Quarterly Review',
    nameKhmer: 'របាយការណ៍យុទ្ធសាស្ត្រ & ទិន្នន័យអាជីវកម្ម',
    category: 'business',
    icon: <PieChart size={20} className="text-blue-400" />,
    tagline: 'Executive summary, KPI breakdown, financial analysis, and strategic roadmap',
    taglineKhmer: 'សង្ខេបប្រតិបត្តិការ, សូចនាករ KPI, ការវិភាគ SWOT & ផែនទីបង្ហាញផ្លូវទៅមុខ',
    structure: [
      'Slide 1: Executive Summary & Highlights',
      'Slide 2: Strategic Goals vs Actual Performance',
      'Slide 3: Core KPI Dashboard & Metrics',
      'Slide 4: Market Dynamics & SWOT Analysis',
      'Slide 5: Departmental Operational Review',
      'Slide 6: Risk Assessment & Mitigation',
      'Slide 7: 90-Day Execution Roadmap',
    ],
    recommendedSlides: 7,
    badge: 'Corporate',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  },
  {
    id: 'educational_lecture',
    name: 'Academic Lecture & Workshop',
    nameKhmer: 'បង្រៀន, សិក្ខាសាលា & ការបណ្តុះបណ្តាល',
    category: 'educational',
    icon: <GraduationCap size={20} className="text-emerald-400" />,
    tagline: 'Pedagogical structure with learning objectives, step-by-step theory, and quizzes',
    taglineKhmer: 'គោលបំណងមេរៀន, ទ្រឹស្តីជាជំហានៗ, ឧទាហរណ៍ជាក់ស្តែង & សំណួរបញ្ជាក់ការយល់ដឹង',
    structure: [
      'Slide 1: Topic Overview & Learning Objectives',
      'Slide 2: Foundation & Background Context',
      'Slide 3: Core Concept 1: Framework & Principles',
      'Slide 4: Core Concept 2: Detailed Mechanism',
      'Slide 5: Practical Real-World Case Study',
      'Slide 6: Common Pitfalls & Best Practices',
      'Slide 7: Summary & Interactive Quiz/Q&A',
    ],
    recommendedSlides: 7,
    badge: 'Education',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  },
  {
    id: 'product_launch',
    name: 'Creative Storytelling & Product Launch',
    nameKhmer: 'ការរៀបរាប់ដំណើររឿង & សម្ពោធផលិតផល',
    category: 'creative',
    icon: <Sparkles size={20} className="text-purple-400" />,
    tagline: 'Emotional narrative hook, bold feature reveals, social proof, and vibrant CTA',
    taglineKhmer: 'ទាក់ទាញអារម្មណ៍, បង្ហាញមុខងារពិសេសថ្មីៗ, ការបញ្ជាក់ពីអ្នកប្រើប្រាស់ & CTA',
    structure: [
      'Slide 1: The Emotional Narrative Hook',
      'Slide 2: Yesterday vs Tomorrow (The Shift)',
      'Slide 3: Introducing The Flagship Innovation',
      'Slide 4: Feature Deep-Dive & Magic Moments',
      'Slide 5: Customer Testimonials & Social Proof',
      'Slide 6: Pricing, Packaging & Availability',
      'Slide 7: Call to Action & Getting Started',
    ],
    recommendedSlides: 7,
    badge: 'Storytelling',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  },
  {
    id: 'tech_architecture',
    name: 'Technical Architecture & System Design',
    nameKhmer: 'ស្ថាបត្យកម្មបច្ចេកវិទ្យា & IT System Design',
    category: 'technical',
    icon: <Code2 size={20} className="text-cyan-400" />,
    tagline: 'Engineered for developers: architecture diagrams, API flows, scalability and security',
    taglineKhmer: 'សម្រាប់វិស្វករ៖ គំនូសបំព្រួញប្រព័ន្ធ, លំហូរទិន្នន័យ API, សុវត្ថិភាព & Scalability',
    structure: [
      'Slide 1: High-Level Architecture Overview',
      'Slide 2: Tech Stack & Service Decomposition',
      'Slide 3: Data Flow & Event Pipelines',
      'Slide 4: Database Schema & Storage Layer',
      'Slide 5: Security, Auth & RBAC Boundaries',
      'Slide 6: Performance, Benchmarks & SLA',
      'Slide 7: Deployment & CI/CD Topology',
    ],
    recommendedSlides: 7,
    badge: 'Engineering',
    badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
  },
  {
    id: 'keynote_minimal',
    name: 'Minimalist Keynote (TED Style)',
    nameKhmer: 'Keynote បែបសាមញ្ញ មានឥទ្ធិពលខ្លាំង (TED Style)',
    category: 'minimal',
    icon: <Zap size={20} className="text-rose-400" />,
    tagline: 'One big memorable idea per slide, oversized typography, zero clutter, powerful punchlines',
    taglineKhmer: '១ ស្លាយផ្តោតលើគំនិតធំ ១, អក្សរធំៗច្បាស់ៗ, គ្មានភាពរញ៉េរញ៉ៃ, ចងចាំបានយូរ',
    structure: [
      'Slide 1: The Provocative Question',
      'Slide 2: The Hidden Truth',
      'Slide 3: The Catalyst',
      'Slide 4: The 3 Core Pillars',
      'Slide 5: The Human Impact',
      'Slide 6: The Memorable Takeaway',
    ],
    recommendedSlides: 6,
    badge: 'High Impact',
    badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
  },
];

export const SLIDE_THEMES: SlideThemeOption[] = [
  {
    id: 'dark_neon',
    name: 'Dark Neo-Glass',
    nameKhmer: 'ងងឹត បែប Modern Neo-Glass',
    previewColor: 'bg-[#0f1015] border-purple-500/40',
    accentColor: '#c084fc',
    bgDesc: 'Obsidian charcoal with glowing purple & cyan gradient borders',
    fontPairing: 'Plus Jakarta Sans + JetBrains Mono',
  },
  {
    id: 'clean_light',
    name: 'Editorial Minimalist Light',
    nameKhmer: 'ស ស្អាត បែបអក្សរសិល្ប៍ទំនើប',
    previewColor: 'bg-[#f8f9fa] border-[#d1d5db]',
    accentColor: '#1e293b',
    bgDesc: 'Off-white canvas with sharp high-contrast Swiss typography',
    fontPairing: 'Playfair Display + Inter',
  },
  {
    id: 'corporate_navy',
    name: 'Enterprise Executive Navy',
    nameKhmer: 'ខៀវចាស់ អាជីវកម្មផ្លូវការ (Enterprise)',
    previewColor: 'bg-[#0a192f] border-blue-400/40',
    accentColor: '#38bdf8',
    bgDesc: 'Deep navy background with crisp white typography and metallic cyan cards',
    fontPairing: 'Manrope + Space Grotesk',
  },
  {
    id: 'vibrant_gradient',
    name: 'Creative Solar Gradient',
    nameKhmer: 'ចម្រុះពណ៌ រស់រវើក (Creative)',
    previewColor: 'bg-gradient-to-br from-[#1a102f] to-[#2d124d] border-pink-500/40',
    accentColor: '#f472b6',
    bgDesc: 'Dynamic sunset and violet highlights for creative marketing pitch decks',
    fontPairing: 'Outfit + Plus Jakarta Sans',
  },
  {
    id: 'organic_botanical',
    name: 'Warm Earth & Botanical',
    nameKhmer: 'ធម្មជាតិ កក់ក្តៅ (Botanical Earth)',
    previewColor: 'bg-[#141d17] border-emerald-500/40',
    accentColor: '#34d399',
    bgDesc: 'Forest obsidian with warm sage green badges and natural tones',
    fontPairing: 'Lora + Plus Jakarta Sans',
  },
];

export const SLIDE_FORMATS: SlideFormatOption[] = [
  {
    id: 'markdown',
    label: 'Marp / Slidev Markdown',
    labelKhmer: 'Markdown Slides (មានសញ្ញា --- ផ្តាច់ស្លាយ)',
    description: 'Universal Markdown deck with frontmatter metadata, headers, bullet points, and speaker notes.',
  },
  {
    id: 'outline',
    label: 'Detailed Slide-by-Slide Blueprint',
    labelKhmer: 'ប្លង់មេលម្អិត (Slide Title + Content + Speaker Script)',
    description: 'Complete slide structure including visual layout suggestions, exact bullet texts, and speaker narration.',
  },
  {
    id: 'html',
    label: 'Interactive HTML/CSS Presentation',
    labelKhmer: 'HTML/CSS Slide Deck ដែលចុចមើលបាន',
    description: 'Single-file self-contained interactive web slides with animations, keyboard arrows, and clean design.',
  },
  {
    id: 'vba_powerpoint',
    label: 'PowerPoint VBA Generator Code',
    labelKhmer: 'កូដ VBA បង្កើតចូល PowerPoint ស្វ័យប្រវត្តិ',
    description: 'Copy-pasteable Microsoft PowerPoint VBA macro to build the entire deck in 1 click.',
  },
];

interface SlideStyleBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyStyle: (promptText: string, autoSend?: boolean) => void;
  initialTopic?: string;
}

export default function SlideStyleBottomSheet({
  isOpen,
  onClose,
  onApplyStyle,
  initialTopic = '',
}: SlideStyleBottomSheetProps) {
  const { triggerSelection, triggerLight, triggerMedium, triggerSuccess } = useHaptic();

  const [activeTab, setActiveTab] = useState<'styles' | 'themes' | 'customizer'>('styles');
  const [selectedStyleId, setSelectedStyleId] = useState<string>('pitch_deck');
  const [selectedThemeId, setSelectedThemeId] = useState<string>('dark_neon');
  const [selectedFormatId, setSelectedFormatId] = useState<SlideFormatOption['id']>('markdown');
  const [slideCount, setSlideCount] = useState<number>(8);
  const [presentationTopic, setPresentationTopic] = useState<string>(initialTopic);
  const [targetAudience, setTargetAudience] = useState<string>('General Audience');
  const [outputLanguage, setOutputLanguage] = useState<'km' | 'en' | 'bilingual'>('km');

  // Quick preset topic buttons
  const quickTopics = [
    'AI & Automation Strategy 2026',
    'Startup Seed Round Pitch Deck',
    'Marketing Campaign & Brand Growth',
    'Cybersecurity & Cloud Migration',
    'Khmer Digital Economy & FinTech',
    'Clean Energy & ESG Transformation',
  ];

  const currentStyle = SLIDE_STYLES.find((s) => s.id === selectedStyleId) || SLIDE_STYLES[0];
  const currentTheme = SLIDE_THEMES.find((t) => t.id === selectedThemeId) || SLIDE_THEMES[0];
  const currentFormat = SLIDE_FORMATS.find((f) => f.id === selectedFormatId) || SLIDE_FORMATS[0];

  // Generate the formatted prompt to send to the AI
  const buildPrompt = () => {
    const topic = presentationTopic.trim() || 'Modern Innovation & Strategic Vision';
    const langDesc =
      outputLanguage === 'km'
        ? 'ភាសាខ្មែរ (Khmer language with fluent, professional terminology)'
        : outputLanguage === 'bilingual'
        ? 'Bilingual (Khmer headers with English technical terms)'
        : 'English (Clear, executive, high-impact phrasing)';

    let prompt = `Please create a complete **${slideCount}-Slide Presentation Deck** on the topic: **"${topic}"**.\n\n`;
    prompt += `### 📐 Presentation Style Configuration:\n`;
    prompt += `- **Slide Style & Structure**: ${currentStyle.name} (${currentStyle.nameKhmer})\n`;
    prompt += `- **Visual Theme Aesthetic**: ${currentTheme.name} (${currentTheme.bgDesc})\n`;
    prompt += `- **Target Audience**: ${targetAudience}\n`;
    prompt += `- **Language**: ${langDesc}\n`;
    prompt += `- **Output Format**: ${currentFormat.label} (${currentFormat.description})\n\n`;

    prompt += `### 📋 Slide-by-Slide Blueprint to follow:\n`;
    currentStyle.structure.slice(0, slideCount).forEach((s) => {
      prompt += `- ${s}\n`;
    });

    prompt += `\n### ⚡ Formatting & Quality Requirements:\n`;
    prompt += `1. Provide full, high-quality, professional slide content for **all ${slideCount} slides**.\n`;
    prompt += `2. For each slide, include:\n`;
    prompt += `   - **Slide Number & Title** (Clear & Punchy)\n`;
    prompt += `   - **Key Bullet Points / Statistics / Takeaways** (3-4 concise points)\n`;
    prompt += `   - **Visual Cue / Layout Suggestion** (e.g. 2-column grid, icon cards, chart recommendation)\n`;
    prompt += `   - **Speaker Notes / Narration Script** (What the presenter should say)\n`;
    if (selectedFormatId === 'markdown') {
      prompt += `3. Use \`---\` between each slide for compatibility with slide generators (Marp / Slidev).\n`;
    } else if (selectedFormatId === 'vba_powerpoint') {
      prompt += `3. Provide a ready-to-run PowerPoint VBA script with comments on how to run it.\n`;
    }

    return prompt;
  };

  const handleApply = (autoSend: boolean) => {
    triggerSuccess();
    const prompt = buildPrompt();
    onApplyStyle(prompt, autoSend);
    onClose();
  };

  return (
    <BottomSheet isOpen={isOpen} onClose={onClose} showHandle={true} maxHeight="max-h-[92vh]">
      <div className="flex flex-col px-4 pb-6 pt-1 text-[#e3e3e3]">
        {/* Header with Title and Badges */}
        <div className="flex items-center justify-between border-b border-[#2e3035] pb-3.5 mb-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-500/20 text-[#c084fc] border border-purple-500/30">
              <Presentation size={20} />
            </div>
            <div>
              <h2 className="text-base font-semibold tracking-tight text-[#f1f3f4] flex items-center gap-2">
                <span>មីនុយ ស្តាយ ស្លាយ</span>
                <span className="text-xs font-normal text-[#9aa0a6]">• Slide Styles</span>
              </h2>
              <p className="text-[11.5px] text-[#8e918f]">
                ជ្រើសរើសទម្រង់ស្លាយ, ស្ទីលបទបង្ហាញ និង Theme សម្រាប់បង្កើត Slide ដោយស្វ័យប្រវត្តិ
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 rounded-full bg-[#18191c] px-3 py-1 text-[11px] font-medium text-purple-300 border border-purple-500/20">
            <Sparkles size={12} className="text-purple-400" />
            <span>AI Slide Generator</span>
          </div>
        </div>

        {/* Tab Switcher: Styles | Themes | Customizer */}
        <div className="grid grid-cols-3 gap-1 rounded-xl bg-[#141517] p-1 border border-[#2e3035] mb-4">
          <button
            type="button"
            onClick={() => {
              triggerLight();
              setActiveTab('styles');
            }}
            className={cn(
              'flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-medium transition-all',
              activeTab === 'styles'
                ? 'bg-[#28292a] text-[#f1f3f4] shadow-sm font-semibold'
                : 'text-[#8e918f] hover:text-[#e3e3e3]'
            )}
          >
            <LayoutTemplate size={14} />
            <span>ស្តាយស្លាយ (Styles)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              triggerLight();
              setActiveTab('themes');
            }}
            className={cn(
              'flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-medium transition-all',
              activeTab === 'themes'
                ? 'bg-[#28292a] text-[#f1f3f4] shadow-sm font-semibold'
                : 'text-[#8e918f] hover:text-[#e3e3e3]'
            )}
          >
            <Palette size={14} />
            <span>ស្បែក & ពណ៌ (Themes)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              triggerLight();
              setActiveTab('customizer');
            }}
            className={cn(
              'flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-medium transition-all',
              activeTab === 'customizer'
                ? 'bg-[#28292a] text-[#f1f3f4] shadow-sm font-semibold'
                : 'text-[#8e918f] hover:text-[#e3e3e3]'
            )}
          >
            <SlidersHorizontal size={14} />
            <span>កែសម្រួលប្លង់ (Config)</span>
          </button>
        </div>

        {/* Topic Input Field */}
        <div className="mb-4 rounded-2xl bg-[#18191c] p-3 border border-[#2e3035]">
          <label className="block text-[11px] font-semibold text-[#8e918f] uppercase tracking-wider mb-1.5 flex items-center justify-between">
            <span>ប្រធានបទបទបង្ហាញ / Slide Topic:</span>
            <span className="text-[10px] text-purple-400 lowercase font-normal">Optional or pick preset</span>
          </label>
          <input
            type="text"
            value={presentationTopic}
            onChange={(e) => setPresentationTopic(e.target.value)}
            placeholder="ឧ. ផែនការអាជីវកម្ម Startup, AI in Healthcare, យុទ្ធសាស្ត្រលក់ 2026..."
            className="w-full rounded-xl bg-[#101113] px-3.5 py-2.5 text-sm text-[#f1f3f4] placeholder-[#5f6368] border border-[#2e3035] focus:border-[#9333ea] focus:outline-none transition-all"
          />

          {/* Quick preset chips */}
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {quickTopics.map((topic, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  triggerSelection();
                  setPresentationTopic(topic);
                }}
                className={cn(
                  'rounded-full px-2.5 py-1 text-[10.5px] font-medium border transition-all cursor-pointer',
                  presentationTopic === topic
                    ? 'bg-purple-500/20 text-purple-300 border-purple-500/50'
                    : 'bg-[#141517] text-[#9aa0a6] border-[#2e3035] hover:text-[#e3e3e3] hover:border-[#4b4e54]'
                )}
              >
                {topic}
              </button>
            ))}
          </div>
        </div>

        {/* TAB 1: SLIDE STYLES */}
        {activeTab === 'styles' && (
          <div className="space-y-2.5 max-h-[38vh] overflow-y-auto pr-1">
            {SLIDE_STYLES.map((style) => {
              const isSelected = selectedStyleId === style.id;
              return (
                <div
                  key={style.id}
                  onClick={() => {
                    triggerSelection();
                    setSelectedStyleId(style.id);
                    setSlideCount(style.recommendedSlides);
                  }}
                  className={cn(
                    'group relative flex flex-col rounded-2xl p-3.5 border transition-all cursor-pointer',
                    isSelected
                      ? 'bg-[#22202a] border-[#9333ea] shadow-md shadow-purple-950/20'
                      : 'bg-[#18191c] border-[#2e3035] hover:border-[#44474f] hover:bg-[#1e2024]'
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#141517] border border-[#2e3035]">
                        {style.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-semibold text-[#f1f3f4]">{style.nameKhmer}</h3>
                          <span className={cn('rounded px-1.5 py-0.2 text-[9px] font-bold border', style.badgeColor)}>
                            {style.badge}
                          </span>
                        </div>
                        <p className="text-xs text-[#c084fc]/90 font-medium">{style.name}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {isSelected ? (
                        <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#9333ea] text-white">
                          <Check size={14} />
                        </div>
                      ) : (
                        <span className="text-xs text-[#8e918f] font-mono">{style.recommendedSlides} slides</span>
                      )}
                    </div>
                  </div>

                  <p className="mt-2 text-[11.5px] text-[#9aa0a6] leading-relaxed">
                    {style.taglineKhmer}
                  </p>

                  {/* Structure Preview when selected */}
                  {isSelected && (
                    <div className="mt-3 pt-2.5 border-t border-purple-500/20">
                      <span className="text-[10px] font-bold text-purple-300 uppercase tracking-wider block mb-1.5">
                        រចនាសម្ព័ន្ធស្លាយ ({style.structure.length} Slides):
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-[11px] text-[#cfd3dc]">
                        {style.structure.map((item, i) => (
                          <div key={i} className="flex items-center gap-1.5 truncate">
                            <span className="text-purple-400 font-bold">•</span>
                            <span className="truncate">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 2: THEMES & COLOR PALETTES */}
        {activeTab === 'themes' && (
          <div className="space-y-2.5 max-h-[38vh] overflow-y-auto pr-1">
            {SLIDE_THEMES.map((theme) => {
              const isSelected = selectedThemeId === theme.id;
              return (
                <div
                  key={theme.id}
                  onClick={() => {
                    triggerSelection();
                    setSelectedThemeId(theme.id);
                  }}
                  className={cn(
                    'flex items-center justify-between rounded-2xl p-3.5 border transition-all cursor-pointer',
                    isSelected
                      ? 'bg-[#22202a] border-[#9333ea] shadow-md shadow-purple-950/20'
                      : 'bg-[#18191c] border-[#2e3035] hover:border-[#44474f] hover:bg-[#1e2024]'
                  )}
                >
                  <div className="flex items-center gap-3.5">
                    <div className={cn('h-10 w-10 shrink-0 rounded-xl border flex items-center justify-center shadow-inner', theme.previewColor)}>
                      <Palette size={18} style={{ color: theme.accentColor }} />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-[#f1f3f4]">{theme.nameKhmer}</h3>
                      <p className="text-xs text-[#8e918f]">{theme.name}</p>
                      <p className="text-[10.5px] text-[#9aa0a6] mt-0.5">{theme.bgDesc}</p>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#9333ea] text-white">
                      <Check size={14} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 3: CUSTOMIZER & FORMAT CONFIG */}
        {activeTab === 'customizer' && (
          <div className="space-y-3 max-h-[38vh] overflow-y-auto pr-1 text-xs">
            {/* Slide Count Slider & Buttons */}
            <div className="rounded-2xl bg-[#18191c] p-3.5 border border-[#2e3035]">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-[#f1f3f4]">ចំនួនស្លាយ (Slide Count):</span>
                <span className="font-mono text-sm font-bold text-purple-400">{slideCount} Slides</span>
              </div>
              <div className="flex gap-2">
                {[5, 7, 8, 10, 12, 15].map((count) => (
                  <button
                    key={count}
                    type="button"
                    onClick={() => {
                      triggerSelection();
                      setSlideCount(count);
                    }}
                    className={cn(
                      'flex-1 rounded-lg py-1.5 font-bold transition-all border',
                      slideCount === count
                        ? 'bg-purple-600 text-white border-purple-500 shadow-sm'
                        : 'bg-[#141517] text-[#8e918f] border-[#2e3035] hover:text-[#e3e3e3]'
                    )}
                  >
                    {count}
                  </button>
                ))}
              </div>
            </div>

            {/* Language Selector */}
            <div className="rounded-2xl bg-[#18191c] p-3.5 border border-[#2e3035]">
              <span className="font-semibold text-[#f1f3f4] block mb-2">ភាសាបទបង្ហាញ (Slide Language):</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'km', label: '🇰🇭 ភាសាខ្មែរ' },
                  { id: 'bilingual', label: '🌐 ខ្មែរ + English' },
                  { id: 'en', label: '🇺🇸 English' },
                ].map((l) => (
                  <button
                    key={l.id}
                    type="button"
                    onClick={() => {
                      triggerSelection();
                      setOutputLanguage(l.id as any);
                    }}
                    className={cn(
                      'rounded-xl py-2 font-medium text-xs border transition-all',
                      outputLanguage === l.id
                        ? 'bg-purple-600/30 text-purple-300 border-purple-500'
                        : 'bg-[#141517] text-[#8e918f] border-[#2e3035]'
                    )}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Output Format Selector */}
            <div className="rounded-2xl bg-[#18191c] p-3.5 border border-[#2e3035]">
              <span className="font-semibold text-[#f1f3f4] block mb-2">ទម្រង់ចេញ (Output Format):</span>
              <div className="space-y-1.5">
                {SLIDE_FORMATS.map((f) => (
                  <div
                    key={f.id}
                    onClick={() => {
                      triggerSelection();
                      setSelectedFormatId(f.id);
                    }}
                    className={cn(
                      'flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition-all',
                      selectedFormatId === f.id
                        ? 'bg-purple-500/20 border-purple-500/50 text-[#f1f3f4]'
                        : 'bg-[#141517] border-[#2e3035] text-[#8e918f] hover:text-[#e3e3e3]'
                    )}
                  >
                    <div>
                      <div className="font-semibold text-[#f1f3f4]">{f.labelKhmer}</div>
                      <div className="text-[10px] text-[#8e918f]">{f.label}</div>
                    </div>
                    {selectedFormatId === f.id && <Check size={14} className="text-purple-400 shrink-0" />}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Selected Summary Bar & Action Buttons */}
        <div className="mt-4 pt-3 border-t border-[#2e3035]">
          <div className="mb-3 flex items-center justify-between text-xs text-[#8e918f]">
            <div className="flex items-center gap-1.5 truncate max-w-[70%]">
              <span className="text-purple-400 font-semibold">ស្តាយ:</span>
              <span className="text-[#e3e3e3] font-medium truncate">{currentStyle.nameKhmer}</span>
              <span>•</span>
              <span className="text-[#c084fc] font-mono">{slideCount} slides</span>
            </div>
            <span className="text-[11px] text-[#9aa0a6] truncate">{currentTheme.name}</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Insert to input prompt */}
            <button
              type="button"
              onClick={() => handleApply(false)}
              className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-[#28292a] py-3 text-xs font-semibold text-[#e3e3e3] hover:bg-[#383a3d] hover:text-white transition-all active:scale-[0.98] border border-[#3c4043]"
            >
              <FileText size={15} />
              <span>បញ្ចូលទៅ Chat Input</span>
            </button>

            {/* Generate & Send Instantly */}
            <button
              type="button"
              onClick={() => handleApply(true)}
              className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#9333ea] to-[#7c3aed] py-3 text-xs font-bold text-white shadow-lg shadow-purple-900/30 hover:brightness-110 transition-all active:scale-[0.98]"
            >
              <Sparkles size={15} />
              <span>បង្កើតបទបង្ហាញភ្លាមៗ</span>
            </button>
          </div>
        </div>
      </div>
    </BottomSheet>
  );
}
