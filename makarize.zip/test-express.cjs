const express = require('express');
const app = express();
app.get('*', (req, res) => res.send('Star route'));
app.listen(3001, () => {
  console.log('listening on 3001');
  const http = require('http');
  http.get('http://localhost:3001/test', (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => console.log('Response:', data, 'Status:', res.statusCode));
    process.exit(0);
  });
});
