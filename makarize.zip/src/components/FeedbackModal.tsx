import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MessageSquare, Star, Send, CheckCircle2, Heart } from 'lucide-react';
import { cn } from '../lib/utils';
import { useHaptic } from '../lib/useHaptic';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail?: string;
}

export default function FeedbackModal({ isOpen, onClose, userEmail }: FeedbackModalProps) {
  const [rating, setRating] = useState<number>(5);
  const [category, setCategory] = useState<string>('improvement');
  const [feedbackText, setFeedbackText] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [isSending, setIsSending] = useState<boolean>(false);
  const { triggerSelection, triggerSuccess, triggerLight } = useHaptic();

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim() && rating === 0) return;

    setIsSending(true);
    try {
      await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating,
          category,
          commentText: feedbackText,
          userEmail: userEmail || 'Anonymous',
        }),
      });
    } catch (err) {
      console.warn('Feedback dispatch notice:', err);
    } finally {
      setIsSending(false);
      triggerSuccess();
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        setFeedbackText('');
        onClose();
      }, 2200);
    }
  };

  const categories = [
    { id: 'improvement', label: '💡 គំនិតកែលម្អ' },
    { id: 'feature', label: '🚀 ស្នើសុំមុខងារថ្មី' },
    { id: 'bug', label: '⚠️ រាយការណ៍បញ្ហា' },
    { id: 'compliment', label: '❤️ ពាក្យកោតសរសើរ' },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
        <motion.div
          initial={{ opacity: 0, y: '100%' }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: '100%' }}
          transition={{ type: 'spring', damping: 26, stiffness: 300 }}
          className="relative w-full max-w-lg overflow-hidden rounded-t-[28px] sm:rounded-3xl border border-[#3c4043] bg-[#18191c] shadow-2xl z-10 max-h-[90vh] flex flex-col text-[#e3e3e3]"
        >
          {/* Mobile Handle */}
          <div className="mx-auto mt-2.5 h-1.5 w-12 rounded-full bg-[#4a4d52] sm:hidden" />

          {/* Header */}
          <div className="flex items-center justify-between px-5 pt-3.5 pb-3 border-b border-[#28292c]">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-500/20 border border-purple-500/30 text-purple-400">
                <MessageSquare size={18} />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">ផ្ញើមតិកែលម្អ (Feedback)</h3>
                <p className="text-[11.5px] text-[#8e918f]">មតិរបស់អ្នកជួយឱ្យ Aroch AI កាន់តែប្រសើរឡើង</p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-[#28292a] text-[#8e918f] hover:text-white transition-colors cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {isSubmitted ? (
            <div className="p-8 flex flex-col items-center justify-center text-center space-y-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 animate-bounce">
                <CheckCircle2 size={32} />
              </div>
              <h4 className="text-base font-bold text-white">សូមអរគុណចំពោះមតិកែលម្អរបស់អ្នក!</h4>
              <p className="text-xs text-[#8e918f] max-w-xs">
                ក្រុមការងារយើងខ្ញុំនឹងយកចិត្តទុកដាក់អភិវឌ្ឍន៍បន្ថែមទៀតដើម្បីផ្តល់បទពិសោធន៍ល្អបំផុត។
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
              {/* Star Rating */}
              <div className="text-center space-y-2 pb-1">
                <label className="text-xs font-semibold text-[#c4c7c5]">តើអ្នកពេញចិត្តកម្រិតណាដែរ?</label>
                <div className="flex items-center justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => {
                        triggerLight();
                        setRating(star);
                      }}
                      className="p-1 transition-transform hover:scale-125 focus:outline-none cursor-pointer"
                    >
                      <Star
                        size={28}
                        className={cn(
                          'transition-colors',
                          star <= rating ? 'fill-amber-400 text-amber-400' : 'text-[#3c4043]'
                        )}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Feedback Category */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#c4c7c5]">ប្រភេទមតិ៖</label>
                <div className="grid grid-cols-2 gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => {
                        triggerLight();
                        setCategory(cat.id);
                      }}
                      className={cn(
                        'px-3 py-2 rounded-xl text-xs font-medium text-left border transition-all cursor-pointer',
                        category === cat.id
                          ? 'bg-purple-950/40 border-purple-500 text-purple-200 ring-1 ring-purple-500/40'
                          : 'bg-[#1e1f23] border-[#2e3035] text-[#8e918f] hover:text-white'
                      )}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Text Area */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#c4c7c5]">សេចក្តីលម្អិត៖</label>
                <textarea
                  rows={4}
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder="សូមសរសេរមតិ យោបល់ ឬបញ្ហាដែលអ្នកបានជួបប្រទះនៅទីនេះ..."
                  className="w-full rounded-2xl bg-[#1e1f23] p-3.5 text-xs text-[#e3e3e3] placeholder-[#8e918f] border border-[#2e3035] focus:border-purple-500 focus:ring-1 focus:ring-purple-500/30 outline-none transition-all resize-none"
                  required
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSending}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 disabled:opacity-60 text-white font-semibold text-xs transition-all shadow-md cursor-pointer active:scale-[0.99]"
                >
                  <Send size={14} className={isSending ? 'animate-spin' : ''} />
                  <span>{isSending ? 'កំពុងផ្ញើ...' : 'ផ្ញើមតិកែលម្អ'}</span>
                </button>
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
