import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Zap, Sparkles, X, ChevronRight } from 'lucide-react';

interface PaidUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlock: () => void;
  onFallback: () => void;
}

export default function PaidUpgradeModal({ isOpen, onClose, onUnlock, onFallback }: PaidUpgradeModalProps) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          className="relative w-full max-w-md rounded-3xl border border-[#3c4043] bg-[#1a1a1c] p-6 shadow-2xl text-[#e3e3e3]"
        >
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-full text-[#8e918f] hover:text-[#e3e3e3] hover:bg-[#28292a] transition-colors"
          >
            <X size={20} />
          </button>

          <div className="flex flex-col items-center text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[#9333ea] to-[#4f46e5] mb-4 shadow-lg shadow-[#9333ea]/20">
              <Lock size={32} className="text-white" />
            </div>
            <h2 className="text-xl font-bold mb-2">ARUCH Paid Tier Required</h2>
            <p className="text-sm text-[#8e918f] mb-6">
              This high-performance model is part of the ARUCH Paid Tier. Unlock it now to get premium AI capabilities and higher usage limits.
            </p>
          </div>

          <div className="space-y-3">
            <button
              type="button"
              onClick={onUnlock}
              className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#9333ea] to-[#4f46e5] py-3 text-sm font-bold text-white shadow-lg hover:brightness-110 active:scale-[0.98] transition-all"
            >
              <Sparkles size={16} />
              Unlock via KHQR Payment
            </button>
            <button
              type="button"
              onClick={onFallback}
              className="w-full flex items-center justify-center gap-2 rounded-2xl bg-[#28292a] py-3 text-sm font-semibold text-[#e3e3e3] hover:bg-[#333537] transition-all"
            >
              <Zap size={16} />
              Continue with Free Core
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
