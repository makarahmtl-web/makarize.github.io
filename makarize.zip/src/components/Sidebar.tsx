import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Plus,
  MessageSquare,
  FolderKanban,
  Box,
  Settings as SettingsIcon,
  Trash2,
  Edit2,
  Check,
  X,
  PanelLeftClose,
  Search,
  Pin,
  PinOff,
  CloudCheck,
  Sparkles,
  Zap,
  MessageCircle,
  MoreVertical,
} from 'lucide-react';
import { ChatSession } from '../types';
import { User } from '../lib/firebase';
import { cn } from '../lib/utils';
import MakarizeLogo from './MakarizeLogo';
import { useHaptic } from '../lib/useHaptic';
import { t } from '../lib/i18n';

function formatSessionTime(timestamp?: number): string {
  if (!timestamp) return '';
  const diff = Date.now() - timestamp;
  if (diff < 60 * 1000) return 'Just now';
  if (diff < 60 * 60 * 1000) return `${Math.floor(diff / (60 * 1000))}m ago`;
  if (diff < 24 * 60 * 60 * 1000) return `${Math.floor(diff / (60 * 60 * 1000))}h ago`;
  if (diff < 7 * 24 * 60 * 60 * 1000) return `${Math.floor(diff / (24 * 60 * 60 * 1000))}d ago`;
  const date = new Date(timestamp);
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  currentSessionId: string;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onTogglePinSession?: (id: string) => void;
  onClearAllHistory?: () => void;
  user: User;
  onOpenSettings: () => void;
  currentNav: 'chats' | 'projects' | 'artifacts';
  onNavChange: (nav: 'chats' | 'projects' | 'artifacts') => void;
  language?: string;
}

export default function Sidebar({
  isOpen,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onRenameSession,
  onTogglePinSession,
  onClearAllHistory,
  user,
  onOpenSettings,
  currentNav,
  onNavChange,
  language = 'km',
}: SidebarProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showConfirmClear, setShowConfirmClear] = useState(false);

  const { triggerLight, triggerSelection, triggerMedium, triggerSuccess, triggerWarning } = useHaptic();

  const handleStartEdit = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerLight();
    setEditingId(session.id);
    setEditTitle(session.title);
  };

  const handleSaveEdit = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (editTitle.trim()) {
      triggerSuccess();
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const handleCancelEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerLight();
    setEditingId(null);
  };

  // Group and filter sessions by date category and search
  const { pinnedSessions, todaySessions, yesterdaySessions, weekSessions, olderSessions } = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const filtered = sessions.filter((s) => {
      if (!query) return true;
      const titleMatch = s.title.toLowerCase().includes(query);
      const messageMatch = (s.messages || []).some((m) => m.text?.toLowerCase().includes(query));
      return titleMatch || messageMatch;
    });

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
    const startOfWeek = startOfToday - 7 * 24 * 60 * 60 * 1000;

    const pinned: ChatSession[] = [];
    const today: ChatSession[] = [];
    const yesterday: ChatSession[] = [];
    const week: ChatSession[] = [];
    const older: ChatSession[] = [];

    for (const s of filtered) {
      if (s.isPinned) {
        pinned.push(s);
        continue;
      }
      const time = s.updatedAt || s.createdAt || 0;
      if (time >= startOfToday) {
        today.push(s);
      } else if (time >= startOfYesterday) {
        yesterday.push(s);
      } else if (time >= startOfWeek) {
        week.push(s);
      } else {
        older.push(s);
      }
    }

    return {
      pinnedSessions: pinned,
      todaySessions: today,
      yesterdaySessions: yesterday,
      weekSessions: week,
      olderSessions: older,
    };
  }, [sessions, searchQuery]);

  const renderSessionItem = (session: ChatSession) => {
    const isActive = session.id === currentSessionId;
    const isEditing = editingId === session.id;

    const modelName = session.model || 'openai/gpt-4o';
    let modelBadge = 'GPT-4o';
    if (modelName.includes('gemini')) modelBadge = 'Gemini';
    else if (modelName.includes('groq') || modelName.includes('llama')) modelBadge = 'Groq';
    else if (modelName.includes('openchat') || modelName.includes('character') || modelName.includes('mythomax')) modelBadge = 'Open Character';
    else if (modelName.includes('claude')) modelBadge = 'Claude';
    else if (modelName.includes('deepseek')) modelBadge = 'DeepSeek';

    return (
      <div
        key={session.id}
        onClick={() => {
          triggerLight();
          onSelectSession(session.id);
          if (window.innerWidth < 768) onClose();
        }}
        className={cn(
          'group relative flex items-center justify-between rounded-xl px-2.5 py-2 text-xs font-medium transition-all cursor-pointer border',
          isActive
            ? 'bg-[#2a2b2f] text-white border-[#9333ea]/50 shadow-sm ring-1 ring-[#9333ea]/20'
            : 'text-[#c4c7c5] border-transparent hover:bg-[#25262a] hover:text-[#e3e3e3]'
        )}
      >
        {isEditing ? (
          <div className="flex flex-1 items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              className="w-full rounded-lg bg-[#141517] px-2 py-1 text-xs text-[#e3e3e3] outline-none border border-[#9333ea]"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSaveEdit(session.id, e as any);
                if (e.key === 'Escape') handleCancelEdit(e as any);
              }}
            />
            <button
              onClick={(e) => handleSaveEdit(session.id, e)}
              className="p-1 text-[#34a853] hover:text-white"
            >
              <Check size={13} />
            </button>
            <button
              onClick={handleCancelEdit}
              className="p-1 text-[#ea4335] hover:text-white"
            >
              <X size={13} />
            </button>
          </div>
        ) : (
          <>
            <div className="flex min-w-0 items-center gap-2 flex-1">
              <MessageSquare size={13} className={cn('shrink-0', isActive ? 'text-[#c084fc]' : 'text-[#8e918f]')} />
              <div className="flex flex-col min-w-0 flex-1">
                <span className="truncate max-w-[145px] text-[12.5px] font-medium leading-tight" title={session.title}>
                  {session.title}
                </span>
                <span className="text-[9.5px] text-[#8e918f] mt-0.5 truncate flex items-center gap-1">
                  <span className="text-[#c084fc]/90 font-medium">{modelBadge}</span>
                  {formatSessionTime(session.updatedAt || session.createdAt) && (
                    <>
                      <span>•</span>
                      <span>{formatSessionTime(session.updatedAt || session.createdAt)}</span>
                    </>
                  )}
                  <span>•</span>
                  <span>{session.messages?.length || 0} msgs</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {onTogglePinSession && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    triggerLight();
                    onTogglePinSession(session.id);
                  }}
                  title={session.isPinned ? 'Unpin chat' : 'Pin chat'}
                  className="p-1 text-[#8e918f] hover:text-[#c084fc] transition-colors"
                >
                  {session.isPinned ? <PinOff size={12} /> : <Pin size={12} />}
                </button>
              )}
              <button
                type="button"
                onClick={(e) => handleStartEdit(session, e)}
                title="Rename"
                className="p-1 text-[#8e918f] hover:text-[#e3e3e3] transition-colors"
              >
                <Edit2 size={12} />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerWarning();
                  onDeleteSession(session.id);
                }}
                title="Delete chat"
                className="p-1 text-[#8e918f] hover:text-[#ea4335] transition-colors"
              >
                <Trash2 size={12} />
              </button>
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Backdrop for Mobile */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              triggerLight();
              onClose();
            }}
            className="fixed inset-0 z-40 bg-black/65 backdrop-blur-sm md:hidden"
          />
        )}
      </AnimatePresence>

      {/* Main Drawer Sidebar */}
      <motion.aside
        initial={false}
        animate={{
          width: isOpen ? 290 : 0,
          opacity: isOpen ? 1 : 0,
        }}
        transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex h-full flex-col overflow-hidden border-r border-[#28292c] bg-[#17181b] shadow-2xl transition-[width,opacity] md:relative md:shadow-none',
          !isOpen && 'pointer-events-none'
        )}
      >
        <div className="flex h-full w-[290px] flex-col justify-between p-3">
          {/* Top Actions & Header */}
          <div className="flex flex-col gap-2.5 flex-1 min-h-0">
            {/* Top Bar with Brand & Close Button */}
            <div className="flex items-center justify-between px-2 pt-1 pb-1">
              <div className="flex items-center gap-2.5">
                <MakarizeLogo size={28} />
                <div className="flex flex-col">
                  <span className="font-bold text-[#e3e3e3] tracking-tight text-[15px] leading-tight">Makarize</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[10px] text-[#c084fc] font-semibold leading-none">AI Studio</span>
                    <span className="inline-flex items-center gap-0.5 rounded-full bg-emerald-500/10 px-1.5 py-0.2 text-[9px] font-bold text-emerald-400 border border-emerald-500/20">
                      <span className="h-1 w-1 rounded-full bg-emerald-400 animate-pulse" />
                      Firestore
                    </span>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  triggerLight();
                  onClose();
                }}
                title="Collapse sidebar"
                className="flex h-8 w-8 items-center justify-center rounded-full text-[#8e918f] hover:bg-[#25262a] hover:text-[#e3e3e3] transition-colors cursor-pointer"
              >
                <PanelLeftClose size={18} />
              </button>
            </div>

            {/* New Chat Button */}
            <button
              type="button"
              id="btn-sidebar-new-chat"
              onClick={() => {
                triggerMedium();
                onNewChat();
                if (window.innerWidth < 768) onClose();
              }}
              className="group flex w-full items-center justify-between rounded-2xl bg-gradient-to-r from-[#9333ea] to-[#7928ca] px-3.5 py-2.5 text-xs font-bold text-white shadow-md hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-white/20 text-white transition-transform group-hover:rotate-90">
                  <Plus size={15} />
                </div>
                <span className="text-sm font-semibold">{t('newChat', language)}</span>
              </div>
              <Sparkles size={14} className="opacity-80 group-hover:rotate-12 transition-transform" />
            </button>

            {/* Search Bar for Past Conversations */}
            <div className="relative mt-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8e918f]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search past chats..."
                className="w-full rounded-xl bg-[#1f2024] pl-9 pr-7 py-1.5 text-xs text-[#e3e3e3] placeholder-[#8e918f] border border-[#2e3035] focus:border-[#9333ea]/70 focus:ring-1 focus:ring-[#9333ea]/30 outline-none transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8e918f] hover:text-white"
                >
                  <X size={12} />
                </button>
              )}
            </div>

            {/* Navigation Category Tabs */}
            <nav className="flex gap-1 border-b border-[#28292c] pb-2 pt-0.5">
              <button
                type="button"
                onClick={() => {
                  triggerSelection();
                  onNavChange('chats');
                }}
                className={cn(
                  'flex-1 flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-semibold transition-colors cursor-pointer',
                  currentNav === 'chats'
                    ? 'bg-[#9333ea]/20 text-[#d8b4fe] border border-[#9333ea]/40'
                    : 'text-[#8e918f] hover:bg-[#202124] hover:text-[#e3e3e3]'
                )}
              >
                <MessageSquare size={13} />
                <span>{t('chats', language)}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  triggerSelection();
                  onNavChange('projects');
                }}
                className={cn(
                  'flex-1 flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-semibold transition-colors cursor-pointer',
                  currentNav === 'projects'
                    ? 'bg-[#9333ea]/20 text-[#d8b4fe] border border-[#9333ea]/40'
                    : 'text-[#8e918f] hover:bg-[#202124] hover:text-[#e3e3e3]'
                )}
              >
                <FolderKanban size={13} />
                <span>{t('projects', language)}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  triggerSelection();
                  onNavChange('artifacts');
                }}
                className={cn(
                  'flex-1 flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-semibold transition-colors cursor-pointer',
                  currentNav === 'artifacts'
                    ? 'bg-[#9333ea]/20 text-[#d8b4fe] border border-[#9333ea]/40'
                    : 'text-[#8e918f] hover:bg-[#202124] hover:text-[#e3e3e3]'
                )}
              >
                <Box size={13} />
                <span>{t('artifacts', language)}</span>
              </button>
            </nav>

            {/* Past Conversations List (Grouped by Date) */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-3 pt-1">
              {sessions.length === 0 ? (
                <div className="py-8 text-center">
                  <MessageCircle size={28} className="mx-auto text-[#4a4d52] mb-2" />
                  <p className="text-xs font-medium text-[#8e918f]">No conversation history yet.</p>
                  <p className="text-[11px] text-[#5f6368] mt-0.5">Start chatting to auto-save to Firestore.</p>
                </div>
              ) : (
                <>
                  {/* Pinned Section */}
                  {pinnedSessions.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-[#c084fc] flex items-center gap-1">
                        <Pin size={10} />
                        <span>Pinned Chats</span>
                      </div>
                      <div className="space-y-1">{pinnedSessions.map(renderSessionItem)}</div>
                    </div>
                  )}

                  {/* Today Section */}
                  {todaySessions.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-[#8e918f]">
                        Today
                      </div>
                      <div className="space-y-1">{todaySessions.map(renderSessionItem)}</div>
                    </div>
                  )}

                  {/* Yesterday Section */}
                  {yesterdaySessions.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-[#8e918f]">
                        Yesterday
                      </div>
                      <div className="space-y-1">{yesterdaySessions.map(renderSessionItem)}</div>
                    </div>
                  )}

                  {/* Previous 7 Days */}
                  {weekSessions.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-[#8e918f]">
                        Previous 7 Days
                      </div>
                      <div className="space-y-1">{weekSessions.map(renderSessionItem)}</div>
                    </div>
                  )}

                  {/* Older Section */}
                  {olderSessions.length > 0 && (
                    <div className="space-y-1">
                      <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-[#8e918f]">
                        Older History
                      </div>
                      <div className="space-y-1">{olderSessions.map(renderSessionItem)}</div>
                    </div>
                  )}

                  {/* No search results feedback */}
                  {searchQuery &&
                    pinnedSessions.length === 0 &&
                    todaySessions.length === 0 &&
                    yesterdaySessions.length === 0 &&
                    weekSessions.length === 0 &&
                    olderSessions.length === 0 && (
                      <p className="px-3 py-6 text-center text-xs text-[#8e918f]">
                        No matching conversations found for &ldquo;{searchQuery}&rdquo;.
                      </p>
                    )}
                </>
              )}
            </div>
          </div>

          {/* Bottom Actions & User Profile */}
          <div className="mt-auto border-t border-[#28292c] pt-2.5 space-y-2">
            {/* Clear History Trigger (if sessions exist) */}
            {sessions.length > 1 && onClearAllHistory && (
              <div className="px-1">
                {showConfirmClear ? (
                  <div className="flex items-center justify-between rounded-xl bg-red-500/10 border border-red-500/30 p-2 text-xs text-red-400">
                    <span className="text-[11px] font-semibold">Clear all chats?</span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          triggerWarning();
                          onClearAllHistory();
                          setShowConfirmClear(false);
                        }}
                        className="rounded bg-red-600 px-2 py-0.5 text-[10px] font-bold text-white hover:bg-red-500"
                      >
                        Yes
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowConfirmClear(false)}
                        className="rounded bg-[#28292c] px-2 py-0.5 text-[10px] text-[#e3e3e3] hover:bg-[#34363a]"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowConfirmClear(true)}
                    className="w-full flex items-center justify-center gap-1.5 py-1 text-[11px] text-[#8e918f] hover:text-[#ea4335] transition-colors"
                  >
                    <Trash2 size={11} />
                    <span>Clear conversation history</span>
                  </button>
                )}
              </div>
            )}

            {/* ផ្នែក Profile ខាងក្រោម Sidebar */}
            <div className="user-profile-card">
              {user.photoURL ? (
                <img
                  id="userAvatar"
                  src={user.photoURL}
                  alt="User Profile"
                  className="profile-img border border-[#4b4e54]"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div
                  id="userAvatar"
                  className="profile-img flex shrink-0 items-center justify-center bg-gradient-to-tr from-[#9333ea] to-[#4285f4] text-xs font-bold text-white shadow-sm"
                >
                  {user.displayName ? user.displayName.charAt(0).toUpperCase() : 'M'}
                </div>
              )}
              <div className="user-info">
                <div id="userNameDisplay" className="user-name" title={user.displayName || 'Makara HMTL'}>
                  {user.displayName || 'Makara HMTL'}
                </div>
                <div id="userEmailDisplay" className="user-email" title={user.email || 'makarahmtl@gmail.com'}>
                  {user.email || 'makarahmtl@gmail.com'}
                </div>
              </div>
              <button
                type="button"
                id="btn-sidebar-user-settings"
                onClick={() => {
                  triggerSelection();
                  onOpenSettings();
                }}
                className="settings-btn"
                title="ការកំណត់"
              >
                ⚙️
              </button>
            </div>
          </div>
        </div>
      </motion.aside>
    </>
  );
}

