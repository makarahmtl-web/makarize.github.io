import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Play,
  Pause,
  Upload,
  Camera,
  Image as ImageIcon,
  FileCode,
  Video,
  Sparkles,
  RefreshCw,
  Check,
  Send,
  Trash2,
  Globe,
  Loader2,
  SwitchCamera,
  RotateCcw,
} from 'lucide-react';
import BottomSheet from './BottomSheet';
import { FileAttachment } from '../types';
import { cn } from '../lib/utils';
import { formatBytes } from '../lib/fileUtils';
import { useHaptic } from '../lib/useHaptic';

interface AttachmentBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onAddAttachment: (attachment: FileAttachment) => void;
  onTranscribeDirect: (transcriptText: string, audioAttachment?: FileAttachment) => void;
}

export interface LanguageOption {
  code: string;
  name: string;
  nativeLabel: string;
}

export const AUDIO_TRANSLATION_LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeLabel: 'English' },
  { code: 'km', name: 'Khmer', nativeLabel: 'Khmer (ភាសាខ្មែរ)' },
  { code: 'ja', name: 'Japanese', nativeLabel: 'Japanese (日本語)' },
  { code: 'es', name: 'Spanish', nativeLabel: 'Spanish (Español)' },
  { code: 'fr', name: 'French', nativeLabel: 'French (Français)' },
  { code: 'zh', name: 'Chinese', nativeLabel: 'Chinese (中文)' },
];

type TabMode = 'audio' | 'camera' | 'photos' | 'documents';

export default function AttachmentBottomSheet({
  isOpen,
  onClose,
  onAddAttachment,
  onTranscribeDirect,
}: AttachmentBottomSheetProps) {
  const [activeTab, setActiveTab] = useState<TabMode>('audio');
  const {
    triggerLight,
    triggerSelection,
    triggerMedium,
    triggerHeavy,
    triggerSuccess,
    triggerWarning,
  } = useHaptic();

  // --- Audio Recording State ---
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcribeTargetLang, setTranscribeTargetLang] = useState<string>('ja');
  const [transcribeMode, setTranscribeMode] = useState<'verbatim' | 'translate'>('translate');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<number | null>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);

  // --- Camera Capture State ---
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isSwitchingCamera, setIsSwitchingCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // File Input Refs
  const photoInputRef = useRef<HTMLInputElement | null>(null);
  const docInputRef = useRef<HTMLInputElement | null>(null);

  // --- Camera Stream Lifecycle ---
  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      startCamera(facingMode);
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab, facingMode]);

  const startCamera = async (targetFacing: 'user' | 'environment' = facingMode) => {
    try {
      setIsSwitchingCamera(true);
      setCameraError(null);
      stopCamera();

      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: targetFacing,
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });
      } catch (err) {
        // Fallback for browsers that don't support specific facingMode constraints
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      }

      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError('Camera access denied or unavailable on this device.');
    } finally {
      setIsSwitchingCamera(false);
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
  };

  const toggleFacingMode = () => {
    triggerLight();
    const nextMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextMode);
  };

  const takeSnapshot = () => {
    if (!videoRef.current) return;
    triggerHeavy();
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      if (facingMode === 'user') {
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
      }
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const base64Data = canvas.toDataURL('image/jpeg', 0.9);
      setCapturedImage(base64Data);
    }
  };

  const attachCapturedImage = () => {
    if (!capturedImage) return;
    triggerSuccess();
    const base64Clean = capturedImage.split(',')[1];
    const newAttachment: FileAttachment = {
      id: `snap-${Date.now()}`,
      name: `Snapshot-${new Date().toLocaleTimeString().replace(/:/g, '-')}.jpg`,
      type: 'image/jpeg',
      mimeType: 'image/jpeg',
      size: Math.round((base64Clean.length * 3) / 4),
      data: base64Clean,
      previewUrl: capturedImage,
      typeCategory: 'image',
    };
    onAddAttachment(newAttachment);
    setCapturedImage(null);
    onClose();
  };

  // --- Audio Recording Logic ---
  const startRecording = async () => {
    try {
      triggerHeavy();
      setAudioBlob(null);
      setAudioUrl(null);
      audioChunksRef.current = [];

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const mimeType = mediaRecorder.mimeType || 'audio/webm';
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        setAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start(100);
      setIsRecording(true);
      setIsPaused(false);
      setRecordingDuration(0);

      timerIntervalRef.current = window.setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone recording error:', err);
      alert('Microphone access is required to record audio notes.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      triggerMedium();
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
  };

  const togglePlayAudio = () => {
    triggerLight();
    if (!audioElementRef.current && audioUrl) {
      audioElementRef.current = new Audio(audioUrl);
      audioElementRef.current.onended = () => setIsPlayingAudio(false);
    }

    if (audioElementRef.current) {
      if (isPlayingAudio) {
        audioElementRef.current.pause();
        setIsPlayingAudio(false);
      } else {
        audioElementRef.current.play();
        setIsPlayingAudio(true);
      }
    }
  };

  // Convert audio blob to base64 & transcribe via /api/transcribe
  const handleTranscribeAndSend = async (mode: 'verbatim' | 'translate') => {
    if (!audioBlob) return;
    triggerMedium();
    setIsTranscribing(true);

    try {
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        try {
          const base64Data = (reader.result as string).split(',')[1];
          const mimeType = audioBlob.type || 'audio/webm';

          const res = await fetch('/api/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioData: base64Data,
              mimeType,
              mode,
              targetLanguage: transcribeTargetLang,
            }),
          });

          const data = await res.json();
          if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to transcribe audio');
          }

          const audioAttachment: FileAttachment = {
            id: `voice-${Date.now()}`,
            name: `VoiceRecord-${recordingDuration}s.webm`,
            type: mimeType,
            mimeType: mimeType,
            size: audioBlob.size,
            data: base64Data,
            previewUrl: audioUrl || undefined,
            typeCategory: 'audio',
          };

          triggerSuccess();
          setIsTranscribing(false);
          onTranscribeDirect(data.text, audioAttachment);
          onClose();
        } catch (innerErr: any) {
          console.error('Transcription error:', innerErr);
          alert(`Transcription error: ${innerErr.message || 'Error processing audio'}`);
          setIsTranscribing(false);
        }
      };
    } catch (err: any) {
      console.error('Transcription file read error:', err);
      alert(`Transcription error: ${err.message || 'Failed to read audio file'}`);
      setIsTranscribing(false);
    }
  };

  // Attach recorded audio directly to prompt
  const attachAudioToPrompt = () => {
    if (!audioBlob) return;
    triggerSuccess();
    const reader = new FileReader();
    reader.readAsDataURL(audioBlob);
    reader.onloadend = () => {
      const base64Data = (reader.result as string).split(',')[1];
      const mimeType = audioBlob.type || 'audio/webm';
      const audioAttachment: FileAttachment = {
        id: `voice-${Date.now()}`,
        name: `AudioNote-${new Date().toLocaleTimeString().replace(/:/g, '-')}.webm`,
        type: mimeType,
        mimeType: mimeType,
        size: audioBlob.size,
        data: base64Data,
        previewUrl: audioUrl || undefined,
        typeCategory: 'audio',
      };
      onAddAttachment(audioAttachment);
      onClose();
    };
  };

  // --- Photo & Document File Handlers ---
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    triggerSuccess();

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        const isImage = file.type.startsWith('image/');
        const newAttachment: FileAttachment = {
          id: `file-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          name: file.name,
          type: file.type || 'application/octet-stream',
          mimeType: file.type || 'application/octet-stream',
          size: file.size,
          data: base64String,
          previewUrl: isImage ? (reader.result as string) : undefined,
          typeCategory: isImage ? 'image' : 'document',
        };
        onAddAttachment(newAttachment);
      };
      reader.readAsDataURL(file);
    });

    onClose();
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const getHeaderInfo = () => {
    switch (activeTab) {
      case 'audio':
        return {
          title: 'ARUCH Voice & Speech Studio',
          subtitle: 'Record audio, dictate thoughts, or speak directly for instant AI transcription and voice processing.',
        };
      case 'camera':
        return {
          title: 'ARUCH Camera & Vision Scanner',
          subtitle: 'Snap photos instantly to analyze homework, objects, or surroundings using AI vision.',
        };
      case 'photos':
        return {
          title: 'ARUCH Image Gallery & Vision Analysis',
          subtitle: 'Upload photos, screenshots, or diagrams for deep visual inspection and multimodal analysis.',
        };
      case 'documents':
        return {
          title: 'ARUCH Document & Code Inspector',
          subtitle: 'Upload PDF reports, scripts, or datasets for deep technical review and code debugging.',
        };
    }
  };

  const { title: currentTitle, subtitle: currentSubtitle } = getHeaderInfo();

  return (
    <BottomSheet
      isOpen={isOpen}
      onClose={onClose}
      title={currentTitle}
      subtitle={currentSubtitle}
      icon={<Sparkles size={20} />}
      maxHeight="max-h-[85vh]"
    >
      {/* Top Tab Bar */}
      <div className="flex gap-2 border-b border-[#28292a] pb-3 mb-4 overflow-x-auto">
        {[
          { id: 'audio', label: 'Voice & Speech', icon: <Mic size={15} /> },
          { id: 'camera', label: 'Camera Snap', icon: <Camera size={15} /> },
          { id: 'photos', label: 'Images & Photos', icon: <ImageIcon size={15} /> },
          { id: 'documents', label: 'Code & Docs', icon: <FileCode size={15} /> },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              triggerSelection();
              setActiveTab(tab.id as TabMode);
            }}
            className={cn(
              'flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold transition-all',
              activeTab === tab.id
                ? 'bg-[#9333ea] text-white shadow-md'
                : 'bg-[#28292a] text-[#8e918f] hover:bg-[#333537] hover:text-[#e3e3e3]'
            )}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: Live Voice Recording & Transcription */}
      {activeTab === 'audio' && (
        <div className="flex flex-col items-center justify-center py-4 text-center">
          {/* Recording Visualizer or Status */}
          <div className="relative mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-[#18191a] border border-[#3c4043] shadow-2xl">
            {isRecording ? (
              <div className="relative flex items-center justify-center">
                <span className="absolute inline-flex h-24 w-24 animate-ping rounded-full bg-[#ea4335] opacity-25" />
                <button
                  type="button"
                  onClick={stopRecording}
                  className="relative z-10 flex h-20 w-20 items-center justify-center rounded-full bg-[#ea4335] text-white shadow-lg transition-transform hover:scale-105"
                  title="Stop recording"
                >
                  <Square size={28} fill="currentColor" />
                </button>
              </div>
            ) : audioBlob ? (
              <button
                type="button"
                onClick={togglePlayAudio}
                className="flex h-20 w-20 items-center justify-center rounded-full bg-[#9333ea] text-white shadow-lg transition-transform hover:scale-105"
                title="Play recording"
              >
                {isPlayingAudio ? <Pause size={28} /> : <Play size={28} className="ml-1" fill="currentColor" />}
              </button>
            ) : (
              <button
                type="button"
                onClick={startRecording}
                className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-tr from-[#9333ea] to-[#4285f4] text-white shadow-lg transition-transform hover:scale-105 active:scale-95"
                title="Start recording voice"
              >
                <Mic size={32} />
              </button>
            )}
          </div>

          {/* Status Label & Timer */}
          <div className="mb-6 flex flex-col items-center gap-1">
            <span className="text-xl font-bold font-mono tracking-wider text-[#e3e3e3]">
              {formatSeconds(recordingDuration)}
            </span>
            <span className="text-xs text-[#8e918f]">
              {isRecording
                ? 'Recording audio... Speak clearly into your mic.'
                : audioBlob
                ? 'Recording ready. Transcribe, translate, or attach.'
                : 'Tap microphone to start recording speech'}
            </span>
          </div>

          {/* Actions when audio is recorded */}
          {audioBlob && !isRecording && (
            <div className="w-full max-w-md flex flex-col gap-3">
              {/* Translation Target Selector */}
              <div className="flex items-center justify-between rounded-xl bg-[#18191a] border border-[#3c4043] p-3 text-xs">
                <div className="flex items-center gap-2 text-[#8e918f]">
                  <Globe size={14} className="text-[#a855f7]" />
                  <span className="font-medium">Translate Target:</span>
                </div>
                <select
                  id="transcribe-target-language"
                  value={transcribeTargetLang}
                  onChange={(e) => {
                    triggerSelection();
                    setTranscribeTargetLang(e.target.value);
                  }}
                  className="rounded-lg bg-[#28292a] px-3 py-1.5 text-xs font-semibold text-[#e3e3e3] border border-[#3c4043] focus:border-[#9333ea] outline-none cursor-pointer"
                >
                  {AUDIO_TRANSLATION_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.nativeLabel}
                    </option>
                  ))}
                </select>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* Translate & Send Button (Primary when a language is selected) */}
                <button
                  type="button"
                  id="btn-translate-and-send"
                  disabled={isTranscribing}
                  onClick={() => handleTranscribeAndSend('translate')}
                  className="flex items-center justify-center gap-2 rounded-xl bg-[#9333ea] px-4 py-3 text-xs font-semibold text-white shadow-md hover:bg-[#7e22ce] transition-all disabled:opacity-50 cursor-pointer"
                >
                  {isTranscribing ? <Loader2 size={14} className="animate-spin" /> : <Globe size={14} />}
                  <span>
                    Translate to{' '}
                    {AUDIO_TRANSLATION_LANGUAGES.find((l) => l.code === transcribeTargetLang)?.name || 'Target'}{' '}
                    & Send
                  </span>
                </button>

                {/* Transcribe Verbatim (Original Speech) */}
                <button
                  type="button"
                  id="btn-transcribe-verbatim"
                  disabled={isTranscribing}
                  onClick={() => handleTranscribeAndSend('verbatim')}
                  className="flex items-center justify-center gap-2 rounded-xl bg-[#28292a] border border-[#3c4043] px-4 py-3 text-xs font-semibold text-[#d8b4fe] hover:bg-[#333537] hover:border-[#9333ea] transition-all disabled:opacity-50 cursor-pointer"
                >
                  {isTranscribing ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                  <span>Transcribe Original</span>
                </button>
              </div>

              <div className="flex items-center justify-between gap-2 pt-1">
                <button
                  type="button"
                  onClick={attachAudioToPrompt}
                  className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-[#3c4043] bg-[#18191a] py-2.5 text-xs font-medium text-[#c4c7c5] hover:bg-[#28292a]"
                >
                  <Upload size={13} />
                  <span>Attach Audio to Prompt</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    triggerWarning();
                    setAudioBlob(null);
                    setAudioUrl(null);
                    setRecordingDuration(0);
                  }}
                  className="flex items-center justify-center rounded-xl border border-[#ea4335]/30 bg-[#ea4335]/10 p-2.5 text-xs text-[#ea4335] hover:bg-[#ea4335]/20"
                  title="Discard recording"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Camera Capture */}
      {activeTab === 'camera' && (
        <div className="flex flex-col items-center justify-center py-2">
          {cameraError ? (
            <div className="flex flex-col items-center justify-center p-8 text-center text-[#ea4335] bg-[#18191a] rounded-2xl border border-[#ea4335]/30">
              <Camera size={36} className="mb-2 opacity-80" />
              <p className="text-sm font-semibold">{cameraError}</p>
              <button
                type="button"
                onClick={() => {
                  triggerMedium();
                  startCamera();
                }}
                className="mt-4 flex items-center gap-2 rounded-xl bg-[#28292a] px-4 py-2 text-xs text-white"
              >
                <RefreshCw size={13} />
                <span>Retry Camera</span>
              </button>
            </div>
          ) : capturedImage ? (
            <div className="flex flex-col items-center gap-4 w-full max-w-md">
              <img
                src={capturedImage}
                alt="Captured Snap"
                className="h-64 w-full rounded-2xl object-cover border border-[#3c4043] shadow-lg"
              />
              <div className="flex w-full gap-3">
                <button
                  type="button"
                  onClick={() => {
                    triggerWarning();
                    setCapturedImage(null);
                  }}
                  className="flex-1 rounded-xl border border-[#3c4043] bg-[#28292a] py-3 text-xs font-medium text-[#e3e3e3] hover:bg-[#333537]"
                >
                  Retake Photo
                </button>
                <button
                  type="button"
                  onClick={attachCapturedImage}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-[#9333ea] py-3 text-xs font-semibold text-white hover:bg-[#7e22ce]"
                >
                  <Check size={14} />
                  <span>Attach Snapshot</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4 w-full max-w-md">
              <div className="relative overflow-hidden rounded-2xl border border-[#3c4043] bg-black h-72 w-full flex items-center justify-center shadow-lg">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={cn(
                    'h-full w-full object-cover transition-transform duration-300',
                    facingMode === 'user' && 'scale-x-[-1]'
                  )}
                />

                {/* Top-Left Camera Mode Status Badge */}
                <div className="absolute top-3 left-3 z-20 flex items-center gap-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/15 px-2.5 py-1 text-[11px] font-medium text-white shadow-md">
                  <span className="h-2 w-2 rounded-full bg-[#34a853] animate-pulse" />
                  <span>{facingMode === 'user' ? 'កាមេរ៉ាមុខ (Front)' : 'កាមេរ៉ាក្រោយ (Back)'}</span>
                </div>

                {/* Corner Switch Camera Button inside the frame */}
                <button
                  type="button"
                  onClick={toggleFacingMode}
                  disabled={isSwitchingCamera}
                  className="absolute top-3 right-3 z-20 flex items-center gap-1.5 rounded-full bg-black/60 hover:bg-black/85 backdrop-blur-md border border-white/20 px-3 py-1.5 text-xs font-semibold text-white active:scale-95 transition-all shadow-lg cursor-pointer disabled:opacity-50"
                  title="ប្តូរកាមេរ៉ា (Switch Front/Back Camera)"
                >
                  <SwitchCamera size={15} className={cn('text-[#c084fc]', isSwitchingCamera && 'animate-spin')} />
                  <span className="text-[11.5px]">ប្តូរកាមេរ៉ា</span>
                </button>

                {/* Bottom-right mini rotate indicator */}
                <button
                  type="button"
                  onClick={toggleFacingMode}
                  className="absolute bottom-3 right-3 z-20 flex h-9 w-9 items-center justify-center rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white active:scale-90 transition-all shadow-md cursor-pointer"
                  title="Flip camera"
                >
                  <RotateCcw size={15} className="text-[#e3e3e3]" />
                </button>
              </div>

              {/* Shutter Action Bar */}
              <div className="flex items-center justify-center gap-4 w-full pt-1">
                {/* Secondary Flip Button */}
                <button
                  type="button"
                  onClick={toggleFacingMode}
                  disabled={isSwitchingCamera}
                  className="flex h-12 w-12 items-center justify-center rounded-full bg-[#28292a] border border-[#3c4043] text-white hover:bg-[#333537] hover:border-[#9333ea] active:scale-90 transition-all shadow-md cursor-pointer"
                  title="ប្តូរកាមេរ៉ាមុខ / ក្រោយ"
                >
                  <SwitchCamera size={20} className={cn('text-[#c084fc]', isSwitchingCamera && 'animate-spin')} />
                </button>

                {/* Shutter Button */}
                <button
                  type="button"
                  onClick={takeSnapshot}
                  className="flex items-center gap-2 rounded-full bg-white px-7 py-3.5 text-xs font-bold text-black shadow-xl hover:bg-gray-200 active:scale-95 transition-all cursor-pointer"
                >
                  <Camera size={16} />
                  <span>ថតរូប (Snap Photo)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Images & Photos Upload */}
      {activeTab === 'photos' && (
        <div className="flex flex-col items-center justify-center py-4">
          <input
            ref={photoInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileUpload}
            className="hidden"
          />

          <div
            onClick={() => {
              triggerLight();
              photoInputRef.current?.click();
            }}
            className="flex flex-col items-center justify-center w-full max-w-lg rounded-3xl border-2 border-dashed border-[#3c4043] bg-[#18191a] p-8 text-center cursor-pointer hover:border-[#9333ea] hover:bg-[#1e1f20] transition-all"
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#9333ea]/15 text-[#c084fc] border border-[#9333ea]/30 mb-3">
              <ImageIcon size={30} />
            </div>
            <h4 className="text-sm font-semibold text-[#e3e3e3]">Upload Photos & Images</h4>
            <p className="text-xs text-[#8e918f] mt-1 max-w-xs">
              Drag & drop images here or click to browse. Supports PNG, JPG, WebP, GIF for multimodal vision analysis.
            </p>
            <span className="mt-4 rounded-xl bg-[#28292a] px-4 py-2 text-xs font-medium text-[#d8b4fe] border border-[#3c4043]">
              Browse Images
            </span>
          </div>
        </div>
      )}

      {/* TAB 4: Code & Documents */}
      {activeTab === 'documents' && (
        <div className="flex flex-col items-center justify-center py-4">
          <input
            ref={docInputRef}
            type="file"
            accept=".pdf,.txt,.md,.json,.js,.ts,.tsx,.jsx,.py,.html,.css,.csv"
            multiple
            onChange={handleFileUpload}
            className="hidden"
          />

          <div
            onClick={() => {
              triggerLight();
              docInputRef.current?.click();
            }}
            className="flex flex-col items-center justify-center w-full max-w-lg rounded-3xl border-2 border-dashed border-[#3c4043] bg-[#18191a] p-8 text-center cursor-pointer hover:border-[#9333ea] hover:bg-[#1e1f20] transition-all"
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#4285f4]/15 text-[#4285f4] border border-[#4285f4]/30 mb-3">
              <FileCode size={30} />
            </div>
            <h4 className="text-sm font-semibold text-[#e3e3e3]">Upload Code & Documents</h4>
            <p className="text-xs text-[#8e918f] mt-1 max-w-xs">
              Upload PDF reports, TypeScript/Python scripts, Markdown docs, or CSV datasets for deep AI inspection.
            </p>
            <span className="mt-4 rounded-xl bg-[#28292a] px-4 py-2 text-xs font-medium text-[#a8c7fa] border border-[#3c4043]">
              Browse Files
            </span>
          </div>
        </div>
      )}
    </BottomSheet>
  );
}
