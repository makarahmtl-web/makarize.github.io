import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronDown } from 'lucide-react';
import { cn } from '../lib/utils';
import { useHaptic } from '../lib/useHaptic';

interface BottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  icon?: React.ReactNode;
  children: React.ReactNode;
  maxHeight?: string; // e.g. 'max-h-[85vh]', 'max-h-[92vh]'
  className?: string;
  showHandle?: boolean;
  footer?: React.ReactNode;
  headerAction?: React.ReactNode;
}

export default function BottomSheet({
  isOpen,
  onClose,
  title,
  subtitle,
  icon,
  children,
  maxHeight = 'max-h-[88vh]',
  className = '',
  showHandle = true,
  footer,
  headerAction,
}: BottomSheetProps) {
  const sheetRef = useRef<HTMLDivElement>(null);
  const prevIsOpenRef = useRef(false);
  const { triggerSheetOpen, triggerSheetClose, triggerLight } = useHaptic();

  // Trigger haptic pulse when sheet slides up or dismisses
  useEffect(() => {
    if (isOpen && !prevIsOpenRef.current) {
      triggerSheetOpen();
    } else if (!isOpen && prevIsOpenRef.current) {
      triggerSheetClose();
    }
    prevIsOpenRef.current = isOpen;
  }, [isOpen, triggerSheetOpen, triggerSheetClose]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        triggerSheetClose();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, triggerSheetClose]);

  // Lock body scroll when open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleBackdropClick = () => {
    triggerSheetClose();
    onClose();
  };

  const handleCloseButtonClick = () => {
    triggerSheetClose();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end isolate">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            onClick={handleBackdropClick}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
            aria-hidden="true"
          />

          {/* Slide-Up Bottom Sheet Container */}
          <motion.div
            ref={sheetRef}
            initial={{ y: '100%', opacity: 0.8 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0.8 }}
            transition={{
              type: 'spring',
              damping: 28,
              stiffness: 300,
              mass: 0.8,
            }}
            className={cn(
              'relative z-10 mx-auto flex w-full max-w-3xl flex-col rounded-t-[28px] border-t border-x border-[#3c4043] bg-[#1e1f20] text-[#e3e3e3] shadow-2xl',
              maxHeight,
              className
            )}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0.05, bottom: 0.6 }}
            onDragStart={() => triggerLight()}
            onDragEnd={(_, info) => {
              if (info.offset.y > 100 || info.velocity.y > 500) {
                triggerSheetClose();
                onClose();
              }
            }}
          >
            {/* Top Drag Handle */}
            {showHandle && (
              <div className="flex w-full items-center justify-center pt-3 pb-1 cursor-grab active:cursor-grabbing">
                <div className="h-1.5 w-12 rounded-full bg-[#5f6368]/80 hover:bg-[#8e918f] transition-colors" />
              </div>
            )}

            {/* Header */}
            {(title || subtitle || icon || headerAction) && (
              <div className="flex items-center justify-between border-b border-[#28292a] px-6 py-3.5">
                <div className="flex items-center gap-3 min-w-0">
                  {icon && (
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#28292a] text-[#c084fc] border border-[#3c4043]/50">
                      {icon}
                    </div>
                  )}
                  <div className="flex flex-col min-w-0">
                    {title && (
                      <h3 className="text-base font-bold tracking-tight text-[#e3e3e3]">
                        {title}
                      </h3>
                    )}
                    {subtitle && (
                      <p className="text-xs text-[#8e918f] leading-snug">
                        {subtitle}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {headerAction}
                  <button
                    type="button"
                    onClick={handleCloseButtonClick}
                    className="flex h-8 w-8 items-center justify-center rounded-full text-[#8e918f] hover:bg-[#28292a] hover:text-[#e3e3e3] transition-colors"
                    title="Close sheet"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>
            )}

            {/* Content Scroll Body */}
            <div className="flex-1 overflow-y-auto overscroll-contain px-6 py-4">
              {children}
            </div>

            {/* Footer */}
            {footer && (
              <div className="border-t border-[#28292a] bg-[#18191a] px-6 py-3.5 rounded-b-none">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
