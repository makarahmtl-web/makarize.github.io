import React, { useState } from 'react';
import {
  Palette,
  Type,
  Mic,
  Vibrate,
  Clock,
  Lock,
  Share2,
  LogOut,
  Check,
  Play,
  Volume2,
  Sparkles,
  Globe,
  Trash2,
  Sliders,
  Shield,
  Cpu,
  Languages,
  Smartphone,
  Key,
  ChevronRight,
  Scale,
  UserX,
  Sun,
  Moon,
  Monitor,
} from 'lucide-react';
import BottomSheet from './BottomSheet';
import ApiSettings from './ApiSettings';
import { AppSettings } from '../types';
import { User } from '../lib/firebase';
import { cn } from '../lib/utils';
import MakarizeLogo from './MakarizeLogo';
import { useHaptic } from '../lib/useHaptic';
import { SUPPORTED_LANGUAGES, t } from '../lib/i18n';
import { applyTheme, resolveTheme, THEMES, ThemeMode } from '../lib/theme';

interface SettingsBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onSignOut: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearHistory: () => void;
  onOpenLegal?: (tab: 'privacy' | 'terms') => void;
  onOpenDeleteAccount?: () => void;
}

type TabType =
  | 'language'
  | 'appearance'
  | 'capabilities'
  | 'voice'
  | 'permissions'
  | 'focus'
  | 'privacy'
  | 'apiKeys';

export default function SettingsBottomSheet({
  isOpen,
  onClose,
  user,
  onSignOut,
  settings,
  onUpdateSettings,
  onClearHistory,
  onOpenLegal,
  onOpenDeleteAccount,
}: SettingsBottomSheetProps) {
  const currentLang = settings.language || 'km';
  const [activeTab, setActiveTab] = useState<TabType>('language');
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);
  const [showClearSuccess, setShowClearSuccess] = useState(false);
  const [hapticTested, setHapticTested] = useState(false);

  const {
    triggerSelection,
    triggerMedium,
    triggerHeavy,
    triggerSuccess,
    triggerWarning,
    triggerError,
    triggerLight,
    isSupported: isHapticSupported,
  } = useHaptic(settings.hapticFeedback ?? true);

  const testHapticPattern = (pattern: 'light' | 'medium' | 'heavy' | 'success' | 'warning') => {
    if (pattern === 'light') triggerLight();
    else if (pattern === 'medium') triggerMedium();
    else if (pattern === 'heavy') triggerHeavy();
    else if (pattern === 'success') triggerSuccess();
    else if (pattern === 'warning') triggerWarning();

    setHapticTested(true);
    setTimeout(() => setHapticTested(false), 1200);
  };

  const playVoiceSample = (voiceName: string) => {
    triggerLight();
    setPlayingVoice(voiceName);
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(
          `Hello ${user.displayName?.split(' ')[0] || 'there'}, this is Makarize AI with ${voiceName} voice tone.`
        );
        utterance.rate = voiceName === 'Puck' ? 1.05 : voiceName === 'Fenrir' ? 0.9 : 1.0;
        utterance.pitch = voiceName === 'Kore' || voiceName === 'Aoede' ? 1.15 : 0.95;
        utterance.onend = () => setPlayingVoice(null);
        utterance.onerror = () => setPlayingVoice(null);
        window.speechSynthesis.speak(utterance);
      } else {
        setTimeout(() => setPlayingVoice(null), 1500);
      }
    } catch {
      setTimeout(() => setPlayingVoice(null), 1500);
    }
  };

  const menuItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'language', label: t('tabLanguage', currentLang), icon: <Languages size={15} /> },
    { id: 'appearance', label: t('tabAppearance', currentLang), icon: <Palette size={15} /> },
    { id: 'capabilities', label: t('tabCapabilities', currentLang), icon: <Cpu size={15} /> },
    { id: 'apiKeys', label: 'API Keys', icon: <Key size={15} /> },
    { id: 'voice', label: t('tabVoice', currentLang), icon: <Mic size={15} /> },
    { id: 'permissions', label: t('tabPermissions', currentLang), icon: <Shield size={15} /> },
    { id: 'focus', label: t('tabFocus', currentLang), icon: <Clock size={15} /> },
    { id: 'privacy', label: t('tabPrivacy', currentLang), icon: <Lock size={15} /> },
  ];

  return (
    <BottomSheet
      isOpen={isOpen}
      onClose={onClose}
      title={t('settingsTitle', currentLang)}
      subtitle={t('settingsSubtitle', currentLang)}
      icon={<MakarizeLogo size={22} />}
      maxHeight="max-h-[88vh]"
      footer={
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-[#8e918f]">
            <Globe size={13} className="text-[#a855f7]" />
            <span className="truncate">gen-lang-client-0341340527.firebaseapp.com</span>
          </div>

          <button
            type="button"
            onClick={() => {
              triggerWarning();
              onClose();
              onSignOut();
            }}
            className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-[#ea4335] px-5 py-2.5 text-xs font-semibold text-white transition-all hover:bg-[#d93025] shadow-md cursor-pointer"
          >
            <LogOut size={14} />
            <span>{t('signOut', currentLang)}</span>
          </button>
        </div>
      }
    >
      {/* Main Vertical Stack Container */}
      <div className="flex flex-col gap-4">
        {/* 1. Profile info card */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl bg-[#18191a] border border-[#3c4043] p-4 shadow-sm">
          <div className="flex items-center gap-3">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt="User"
                className="h-11 w-11 rounded-full object-cover border border-[#5f6368]"
              />
            ) : (
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-tr from-[#9333ea] to-[#4285f4] text-base font-bold text-white shadow-sm">
                {user.displayName ? user.displayName.charAt(0).toUpperCase() : 'M'}
              </div>
            )}
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-bold text-[#e3e3e3] truncate">{user.displayName || 'Mr.Makara'}</span>
              <span className="text-xs text-[#8e918f] truncate">{user.email || 'makarahmtl@gmail.com'}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Quick Light / Dark Theme Switcher Button */}
            <div className="flex items-center gap-1 bg-[#121315] p-1 rounded-full border border-[#333537] shadow-inner">
              <button
                type="button"
                id="btn-quick-theme-light"
                onClick={() => {
                  triggerSelection();
                  onUpdateSettings({ colorMode: 'light' });
                  applyTheme('light');
                }}
                className={cn(
                  'flex h-7 w-7 items-center justify-center rounded-full transition-all cursor-pointer',
                  settings.colorMode === 'light'
                    ? 'bg-amber-500 text-black shadow-md font-bold'
                    : 'text-[#8e918f] hover:text-white'
                )}
                title={currentLang === 'km' ? 'ប្ដូរទៅ Light Mode (ភ្លឺ)' : 'Switch to Light Mode'}
              >
                <Sun size={14} />
              </button>

              <button
                type="button"
                id="btn-quick-theme-dark"
                onClick={() => {
                  triggerSelection();
                  onUpdateSettings({ colorMode: 'dark' });
                  applyTheme('dark');
                }}
                className={cn(
                  'flex h-7 w-7 items-center justify-center rounded-full transition-all cursor-pointer',
                  settings.colorMode === 'dark' || !settings.colorMode
                    ? 'bg-purple-600 text-white shadow-md font-bold'
                    : 'text-[#8e918f] hover:text-white'
                )}
                title={currentLang === 'km' ? 'ប្ដូរទៅ Dark Mode (ងងឹត)' : 'Switch to Dark Mode'}
              >
                <Moon size={14} />
              </button>
            </div>

            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#9333ea]/20 border border-[#9333ea]/30 px-3 py-1 text-[11px] font-semibold text-[#d8b4fe]">
              <Sparkles size={11} className="text-[#c084fc]" />
              <span>Makarize Pro</span>
            </span>
          </div>
        </div>

        {/* 2. Vertical Option Groups / Category Navigation */}
        <div className="flex flex-col gap-2 rounded-2xl bg-[#18191a] border border-[#3c4043] p-2.5">
          <span className="px-2 pt-1 text-[11px] font-bold uppercase tracking-wider text-[#a855f7]">
            Preference Categories
          </span>
          <div className="flex flex-col gap-1.5">
            {menuItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  triggerSelection();
                  setActiveTab(item.id);
                }}
                className={cn(
                  'flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-semibold transition-all text-left w-full cursor-pointer',
                  activeTab === item.id
                    ? 'bg-[#9333ea] text-white shadow-md'
                    : 'bg-[#1f2022] text-[#8e918f] hover:bg-[#28292a] hover:text-[#e3e3e3] border border-[#333537]'
                )}
              >
                <div className="flex items-center gap-2.5">
                  <span className={activeTab === item.id ? 'text-white' : 'text-[#a855f7]'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </div>
                {activeTab === item.id && (
                  <Check size={14} className="text-white" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* 3. Unified Card for Selected Category Content */}
        <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-4 sm:p-5 shadow-sm">
          <div className="mb-4 pb-2 border-b border-[#28292a] flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#e3e3e3] flex items-center gap-2">
              <span className="text-[#c084fc]">
                {menuItems.find((m) => m.id === activeTab)?.icon}
              </span>
              <span>{menuItems.find((m) => m.id === activeTab)?.label}</span>
            </h3>
            <span className="text-[10px] text-[#8e918f] font-mono">Panel</span>
          </div>

      {/* TAB 0: Language & Region */}
      {activeTab === 'language' && (
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-1">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#a855f7]">
              {t('selectLanguage', currentLang)}
            </h4>
            <p className="text-xs text-[#8e918f]">
              {t('languageDesc', currentLang)}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {SUPPORTED_LANGUAGES.map((lang) => {
              const isSelected = currentLang === lang.code;
              return (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => {
                    triggerSuccess();
                    onUpdateSettings({ language: lang.code });
                  }}
                  className={cn(
                    'flex items-center justify-between rounded-2xl border p-3.5 transition-all text-left cursor-pointer',
                    isSelected
                      ? 'border-[#c084fc] bg-[#9333ea]/20 shadow-md ring-1 ring-[#c084fc]'
                      : 'border-[#3c4043] bg-[#1f2022] hover:border-[#5f6368] hover:bg-[#28292a]'
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl leading-none">{lang.flag}</span>
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-[#e3e3e3] leading-snug">
                        {lang.name}
                      </span>
                      <span className="text-xs text-[#8e918f] font-medium">
                        {lang.englishName}
                      </span>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#9333ea] text-white shadow-sm">
                      <Check size={14} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 1: Appearance & Typography */}
      {activeTab === 'appearance' && (
        <div className="flex flex-col gap-6">
          {/* Primary Light / Dark Mode Master Toggle */}
          <div className="flex flex-col gap-2 rounded-2xl bg-[#1f2024] border border-[#333537] p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#9333ea]/20 text-[#c084fc]">
                  {settings.colorMode === 'light' ? <Sun size={18} /> : <Moon size={18} />}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#e3e3e3]">
                    {currentLang === 'km' ? 'ប្ដូររូបរាង (Theme Mode Toggle)' : 'Theme Mode Switcher'}
                  </h4>
                  <p className="text-[11px] text-[#8e918f]">
                    {currentLang === 'km'
                      ? 'ប្ដូររវាង Dark Mode និង Light Mode (ធ្វើបច្ចុប្បន្នភាព CSS Variables ភ្លាមៗ)'
                      : 'Switch instantly between Dark and Light mode (updates CSS variables)'}
                  </p>
                </div>
              </div>

              {/* Toggle Switch Component */}
              <div className="inline-flex rounded-xl bg-[#141518] p-1 border border-[#2e3035] shadow-inner">
                <button
                  type="button"
                  id="btn-theme-toggle-light"
                  onClick={() => {
                    triggerSelection();
                    onUpdateSettings({ colorMode: 'light' });
                    applyTheme('light');
                  }}
                  className={cn(
                    'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all cursor-pointer',
                    settings.colorMode === 'light'
                      ? 'bg-amber-400 text-slate-900 shadow-md ring-1 ring-amber-300'
                      : 'text-[#8e918f] hover:text-[#e3e3e3]'
                  )}
                >
                  <Sun size={13} />
                  <span>Light</span>
                </button>

                <button
                  type="button"
                  id="btn-theme-toggle-dark"
                  onClick={() => {
                    triggerSelection();
                    onUpdateSettings({ colorMode: 'dark' });
                    applyTheme('dark');
                  }}
                  className={cn(
                    'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all cursor-pointer',
                    settings.colorMode === 'dark' || !settings.colorMode
                      ? 'bg-[#9333ea] text-white shadow-md ring-1 ring-[#c084fc]'
                      : 'text-[#8e918f] hover:text-[#e3e3e3]'
                  )}
                >
                  <Moon size={13} />
                  <span>Dark</span>
                </button>

                <button
                  type="button"
                  id="btn-theme-toggle-system"
                  onClick={() => {
                    triggerSelection();
                    onUpdateSettings({ colorMode: 'system' });
                    applyTheme('system');
                  }}
                  className={cn(
                    'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all cursor-pointer',
                    settings.colorMode === 'system'
                      ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400'
                      : 'text-[#8e918f] hover:text-[#e3e3e3]'
                  )}
                  title="Follow OS System Theme"
                >
                  <Monitor size={13} />
                  <span>Auto</span>
                </button>
              </div>
            </div>

            {/* Active CSS Variable Badge */}
            <div className="mt-2 pt-2 border-t border-[#2a2c30] flex items-center justify-between text-[10px] text-[#8e918f]">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>CSS Variables: Active ({settings.colorMode || 'dark'})</span>
              </span>
              <span className="font-mono text-[#c084fc]">
                --color-background: {THEMES[resolveTheme(settings.colorMode || 'dark')]?.background}
              </span>
            </div>
          </div>

          {/* Color Mode / Themes Grid */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-[#a855f7]">Color Palette Presets</h4>
              <span className="text-[11px] text-[#8e918f]">Selected: {settings.colorMode || 'dark'}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {[
                { id: 'dark', label: 'Obsidian Dark', bg: '#131314', border: '#3c4043' },
                { id: 'purple', label: 'Makarize Violet', bg: 'linear-gradient(135deg, #1e0e33 0%, #3b0764 100%)', border: '#9333ea' },
                { id: 'midnight', label: 'Midnight Navy', bg: '#0b0f19', border: '#1e293b' },
                { id: 'light', label: 'Clean Light', bg: '#f8f9fa', border: '#dadce0' },
                { id: 'system', label: 'System Sync', bg: 'linear-gradient(135deg, #131314 50%, #f8f9fa 50%)', border: '#3c4043' },
              ].map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  id={`btn-theme-palette-${mode.id}`}
                  onClick={() => {
                    triggerSelection();
                    onUpdateSettings({ colorMode: mode.id as any });
                    applyTheme(mode.id as ThemeMode);
                  }}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-2xl border p-3 text-center transition-all cursor-pointer',
                    settings.colorMode === mode.id
                      ? 'border-[#c084fc] bg-[#9333ea]/15 shadow-md ring-1 ring-[#c084fc]'
                      : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368]'
                  )}
                >
                  <div
                    className="h-8 w-full rounded-xl border shadow-inner"
                    style={{ background: mode.bg, borderColor: mode.border }}
                  />
                  <span className="text-[11px] font-medium text-[#e3e3e3]">{mode.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Typography */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-[#a855f7]">Font Style</h4>
              <span className="text-[11px] text-[#8e918f]">Active: {settings.fontStyle}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { id: 'sans', label: 'Inter Sans', sample: 'Makarize' },
                { id: 'modern', label: 'Modern Grotesk', sample: 'Makarize' },
                { id: 'serif', label: 'Editorial Serif', sample: 'Makarize' },
                { id: 'mono', label: 'Code Monospace', sample: '<Code/>' },
              ].map((font) => (
                <button
                  key={font.id}
                  type="button"
                  onClick={() => {
                    triggerSelection();
                    onUpdateSettings({ fontStyle: font.id as any });
                  }}
                  className={cn(
                    'flex flex-col items-center gap-1.5 rounded-2xl border p-3.5 text-center transition-all cursor-pointer',
                    settings.fontStyle === font.id
                      ? 'border-[#c084fc] bg-[#9333ea]/15 shadow-md ring-1 ring-[#c084fc]'
                      : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368]'
                  )}
                >
                  <span className="text-base font-bold text-[#e3e3e3]">{font.sample}</span>
                  <span className="text-[11px] font-medium text-[#8e918f]">{font.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Animated Backgrounds */}
          <div>
            <div className="flex items-center justify-between mb-2 mt-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-[#a855f7]">Animated Backgrounds</h4>
              <span className="text-[11px] text-[#8e918f]">Active: {settings.backgroundMode || 'none'}</span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { id: 'none', label: 'None' },
                { id: 'rain', label: 'Gentle Rain' },
                { id: 'snow', label: 'Soft Snowfall' },
                { id: 'earth', label: 'Cosmic Earth' },
                { id: 'nebula', label: 'Space Nebula' },
                { id: 'grid', label: 'Cyberpunk Grid' },
              ].map((bg) => (
                <button
                  key={bg.id}
                  type="button"
                  onClick={() => {
                    triggerSelection();
                    onUpdateSettings({ backgroundMode: bg.id as any });
                  }}
                  className={cn(
                    'rounded-xl border p-3 text-xs font-medium text-center transition-all cursor-pointer',
                    settings.backgroundMode === bg.id
                      ? 'border-[#c084fc] bg-[#9333ea]/20 text-[#e3e3e3]'
                      : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368] text-[#8e918f]'
                  )}
                >
                  {bg.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Capabilities */}
      {activeTab === 'capabilities' && (
        <div className="flex flex-col gap-3">
          {[
            {
              key: 'codeExecution',
              title: 'Code Execution Sandbox',
              desc: 'Run & test TypeScript and Python snippets in an isolated runtime.',
            },
            {
              key: 'webBrowsing',
              title: 'Live Web Grounding',
              desc: 'Provide fresh online references and verified search citations.',
            },
            {
              key: 'imageGeneration',
              title: 'Multimodal Vision & Analysis',
              desc: 'Process visual inputs, screenshots, and diagrams with high precision.',
            },
            {
              key: 'extendedReasoning',
              title: 'Deep Thinking Mode',
              desc: 'Allocate extra reasoning budget for complex architectural problems.',
            },
          ].map((item) => (
            <div
              key={item.key}
              className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-4"
            >
              <div className="flex flex-col pr-4">
                <span className="text-sm font-semibold text-[#e3e3e3]">{item.title}</span>
                <span className="text-xs text-[#8e918f] mt-0.5">{item.desc}</span>
              </div>
              <label className="relative inline-flex cursor-pointer items-center">
                <input
                  type="checkbox"
                  checked={(settings.capabilities as any)[item.key]}
                  onChange={(e) => {
                    triggerLight();
                    onUpdateSettings({
                      capabilities: {
                        ...settings.capabilities,
                        [item.key]: e.target.checked,
                      },
                    });
                  }}
                  className="peer sr-only"
                />
                <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
              </label>
            </div>
          ))}
        </div>
      )}

      {/* TAB: API Keys */}
      {activeTab === 'apiKeys' && (
        <div className="mt-2">
          <ApiSettings />
        </div>
      )}

      {/* TAB 3: Voice Persona */}
      {activeTab === 'voice' && (
        <div className="flex flex-col gap-3">
          {[
            { id: 'Puck', desc: 'Upbeat, expressive, and lively' },
            { id: 'Charon', desc: 'Calm, authoritative, and steady' },
            { id: 'Kore', desc: 'Warm, clear, and melodious' },
            { id: 'Fenrir', desc: 'Deep, deliberate, and thoughtful' },
            { id: 'Aoede', desc: 'Bright, polished, and friendly' },
          ].map((v) => {
            const isSelected = settings.voice === v.id;
            const isPlaying = playingVoice === v.id;

            return (
              <div
                key={v.id}
                onClick={() => {
                  triggerSelection();
                  onUpdateSettings({ voice: v.id as any });
                }}
                className={cn(
                  'flex items-center justify-between rounded-2xl border p-3.5 transition-all cursor-pointer',
                  isSelected
                    ? 'border-[#c084fc] bg-[#9333ea]/15 ring-1 ring-[#c084fc]'
                    : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368]'
                )}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={cn(
                      'flex h-9 w-9 items-center justify-center rounded-xl',
                      isSelected ? 'bg-[#9333ea] text-white' : 'bg-[#28292a] text-[#8e918f]'
                    )}
                  >
                    <Volume2 size={18} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-semibold text-[#e3e3e3]">{v.id}</span>
                    <span className="text-xs text-[#8e918f]">{v.desc}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    playVoiceSample(v.id);
                  }}
                  className={cn(
                    'flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-all',
                    isPlaying
                      ? 'bg-[#9333ea] text-white animate-pulse'
                      : 'bg-[#28292a] text-[#c4c7c5] hover:bg-[#333537]'
                  )}
                >
                  <Play size={12} fill={isPlaying ? 'currentColor' : 'none'} />
                  {isPlaying ? 'Playing...' : 'Preview'}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 4: Permissions & Haptics */}
      {activeTab === 'permissions' && (
        <div className="flex flex-col gap-3">
          {/* Haptic Feedback Controller Card */}
          <div className="flex flex-col rounded-2xl border border-[#9333ea]/40 bg-[#1e142a] p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#9333ea]/30 text-[#d8b4fe]">
                  <Smartphone size={16} />
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#e3e3e3]">Browser Haptic Feedback</span>
                  <span className="text-xs text-[#8e918f]">
                    Tactile vibration pulses on button clicks & slide-up sheets
                  </span>
                </div>
              </div>
              <label className="relative inline-flex cursor-pointer items-center">
                <input
                  type="checkbox"
                  checked={settings.hapticFeedback ?? true}
                  onChange={(e) => {
                    const nextVal = e.target.checked;
                    if (nextVal) triggerMedium();
                    onUpdateSettings({ hapticFeedback: nextVal });
                  }}
                  className="peer sr-only"
                />
                <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
              </label>
            </div>

            {/* Test Haptic Vibration Patterns */}
            <div className="mt-3.5 pt-3 border-t border-[#3c4043]/40">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#a855f7]">
                Test Vibration Pattern
              </span>
              <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'light', label: 'Light Tap (12ms)' },
                  { id: 'medium', label: 'Medium Impact (25ms)' },
                  { id: 'heavy', label: 'Heavy Action (45ms)' },
                  { id: 'success', label: 'Success Burst' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => testHapticPattern(item.id as any)}
                    className="flex items-center justify-center gap-1.5 rounded-xl border border-[#3c4043] bg-[#28292a] px-2.5 py-2 text-[11px] font-medium text-[#e3e3e3] hover:border-[#9333ea] hover:bg-[#333537] active:scale-95 transition-all"
                  >
                    <Vibrate size={12} className="text-[#c084fc]" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
              <div className="mt-2 text-[10px] text-[#8e918f] flex items-center gap-1">
                <span className={cn('h-1.5 w-1.5 rounded-full', isHapticSupported ? 'bg-emerald-400' : 'bg-amber-400')} />
                <span>
                  {isHapticSupported
                    ? 'navigator.vibrate API detected and ready'
                    : 'Browser requires physical mobile device or vibration support'}
                </span>
              </div>
            </div>
          </div>

          {[
            { key: 'microphone', title: 'Microphone Recording', desc: 'Record audio notes and live voice questions.' },
            { key: 'camera', title: 'Camera Snapshots', desc: 'Capture photos directly from the bottom sheet.' },
            { key: 'clipboard', title: 'Clipboard Copying', desc: 'One-click copy code blocks and outputs.' },
            { key: 'notifications', title: 'Notifications', desc: 'Alert when long AI generation completes.' },
          ].map((perm) => (
            <div
              key={perm.key}
              className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-4"
            >
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-[#e3e3e3]">{perm.title}</span>
                <span className="text-xs text-[#8e918f]">{perm.desc}</span>
              </div>
              <label className="relative inline-flex cursor-pointer items-center">
                <input
                  type="checkbox"
                  checked={(settings.permissions as any)[perm.key]}
                  onChange={(e) => {
                    triggerLight();
                    onUpdateSettings({
                      permissions: {
                        ...settings.permissions,
                        [perm.key]: e.target.checked,
                      },
                    });
                  }}
                  className="peer sr-only"
                />
                <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
              </label>
            </div>
          ))}
        </div>
      )}

      {/* TAB 5: Focus & Timer */}
      {activeTab === 'focus' && (
        <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-5">
          <span className="text-sm font-semibold text-[#e3e3e3]">Pomodoro Focus Sprints</span>
          <p className="text-xs text-[#8e918f] mt-1 mb-4">
            Select your preferred work interval for deep coding sessions.
          </p>
          <div className="grid grid-cols-4 gap-2.5">
            {[15, 25, 45, 60].map((mins) => (
              <button
                key={mins}
                type="button"
                onClick={() => {
                  triggerSelection();
                  onUpdateSettings({ focusDuration: mins });
                }}
                className={cn(
                  'rounded-xl py-2.5 text-xs font-semibold transition-all',
                  settings.focusDuration === mins
                    ? 'bg-[#9333ea] text-white shadow-md'
                    : 'bg-[#28292a] text-[#c4c7c5] hover:bg-[#333537]'
                )}
              >
                {mins} min
              </button>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: Privacy */}
      {activeTab === 'privacy' && (
        <div className="flex flex-col gap-5 overflow-y-auto max-h-[460px] pr-1">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#a855f7] mb-1.5">
              Privacy & Data Confidentiality Statement
            </h4>
            <p className="text-xs text-[#8e918f] leading-relaxed">
              All user chats, history, and personal data processed by ARUCH models are kept strictly confidential and secure. Whether users are students solving homework, business owners analyzing data, or individuals seeking emotional companionship, their privacy is fully protected. Your data, prompts, and conversation histories are never sold, rented, or shared with third parties under any circumstances.
            </p>
          </div>

          <div className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-3.5">
            <div className="flex flex-col pr-3">
              <span className="text-xs font-semibold text-[#e3e3e3]">Telemetry & Diagnostics</span>
              <span className="text-[11px] text-[#8e918f] mt-0.5">
                When disabled, diagnostic telemetry data remains strictly private on your device.
              </span>
            </div>
            <label className="relative inline-flex cursor-pointer items-center shrink-0">
              <input
                type="checkbox"
                checked={settings.dataSharing}
                onChange={(e) => {
                  triggerLight();
                  onUpdateSettings({ dataSharing: e.target.checked });
                }}
                className="peer sr-only"
              />
              <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
            </label>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#a855f7] mb-2">
              App Scope & Capabilities Overview
            </h4>
            <div className="flex flex-col gap-2.5">
              <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-3.5">
                <span className="text-[10px] font-bold text-[#c084fc] uppercase tracking-wider">Free Tier</span>
                <p className="text-xs text-[#e3e3e3] font-medium mt-0.5 mb-1">ARUCH Free Core & Assistants</p>
                <p className="text-[11px] text-[#8e918f] leading-relaxed">
                  Completely free of charge, designed to help students with homework, daily life organization, general problem-solving, and act as a daily emotional companion for listening and chatting.
                </p>
              </div>
              <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-3.5">
                <span className="text-[10px] font-bold text-[#34a853] uppercase tracking-wider">Paid Tiers ($0.50 - $3.00)</span>
                <p className="text-xs text-[#e3e3e3] font-medium mt-0.5 mb-1">Ultra Apex, Supreme Pro, Turbo Elite, Neural V1/V2</p>
                <p className="text-[11px] text-[#8e918f] leading-relaxed">
                  Designed for advanced business strategies, complex coding architectures, market analysis, and high-performance multi-domain problem-solving.
                </p>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#a855f7] mb-2">
              Official Customer Support & Dispute Resolution
            </h4>
            <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-3.5 flex flex-col gap-2">
              <p className="text-[11px] text-[#8e918f] leading-relaxed">
                If you experience any issues with payment verification, model unlocking, or need dispute resolution, you can contact official support directly through:
              </p>
              <div className="flex flex-col gap-1.5 pt-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-[#e3e3e3]">Email:</span>
                  <a href="mailto:ChhuoyMakara@gmail.com" className="text-xs text-[#c084fc] hover:underline">ChhuoyMakara@gmail.com</a>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-[#e3e3e3]">Phone:</span>
                  <a href="tel:0979262838" className="text-xs text-[#c084fc] hover:underline">0979262838 / 077688200</a>
                </div>
              </div>
            </div>
          </div>

          {/* Legal Documentation & Google Play Compliance Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#a855f7] mb-2">
              Legal & Policy Compliance (Google Play)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                id="btn-open-privacy-policy"
                onClick={() => {
                  triggerLight();
                  onClose();
                  if (onOpenLegal) onOpenLegal('privacy');
                  else window.location.href = '/privacy';
                }}
                className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-3.5 text-left hover:border-purple-500/50 hover:bg-[#222326] transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    <Shield size={16} />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-[#f1f3f4] block">Privacy Policy</span>
                    <span className="text-[10px] text-[#8e918f]">គោលការណ៍ឯកជនភាព</span>
                  </div>
                </div>
                <ChevronRight size={15} className="text-[#8e918f] group-hover:text-purple-400 group-hover:translate-x-0.5 transition-all" />
              </button>

              <button
                type="button"
                id="btn-open-terms-of-service"
                onClick={() => {
                  triggerLight();
                  onClose();
                  if (onOpenLegal) onOpenLegal('terms');
                  else window.location.href = '/terms';
                }}
                className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-3.5 text-left hover:border-purple-500/50 hover:bg-[#222326] transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    <Scale size={16} />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-[#f1f3f4] block">Terms of Service</span>
                    <span className="text-[10px] text-[#8e918f]">លក្ខខណ្ឌប្រើប្រាស់</span>
                  </div>
                </div>
                <ChevronRight size={15} className="text-[#8e918f] group-hover:text-purple-400 group-hover:translate-x-0.5 transition-all" />
              </button>
            </div>
          </div>

          {/* Clear History */}
          <div className="flex items-center justify-between rounded-2xl border border-[#ea4335]/30 bg-[#18191a] p-3.5 mt-1">
            <div className="flex flex-col pr-2">
              <span className="text-xs font-semibold text-[#ea4335]">Clear Conversation History</span>
              <span className="text-[11px] text-[#8e918f]">
                {currentLang === 'km'
                  ? 'លុបសារសន្ទនា និងឯកសារទាំងអស់ចេញពី Session បច្ចុប្បន្ន'
                  : 'Delete all active sessions and stored chat history.'}
              </span>
            </div>
            <button
              type="button"
              id="btn-clear-chat-history"
              onClick={() => {
                triggerWarning();
                onClearHistory();
                setShowClearSuccess(true);
                setTimeout(() => setShowClearSuccess(false), 2000);
              }}
              className="flex shrink-0 items-center gap-1.5 rounded-xl border border-[#ea4335] bg-[#ea4335]/15 px-3 py-1.5 text-xs font-semibold text-[#ea4335] hover:bg-[#ea4335] hover:text-white transition-all cursor-pointer"
            >
              <Trash2 size={13} />
              {showClearSuccess ? 'Cleared!' : 'Clear All'}
            </button>
          </div>

          {/* Google Play Compliant Permanent Account Deletion Section */}
          <div className="rounded-2xl border border-red-500/40 bg-gradient-to-br from-red-950/40 via-[#18191a] to-[#18191a] p-4 flex flex-col gap-3 mt-2 shadow-lg">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-red-500/20 text-red-400 border border-red-500/30">
                  <UserX size={20} />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-red-400">
                    {currentLang === 'km' ? 'លុបទិន្នន័យគណនី (Delete Account & Data)' : 'Delete Account & Data'}
                  </span>
                  <span className="text-[11px] text-[#c4c7c5] leading-relaxed mt-0.5">
                    {currentLang === 'km'
                      ? 'លុបគណនី Google Auth, ប្រវត្តិសារ, ឯកសារ, និងការកំណត់ទាំងអស់ជាស្ថាពរពី Firestore Database (ស្តង់ដារ Google Play Store)'
                      : 'Permanently purge your account, Google authentication record, chat archives, and preferences from Cloud Firestore.'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-red-500/20">
              <span className="text-[10px] text-red-300/80 font-medium">
                {currentLang === 'km' ? 'សកម្មភាពនេះមិនអាចត្រឡប់ក្រោយវិញទេ' : 'Permanent & Irreversible'}
              </span>
              <button
                type="button"
                id="btn-trigger-delete-account"
                onClick={() => {
                  triggerWarning();
                  if (onOpenDeleteAccount) {
                    onOpenDeleteAccount();
                  }
                }}
                className="flex items-center gap-1.5 rounded-xl bg-red-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-red-700 transition-all shadow-md shadow-red-600/25 cursor-pointer"
              >
                <UserX size={14} />
                <span>{currentLang === 'km' ? 'លុបគណនី (Delete Account)' : 'Delete Account'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
        </div>
      </div>
    </BottomSheet>
  );
}
