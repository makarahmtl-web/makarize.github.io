import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Sliders,
  Cpu,
  Link as LinkIcon,
  Shield,
  Palette,
  Type,
  Mic,
  Vibrate,
  Clock,
  Lock,
  Share2,
  LogOut,
  Check,
  Play,
  Volume2,
  Sparkles,
  Globe,
  Trash2,
  Languages,
  Key,
} from 'lucide-react';
import { AppSettings } from '../types';
import { User, initFirebase } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { cn } from '../lib/utils';
import MakarizeLogo from './MakarizeLogo';
import ApiSettings from './ApiSettings';
import { SUPPORTED_LANGUAGES, t } from '../lib/i18n';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onSignOut: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearHistory: () => void;
}

type TabType =
  | 'language'
  | 'appearance'
  | 'capabilities'
  | 'connectors'
  | 'permissions'
  | 'voice'
  | 'haptics'
  | 'focus'
  | 'privacy'
  | 'sharedLinks'
  | 'apiKeys';

export default function SettingsModal({
  isOpen,
  onClose,
  user,
  onSignOut,
  settings,
  onUpdateSettings,
  onClearHistory,
}: SettingsModalProps) {
  const currentLang = settings.language || 'km';
  const [activeTab, setActiveTab] = useState<TabType>('language');
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);
  const [showClearSuccess, setShowClearSuccess] = useState(false);

  if (!isOpen) return null;

  const playVoiceSample = (voiceName: string) => {
    setPlayingVoice(voiceName);
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(
          `Hello ${user.displayName?.split(' ')[0] || 'there'}, this is Makarize AI with ${voiceName} voice tone.`
        );
        utterance.rate = voiceName === 'Puck' ? 1.05 : voiceName === 'Fenrir' ? 0.9 : 1.0;
        utterance.pitch = voiceName === 'Kore' || voiceName === 'Aoede' ? 1.15 : 0.95;
        utterance.onend = () => setPlayingVoice(null);
        utterance.onerror = () => setPlayingVoice(null);
        window.speechSynthesis.speak(utterance);
      } else {
        setTimeout(() => setPlayingVoice(null), 1500);
      }
    } catch {
      setTimeout(() => setPlayingVoice(null), 1500);
    }
  };

  const menuItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'language', label: t('tabLanguage', currentLang), icon: <Languages size={18} /> },
    { id: 'appearance', label: t('tabAppearance', currentLang), icon: <Palette size={18} /> },
    { id: 'capabilities', label: t('tabCapabilities', currentLang), icon: <Cpu size={18} /> },
    { id: 'connectors', label: 'Connectors', icon: <LinkIcon size={18} /> },
    { id: 'apiKeys', label: 'API Keys', icon: <Key size={18} /> },
    { id: 'permissions', label: t('tabPermissions', currentLang), icon: <Shield size={18} /> },
    { id: 'voice', label: t('tabVoice', currentLang), icon: <Mic size={18} /> },
    { id: 'haptics', label: 'Haptic feedback', icon: <Vibrate size={18} /> },
    { id: 'focus', label: t('tabFocus', currentLang), icon: <Clock size={18} /> },
    { id: 'privacy', label: t('tabPrivacy', currentLang), icon: <Lock size={18} /> },
    { id: 'sharedLinks', label: 'Shared links', icon: <Share2 size={18} /> },
  ];


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="flex h-[88vh] max-h-[720px] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-[#3c4043] bg-[#1e1f20] shadow-2xl md:flex-row text-[#e3e3e3]"
      >
        {/* Left Settings Sidebar */}
        <div className="flex w-full flex-col justify-between border-b border-[#28292a] bg-[#18191a] p-4 md:w-64 md:border-b-0 md:border-r">
          <div className="flex flex-col gap-2">
            {/* Header Brand */}
            <div className="flex items-center justify-between px-2 pb-2">
              <div className="flex items-center gap-2.5">
                <MakarizeLogo size={26} />
                <div className="flex flex-col">
                  <span className="font-bold text-[#e3e3e3] text-sm">Makarize</span>
                  <span className="text-[10px] text-[#a855f7]">Settings & Theme</span>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="flex h-7 w-7 items-center justify-center rounded-full text-[#8e918f] hover:bg-[#28292a] hover:text-white md:hidden"
              >
                <X size={16} />
              </button>
            </div>


            {/* Nav Tabs - Clean Vertical Stack */}
            <div className="flex flex-col gap-1.5">
              {menuItems.map((item) => (
                <button
                  type="button"
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={cn(
                    'flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-medium transition-all text-left w-full cursor-pointer',
                    activeTab === item.id
                      ? 'bg-[#9333ea]/20 text-[#d8b4fe] border border-[#9333ea]/30 font-semibold'
                      : 'text-[#c4c7c5] hover:bg-[#28292a]/50 hover:text-[#e3e3e3]'
                  )}
                >
                  <span className={activeTab === item.id ? 'text-[#c084fc]' : 'text-[#8e918f]'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* User profile & Log Out in Left Sidebar - Unified Vertical Card */}
          <div className="mt-4 border-t border-[#28292a] pt-3 flex flex-col gap-3">
            <div className="flex items-center gap-2.5 rounded-xl bg-[#141516] border border-[#333537] p-2.5">
              {user.photoURL ? (
                <img src={user.photoURL} alt="User" className="h-9 w-9 rounded-full object-cover border border-[#5f6368]" />
              ) : (
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-tr from-[#9333ea] to-[#4285f4] text-xs font-bold text-white shadow-sm">
                  {user.displayName ? user.displayName.charAt(0).toUpperCase() : 'M'}
                </div>
              )}
              <div className="flex flex-col min-w-0">
                <span className="truncate text-xs font-semibold text-[#e3e3e3]">
                  {user.displayName || 'Mr.Makara'}
                </span>
                <span className="truncate text-[10px] text-[#8e918f]">
                  {user.email || 'makarahmtl@gmail.com'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onSignOut();
              }}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#ea4335]/40 bg-[#ea4335]/15 px-4 py-2.5 text-xs font-semibold text-[#ea4335] transition-all hover:bg-[#ea4335] hover:text-white shadow-sm"
            >
              <LogOut size={14} />
              <span>Log out (Firebase)</span>
            </button>
          </div>
        </div>

        {/* Right Settings Content Area */}
        <div className="flex flex-1 flex-col justify-between overflow-y-auto bg-[#1e1f20] p-6 sm:p-8">
          <div>
            {/* Header with Close */}
            <div className="hidden md:flex items-center justify-between pb-6 border-b border-[#28292a]">
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-semibold text-[#e3e3e3]">
                  {menuItems.find((m) => m.id === activeTab)?.label}
                </h2>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="flex h-8 w-8 items-center justify-center rounded-full text-[#8e918f] hover:bg-[#28292a] hover:text-white transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Tab 0: Language & Region */}
            {activeTab === 'language' && (
              <div className="mt-4 flex flex-col gap-4">
                <div className="flex flex-col gap-1">
                  <h3 className="text-sm font-semibold text-[#e3e3e3]">
                    {t('selectLanguage', currentLang)}
                  </h3>
                  <p className="text-xs text-[#8e918f]">
                    {t('languageDesc', currentLang)}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {SUPPORTED_LANGUAGES.map((lang) => {
                    const isSelected = currentLang === lang.code;
                    return (
                      <button
                        key={lang.code}
                        type="button"
                        onClick={() => onUpdateSettings({ language: lang.code })}
                        className={cn(
                          'flex items-center justify-between rounded-2xl border p-3.5 transition-all text-left cursor-pointer',
                          isSelected
                            ? 'border-[#c084fc] bg-[#9333ea]/20 ring-1 ring-[#c084fc]'
                            : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368]'
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-2xl leading-none">{lang.flag}</span>
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-[#e3e3e3]">
                              {lang.name}
                            </span>
                            <span className="text-xs text-[#8e918f] font-medium">
                              {lang.englishName}
                            </span>
                          </div>
                        </div>

                        {isSelected && (
                          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#9333ea] text-white">
                            <Check size={14} />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tab 1: Appearance & Typography */}
            {activeTab === 'appearance' && (
              <div className="mt-4 flex flex-col gap-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-[#e3e3e3]">Color Theme</h3>
                    <span className="text-[11px] text-[#a855f7] font-medium uppercase tracking-wider">
                      Current: {settings.colorMode}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
                    {[
                      {
                        id: 'dark',
                        label: 'Obsidian Dark',
                        bg: '#131314',
                        border: '#3c4043',
                        badge: 'Default',
                      },
                      {
                        id: 'purple',
                        label: 'Makarize Violet',
                        bg: 'linear-gradient(135deg, #1e0e33 0%, #3b0764 100%)',
                        border: '#9333ea',
                        badge: 'Signature',
                      },
                      {
                        id: 'midnight',
                        label: 'Midnight Navy',
                        bg: '#0b0f19',
                        border: '#1e293b',
                        badge: 'Deep',
                      },
                      {
                        id: 'light',
                        label: 'Clean Light',
                        bg: '#f8f9fa',
                        border: '#dadce0',
                        badge: 'Bright',
                      },
                      {
                        id: 'system',
                        label: 'System Sync',
                        bg: 'linear-gradient(135deg, #131314 50%, #f8f9fa 50%)',
                        border: '#3c4043',
                        badge: 'Auto',
                      },
                    ].map((mode) => (
                      <button
                        key={mode.id}
                        type="button"
                        onClick={() => onUpdateSettings({ colorMode: mode.id as any })}
                        className={cn(
                          'relative flex flex-col items-center gap-2 rounded-2xl border p-3.5 transition-all text-center group cursor-pointer',
                          settings.colorMode === mode.id
                            ? 'border-[#c084fc] bg-[#9333ea]/15 shadow-md ring-1 ring-[#c084fc]'
                            : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368]'
                        )}
                      >
                        <div
                          className="h-10 w-full rounded-xl border shadow-inner transition-transform group-hover:scale-105"
                          style={{ background: mode.bg, borderColor: mode.border }}
                        />
                        <div className="flex flex-col items-center">
                          <span className="text-xs font-medium text-[#e3e3e3]">{mode.label}</span>
                          <span className="text-[9px] text-[#8e918f]">{mode.badge}</span>
                        </div>
                        {settings.colorMode === mode.id && (
                          <div className="absolute top-2 right-2 flex h-4 w-4 items-center justify-center rounded-full bg-[#9333ea] text-white">
                            <Check size={10} />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2 mt-6">
                    <h3 className="text-sm font-semibold text-[#e3e3e3]">Animated Backgrounds</h3>
                    <span className="text-[11px] text-[#a855f7] font-medium uppercase tracking-wider">
                      Current: {settings.backgroundMode || 'none'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                    {[
                      { id: 'none', label: 'None' },
                      { id: 'rain', label: 'Gentle Rain' },
                      { id: 'snow', label: 'Soft Snowfall' },
                      { id: 'matrix', label: 'Cyberpunk Neon Matrix' },
                      { id: 'shooting-stars', label: 'Cosmic Shooting Stars' },
                      { id: 'orbs', label: 'Magic Glowing Orbs' },
                      { id: 'aurora', label: 'Aurora Borealis Wave' },
                      { id: 'sunset', label: 'Sunset Horizon Glow' },
                    ].map((bg) => (
                      <button
                        key={bg.id}
                        type="button"
                        onClick={() => onUpdateSettings({ backgroundMode: bg.id as any })}
                        className={cn(
                          'rounded-xl border p-3 text-xs font-medium text-center transition-all cursor-pointer',
                          settings.backgroundMode === bg.id
                            ? 'border-[#c084fc] bg-[#9333ea]/20 text-[#e3e3e3]'
                            : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368] text-[#8e918f]'
                        )}
                      >
                        {bg.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-[#e3e3e3]">Font Typography</h3>
                    <span className="text-[11px] text-[#a855f7] font-medium uppercase tracking-wider">
                      Current: {settings.fontStyle}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                    {[
                      {
                        id: 'sans',
                        label: 'Inter Sans',
                        sample: 'Makarize',
                        fontFamily: 'Inter, system-ui, sans-serif',
                        desc: 'Clean & readable',
                      },
                      {
                        id: 'modern',
                        label: 'Modern Grotesk',
                        sample: 'Makarize',
                        fontFamily: 'system-ui, -apple-system, sans-serif',
                        desc: 'Dynamic geometric',
                      },
                      {
                        id: 'serif',
                        label: 'Editorial Serif',
                        sample: 'Makarize',
                        fontFamily: 'Georgia, Cambria, serif',
                        desc: 'Refined book typography',
                      },
                      {
                        id: 'mono',
                        label: 'Code Monospace',
                        sample: '<Makarize/>',
                        fontFamily: 'ui-monospace, monospace',
                        desc: 'Developer terminal font',
                      },
                    ].map((font) => (
                      <button
                        key={font.id}
                        type="button"
                        onClick={() => onUpdateSettings({ fontStyle: font.id as any })}
                        className={cn(
                          'relative flex flex-col items-center gap-1.5 rounded-2xl border p-4 transition-all text-center cursor-pointer',
                          settings.fontStyle === font.id
                            ? 'border-[#c084fc] bg-[#9333ea]/15 shadow-md ring-1 ring-[#c084fc]'
                            : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368]'
                        )}
                      >
                        <span
                          className="text-lg font-bold text-[#e3e3e3] my-1"
                          style={{ fontFamily: font.fontFamily }}
                        >
                          {font.sample}
                        </span>
                        <span className="text-xs font-semibold text-[#e3e3e3]">{font.label}</span>
                        <span className="text-[10px] text-[#8e918f]">{font.desc}</span>
                        {settings.fontStyle === font.id && (
                          <div className="absolute top-2 right-2 flex h-4 w-4 items-center justify-center rounded-full bg-[#9333ea] text-white">
                            <Check size={10} />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Capabilities */}
            {activeTab === 'capabilities' && (
              <div className="mt-4 flex flex-col gap-4">
                <p className="text-xs text-[#8e918f]">
                  Control high-performance reasoning and agent tools available to Makarize AI.
                </p>

                <div className="flex flex-col gap-3">
                  {[
                    {
                      key: 'codeExecution',
                      title: 'Code Execution Sandbox',
                      desc: 'Allow Makarize to run and test TypeScript and Python code directly.',
                    },
                    {
                      key: 'webBrowsing',
                      title: 'Live Web Grounding',
                      desc: 'Enable real-time search citations and fresh web facts.',
                    },
                    {
                      key: 'imageGeneration',
                      title: 'Multimodal Image Analysis & Vision',
                      desc: 'Process visual inputs, screenshot review, and image rendering.',
                    },
                    {
                      key: 'extendedReasoning',
                      title: 'Deep Thinking Mode',
                      desc: 'Allocate extra reasoning budget for complex architectural problems.',
                    },
                  ].map((item) => (
                    <div
                      key={item.key}
                      className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-4 transition-colors hover:border-[#5f6368]"
                    >
                      <div className="flex flex-col pr-4">
                        <span className="text-sm font-medium text-[#e3e3e3]">{item.title}</span>
                        <span className="text-xs text-[#8e918f] mt-0.5">{item.desc}</span>
                      </div>
                      <label className="relative inline-flex cursor-pointer items-center">
                        <input
                          type="checkbox"
                          checked={(settings.capabilities as any)[item.key]}
                          onChange={(e) =>
                            onUpdateSettings({
                              capabilities: {
                                ...settings.capabilities,
                                [item.key]: e.target.checked,
                              },
                            })
                          }
                          className="peer sr-only"
                        />
                        <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tab 3: Connectors */}
            {activeTab === 'connectors' && (
              <div className="mt-4 flex flex-col gap-4">
                <p className="text-xs text-[#8e918f]">
                  Connect external workspace tools to seamlessly import context into Makarize conversations.
                </p>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {[
                    { key: 'googleDrive', name: 'Google Drive', desc: 'Docs, Sheets, Slides' },
                    { key: 'github', name: 'GitHub', desc: 'Repositories, PRs, Gists' },
                    { key: 'notion', name: 'Notion', desc: 'Workspace pages & databases' },
                    { key: 'figma', name: 'Figma', desc: 'Design files & component nodes' },
                  ].map((c) => {
                    const isConnected = (settings.connectors as any)[c.key];
                    return (
                      <div
                        key={c.key}
                        className="flex flex-col justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-4.5 transition-colors hover:border-[#5f6368]"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-[#e3e3e3]">{c.name}</span>
                          <span
                            className={cn(
                              'rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider',
                              isConnected
                                ? 'bg-[#34a853]/20 text-[#34a853]'
                                : 'bg-[#8e918f]/20 text-[#8e918f]'
                            )}
                          >
                            {isConnected ? 'Connected' : 'Disconnected'}
                          </span>
                        </div>
                        <p className="text-xs text-[#8e918f] mt-1 mb-3">{c.desc}</p>
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateSettings({
                              connectors: {
                                ...settings.connectors,
                                [c.key]: !isConnected,
                              },
                            })
                          }
                          className={cn(
                            'flex items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-medium transition-all',
                            isConnected
                              ? 'border border-[#3c4043] bg-[#28292a] text-[#c4c7c5] hover:bg-[#333537]'
                              : 'bg-[#9333ea] text-white hover:bg-[#7e22ce]'
                          )}
                        >
                          {isConnected ? 'Disconnect' : 'Connect Account'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tab: API Keys */}
            {activeTab === 'apiKeys' && (
              <div className="mt-4">
                <ApiSettings />
              </div>
            )}

            {/* Tab 4: Permissions */}
            {activeTab === 'permissions' && (
              <div className="mt-4 flex flex-col gap-4">
                <p className="text-xs text-[#8e918f]">
                  Manage device permissions for audio input, snapshots, and alerts.
                </p>

                <div className="flex flex-col gap-3">
                  {[
                    { key: 'microphone', title: 'Microphone', desc: 'Allows voice recording for live queries.' },
                    { key: 'camera', title: 'Camera', desc: 'Allows photo snapshots for visual problem solving.' },
                    { key: 'clipboard', title: 'Clipboard Access', desc: 'One-click copy code blocks and outputs.' },
                    { key: 'notifications', title: 'Desktop Notifications', desc: 'Alert when long reasoning tasks complete.' },
                  ].map((perm) => (
                    <div
                      key={perm.key}
                      className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-4"
                    >
                      <div className="flex flex-col">
                        <span className="text-sm font-medium text-[#e3e3e3]">{perm.title}</span>
                        <span className="text-xs text-[#8e918f]">{perm.desc}</span>
                      </div>
                      <label className="relative inline-flex cursor-pointer items-center">
                        <input
                          type="checkbox"
                          checked={(settings.permissions as any)[perm.key]}
                          onChange={(e) =>
                            onUpdateSettings({
                              permissions: {
                                ...settings.permissions,
                                [perm.key]: e.target.checked,
                              },
                            })
                          }
                          className="peer sr-only"
                        />
                        <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tab 5: Voice persona */}
            {activeTab === 'voice' && (
              <div className="mt-4 flex flex-col gap-4">
                <p className="text-xs text-[#8e918f]">
                  Choose Makarize's audio persona for voice interactions.
                </p>

                <div className="flex flex-col gap-3">
                  {[
                    { id: 'Puck', desc: 'Upbeat, expressive, and lively' },
                    { id: 'Charon', desc: 'Calm, authoritative, and steady' },
                    { id: 'Kore', desc: 'Warm, clear, and melodious' },
                    { id: 'Fenrir', desc: 'Deep, deliberate, and thoughtful' },
                    { id: 'Aoede', desc: 'Bright, polished, and friendly' },
                  ].map((v) => {
                    const isSelected = settings.voice === v.id;
                    const isPlaying = playingVoice === v.id;

                    return (
                      <div
                        key={v.id}
                        onClick={() => onUpdateSettings({ voice: v.id as any })}
                        className={cn(
                          'flex items-center justify-between rounded-2xl border p-4 transition-all cursor-pointer',
                          isSelected
                            ? 'border-[#c084fc] bg-[#9333ea]/15 ring-1 ring-[#c084fc]'
                            : 'border-[#3c4043] bg-[#18191a] hover:border-[#5f6368]'
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={cn(
                              'flex h-9 w-9 items-center justify-center rounded-xl',
                              isSelected ? 'bg-[#9333ea] text-white' : 'bg-[#28292a] text-[#8e918f]'
                            )}
                          >
                            <Volume2 size={18} />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-sm font-semibold text-[#e3e3e3]">{v.id}</span>
                            <span className="text-xs text-[#8e918f]">{v.desc}</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            playVoiceSample(v.id);
                          }}
                          className={cn(
                            'flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-all',
                            isPlaying
                              ? 'bg-[#9333ea] text-white animate-pulse'
                              : 'bg-[#28292a] text-[#c4c7c5] hover:bg-[#333537]'
                          )}
                        >
                          <Play size={12} fill={isPlaying ? 'currentColor' : 'none'} />
                          {isPlaying ? 'Playing...' : 'Preview'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tab 6: Haptics */}
            {activeTab === 'haptics' && (
              <div className="mt-4 flex flex-col gap-4">
                <p className="text-xs text-[#8e918f]">
                  Subtle tactile vibrations on mobile and trackpad click confirmations.
                </p>

                <div className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-4">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-[#e3e3e3]">Enable Haptic Cues</span>
                    <span className="text-xs text-[#8e918f]">
                      Trigger haptics on stream completion and message events.
                    </span>
                  </div>
                  <label className="relative inline-flex cursor-pointer items-center">
                    <input
                      type="checkbox"
                      checked={settings.hapticFeedback}
                      onChange={(e) => onUpdateSettings({ hapticFeedback: e.target.checked })}
                      className="peer sr-only"
                    />
                    <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
                  </label>
                </div>
              </div>
            )}

            {/* Tab 7: Focus & Timer */}
            {activeTab === 'focus' && (
              <div className="mt-4 flex flex-col gap-4">
                <p className="text-xs text-[#8e918f]">
                  Configure built-in Pomodoro productivity timers for deep work sprints.
                </p>

                <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-4">
                  <span className="text-sm font-semibold text-[#e3e3e3]">Focus Sprint Duration</span>
                  <p className="text-xs text-[#8e918f] mt-0.5 mb-3">
                    Select your preferred work interval.
                  </p>
                  <div className="grid grid-cols-4 gap-2">
                    {[15, 25, 45, 60].map((mins) => (
                      <button
                        key={mins}
                        type="button"
                        onClick={() => onUpdateSettings({ focusDuration: mins })}
                        className={cn(
                          'rounded-xl py-2 text-xs font-semibold transition-all',
                          settings.focusDuration === mins
                            ? 'bg-[#9333ea] text-white shadow-md'
                            : 'bg-[#28292a] text-[#c4c7c5] hover:bg-[#333537]'
                        )}
                      >
                        {mins} min
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 8: Privacy & Support */}
            {activeTab === 'privacy' && (
              <div className="mt-4 flex flex-col gap-6 overflow-y-auto max-h-[580px] pr-2">
                <div>
                  <h3 className="text-sm font-semibold text-[#e3e3e3] mb-1">Privacy & Data Confidentiality Statement</h3>
                  <p className="text-xs text-[#8e918f] leading-relaxed">
                    All user chats, history, and personal data processed by ARUCH models are kept strictly confidential and secure. Whether users are students solving homework, business owners analyzing data, or individuals seeking emotional companionship, their privacy is fully protected. Your data, prompts, and conversation histories are never sold, rented, or shared with third parties under any circumstances.
                  </p>
                </div>

                <div className="flex items-center justify-between rounded-2xl border border-[#3c4043] bg-[#18191a] p-4">
                  <div className="flex flex-col pr-4">
                    <span className="text-sm font-medium text-[#e3e3e3]">Telemetry & Diagnostics</span>
                    <span className="text-xs text-[#8e918f] mt-0.5">
                      When disabled, diagnostic data remains strictly private on your device.
                    </span>
                  </div>
                  <label className="relative inline-flex cursor-pointer items-center shrink-0">
                    <input
                      type="checkbox"
                      checked={settings.dataSharing}
                      onChange={(e) => onUpdateSettings({ dataSharing: e.target.checked })}
                      className="peer sr-only"
                    />
                    <div className="peer h-6 w-11 rounded-full bg-[#3c4043] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#9333ea] peer-checked:after:translate-x-full peer-focus:outline-none" />
                  </label>
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-[#e3e3e3] mb-2">App Scope & Capabilities Overview</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-4">
                      <span className="text-xs font-bold text-[#c084fc] uppercase tracking-wider">Free Tier</span>
                      <p className="text-xs text-[#e3e3e3] font-medium mt-1 mb-1">ARUCH Free Core & Assistants</p>
                      <p className="text-[11px] text-[#8e918f] leading-relaxed">
                        Completely free of charge, designed to help students with homework, daily life organization, general problem-solving, and act as a daily emotional companion for listening and chatting.
                      </p>
                    </div>
                    <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-4">
                      <span className="text-xs font-bold text-[#34a853] uppercase tracking-wider">Paid Tiers ($0.50 - $3.00)</span>
                      <p className="text-xs text-[#e3e3e3] font-medium mt-1 mb-1">Ultra Apex, Supreme Pro, Turbo Elite, Neural V1/V2</p>
                      <p className="text-[11px] text-[#8e918f] leading-relaxed">
                        Designed for advanced business strategies, complex coding architectures, market analysis, and high-performance multi-domain problem-solving.
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-[#e3e3e3] mb-2">Official Customer Support & Dispute Resolution</h3>
                  <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-4 flex flex-col gap-2.5">
                    <p className="text-xs text-[#8e918f] leading-relaxed">
                      If you experience any issues with payment verification, model unlocking, or need dispute resolution, you can contact official support directly through:
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 pt-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-[#e3e3e3]">Email:</span>
                        <a href="mailto:ChhuoyMakara@gmail.com" className="text-xs text-[#c084fc] hover:underline">ChhuoyMakara@gmail.com</a>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-[#e3e3e3]">Phone:</span>
                        <a href="tel:0979262838" className="text-xs text-[#c084fc] hover:underline">0979262838 / 077688200</a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-2xl border border-[#ea4335]/30 bg-[#18191a] p-4 mt-2">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-[#ea4335]">Clear All Chat History</span>
                    <span className="text-xs text-[#8e918f]">
                      Permanently clear all stored conversation logs and files.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onClearHistory();
                      setShowClearSuccess(true);
                      setTimeout(() => setShowClearSuccess(false), 2500);
                    }}
                    className="flex items-center gap-1.5 rounded-xl border border-[#ea4335] bg-[#ea4335]/15 px-3.5 py-2 text-xs font-semibold text-[#ea4335] hover:bg-[#ea4335] hover:text-white transition-all cursor-pointer"
                  >
                    <Trash2 size={13} />
                    {showClearSuccess ? 'Cleared!' : 'Clear All'}
                  </button>
                </div>
              </div>
            )}

            {/* Tab 9: Shared links */}
            {activeTab === 'sharedLinks' && (
              <div className="mt-4 flex flex-col gap-4">
                <p className="text-xs text-[#8e918f]">
                  Public conversation links generated for sharing.
                </p>

                <div className="rounded-2xl border border-[#3c4043] bg-[#18191a] p-6 text-center">
                  <Share2 className="mx-auto text-[#8e918f] mb-2" size={24} />
                  <p className="text-sm font-medium text-[#e3e3e3]">No shared links yet</p>
                  <p className="text-xs text-[#8e918f] mt-1">
                    When you share a conversation via link, it will appear here for easy management.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Footer with Domain and Firebase Log out */}
          <div className="mt-8 pt-4 border-t border-[#28292a] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-[#8e918f]">
              <Globe size={13} className="text-[#a855f7]" />
              <span>Domain: <strong className="text-[#c4c7c5]">gen-lang-client-0341340527.firebaseapp.com</strong></span>
            </div>
            <button
              type="button"
              onClick={() => {
                onClose();
                onSignOut();
              }}
              className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-2xl bg-[#ea4335] px-6 py-2.5 text-xs font-semibold text-white transition-all hover:bg-[#d93025] shadow-lg"
            >
              <LogOut size={14} />
              <span>Log out</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
