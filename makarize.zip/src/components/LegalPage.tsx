import React, { useState, useEffect } from 'react';
import {
  Shield,
  FileText,
  Lock,
  ArrowLeft,
  Globe,
  Mail,
  Phone,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Database,
  EyeOff,
  UserCheck,
  AlertTriangle,
  Scale,
  Sparkles,
  Printer,
} from 'lucide-react';
import MakarizeLogo from './MakarizeLogo';
import { cn } from '../lib/utils';
import { useHaptic } from '../lib/useHaptic';

interface LegalPageProps {
  initialTab?: 'privacy' | 'terms';
  onBack?: () => void;
  isModal?: boolean;
}

export default function LegalPage({
  initialTab = 'privacy',
  onBack,
  isModal = false,
}: LegalPageProps) {
  const [activeTab, setActiveTab] = useState<'privacy' | 'terms'>(initialTab);
  const [language, setLanguage] = useState<'km' | 'en'>('km');
  const { triggerSelection, triggerLight } = useHaptic();

  // Scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  const handlePrint = () => {
    triggerLight();
    window.print();
  };

  return (
    <div className={cn(
      'min-h-screen bg-[#0f1013] text-[#e3e3e3] font-sans antialiased selection:bg-purple-500/30 selection:text-purple-200',
      isModal ? 'py-4 px-2 sm:px-6' : 'py-8 px-4 sm:px-8'
    )}>
      <div className="max-w-4xl mx-auto">
        {/* Navigation Bar / Header */}
        <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-[#26282d] mb-8">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                type="button"
                onClick={() => {
                  triggerLight();
                  onBack();
                }}
                className="flex items-center justify-center h-10 w-10 rounded-xl bg-[#1a1b1f] border border-[#2e3035] text-[#8e918f] hover:text-[#f1f3f4] hover:bg-[#282a30] transition-all cursor-pointer"
                title="ត្រឡប់ក្រោយ (Go Back)"
              >
                <ArrowLeft size={18} />
              </button>
            )}
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/10 border border-purple-500/20 shadow-inner">
                <MakarizeLogo size={24} />
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight text-[#f1f3f4] flex items-center gap-2">
                  <span>Makarize AI</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-medium border border-purple-500/30">
                    Legal & Compliance
                  </span>
                </h1>
                <p className="text-xs text-[#8e918f]">
                  គោលការណ៍ឯកជនភាព និងលក្ខខណ្ឌប្រើប្រាស់ផ្លូវការ
                </p>
              </div>
            </div>
          </div>

          {/* Action Tools: Tab Switch, Language, Print */}
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            {/* Language Switch */}
            <div className="flex items-center rounded-xl bg-[#18191c] p-1 border border-[#2e3035]">
              <button
                type="button"
                onClick={() => {
                  triggerSelection();
                  setLanguage('km');
                }}
                className={cn(
                  'px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer',
                  language === 'km'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-[#8e918f] hover:text-[#e3e3e3]'
                )}
              >
                🇰🇭 ភាសាខ្មែរ
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerSelection();
                  setLanguage('en');
                }}
                className={cn(
                  'px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer',
                  language === 'en'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-[#8e918f] hover:text-[#e3e3e3]'
                )}
              >
                🇺🇸 English
              </button>
            </div>

            {/* Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-xl bg-[#18191c] px-3 py-1.5 text-xs font-medium text-[#9aa0a6] border border-[#2e3035] hover:text-[#f1f3f4] hover:bg-[#222428] transition-all cursor-pointer"
              title="Print Legal Document"
            >
              <Printer size={14} />
              <span className="hidden sm:inline">Print</span>
            </button>
          </div>
        </header>

        {/* Tab Selector: Privacy Policy vs Terms of Service */}
        <div className="grid grid-cols-2 gap-2 rounded-2xl bg-[#141517] p-1.5 border border-[#2e3035] mb-8">
          <button
            type="button"
            id="tab-btn-privacy"
            onClick={() => {
              triggerSelection();
              setActiveTab('privacy');
            }}
            className={cn(
              'flex items-center justify-center gap-2 rounded-xl py-3 text-xs sm:text-sm font-bold transition-all cursor-pointer',
              activeTab === 'privacy'
                ? 'bg-[#22202c] text-purple-300 border border-purple-500/40 shadow-md'
                : 'text-[#8e918f] hover:text-[#e3e3e3]'
            )}
          >
            <Shield size={16} className={activeTab === 'privacy' ? 'text-purple-400' : ''} />
            <span>{language === 'km' ? 'គោលការណ៍ឯកជនភាព (Privacy Policy)' : 'Privacy Policy'}</span>
          </button>

          <button
            type="button"
            id="tab-btn-terms"
            onClick={() => {
              triggerSelection();
              setActiveTab('terms');
            }}
            className={cn(
              'flex items-center justify-center gap-2 rounded-xl py-3 text-xs sm:text-sm font-bold transition-all cursor-pointer',
              activeTab === 'terms'
                ? 'bg-[#22202c] text-purple-300 border border-purple-500/40 shadow-md'
                : 'text-[#8e918f] hover:text-[#e3e3e3]'
            )}
          >
            <Scale size={16} className={activeTab === 'terms' ? 'text-purple-400' : ''} />
            <span>{language === 'km' ? 'លក្ខខណ្ឌប្រើប្រាស់ (Terms of Service)' : 'Terms of Service'}</span>
          </button>
        </div>

        {/* ========================================================================= */}
        {/* PRIVACY POLICY CONTENT */}
        {/* ========================================================================= */}
        {activeTab === 'privacy' && (
          <div className="space-y-8 leading-relaxed text-[#c7cad1]">
            {/* Header Meta */}
            <div className="rounded-2xl bg-[#16171b] p-6 border border-[#2e3035]">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-400 mb-2">
                <Lock size={14} />
                <span>Google Play & Global Standards Compliance</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#f1f3f4] mb-2">
                {language === 'km' ? 'គោលការណ៍ឯកជនភាពរបស់ Makarize AI' : 'Privacy Policy for Makarize AI'}
              </h2>
              <div className="flex flex-wrap gap-4 text-xs text-[#8e918f]">
                <span>កាលបរិច្ឆេទធ្វើបច្ចុប្បន្នភាពចុងក្រោយ (Last Updated): <strong>September 2026</strong></span>
                <span>•</span>
                <span>អ្នកអភិវឌ្ឍន៍ (Developer): <strong>Makarize AI (Chhuoy Makara)</strong></span>
              </div>
            </div>

            {/* Quick Summary Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div className="rounded-2xl bg-[#16171b] p-4 border border-[#2e3035]">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-xs mb-1.5">
                  <EyeOff size={16} />
                  <span>{language === 'km' ? 'ទិន្នន័យមិនត្រូវបានលក់' : 'Zero Data Selling'}</span>
                </div>
                <p className="text-xs text-[#8e918f]">
                  {language === 'km'
                    ? 'យើងមិនដែលលក់ ជួល ឬចែករំលែកទិន្នន័យ Chat ឬព័ត៌មានផ្ទាល់ខ្លួនរបស់អ្នកទៅកាន់ភាគីទីបីឡើយ។'
                    : 'We never sell, rent, or monetize your personal conversations or account data to third parties.'}
                </p>
              </div>

              <div className="rounded-2xl bg-[#16171b] p-4 border border-[#2e3035]">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs mb-1.5">
                  <Lock size={16} />
                  <span>{language === 'km' ? 'សុវត្ថិភាពខ្ពស់ (Encrypted)' : 'Encrypted & Secure'}</span>
                </div>
                <p className="text-xs text-[#8e918f]">
                  {language === 'km'
                    ? 'ទិន្នន័យទាំងអស់ត្រូវបានការពារដោយប្រព័ន្ធសុវត្ថិភាព HTTPS/TLS និង Google Firebase Cloud Firestore។'
                    : 'All communications are protected in transit via HTTPS/TLS and at rest using Google Cloud Firestore.'}
                </p>
              </div>

              <div className="rounded-2xl bg-[#16171b] p-4 border border-[#2e3035]">
                <div className="flex items-center gap-2 text-blue-400 font-bold text-xs mb-1.5">
                  <UserCheck size={16} />
                  <span>{language === 'km' ? 'សិទ្ធិគ្រប់គ្រងពេញលេញ' : 'Full User Control'}</span>
                </div>
                <p className="text-xs text-[#8e918f]">
                  {language === 'km'
                    ? 'អ្នកអាចលុបប្រវត្តិ Chat ទាំងអស់ ឬស្នើសុំលុបគណនីរបស់អ្នកចេញពីប្រព័ន្ធបានគ្រប់ពេលវេលា។'
                    : 'You can erase conversation history anytime or request complete deletion of your account.'}
                </p>
              </div>
            </div>

            {/* Section 1: Introduction */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">1.</span>
                <span>{language === 'km' ? 'សេចក្តីផ្តើម និងវិសាលភាព (Introduction & Scope)' : '1. Introduction & Scope'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    កម្មវិធី <strong>Makarize AI</strong> («កម្មវិធី», «យើង», «សេវាកម្ម») ប្តេជ្ញាយ៉ាងម៉ឺងម៉ាត់ក្នុងការការពារឯកជនភាព និងទិន្នន័យផ្ទាល់ខ្លួនរបស់អ្នកប្រើប្រាស់។ គោលការណ៍ឯកជនភាពនេះរៀបរាប់អំពីរបៀបដែលយើងប្រមូល ប្រើប្រាស់ រក្សាទុក និងការពារព័ត៌មានរបស់អ្នកនៅពេលអ្នកប្រើប្រាស់កម្មវិធី Makarize AI នៅលើឧបករណ៍ចល័ត ថេប្លេត ឬគេហទំព័រ។
                  </>
                ) : (
                  <>
                    <strong>Makarize AI</strong> ("the Application", "we", "us", or "our") is strictly committed to protecting the privacy and confidentiality of our users. This Privacy Policy explains how we collect, use, store, and safeguard your information when you access and utilize Makarize AI across mobile devices, web interfaces, and related services.
                  </>
                )}
              </p>
            </section>

            {/* Section 2: Information We Collect */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">2.</span>
                <span>{language === 'km' ? 'ព័ត៌មានដែលយើងប្រមូល (Information We Collect)' : '2. Information We Collect'}</span>
              </h3>
              <div className="space-y-2.5 text-xs sm:text-sm">
                <div className="rounded-xl bg-[#16171b] p-3.5 border border-[#2e3035]">
                  <h4 className="font-semibold text-[#f1f3f4] mb-1">
                    {language === 'km' ? 'ក. ព័ត៌មានគណនី (Account Information):' : 'A. Account Credentials & Profile:'}
                  </h4>
                  <p className="text-[#8e918f]">
                    {language === 'km'
                      ? 'នៅពេលអ្នកចូលប្រើប្រាស់តាមរយៈ Google Sign-In យើងទទួលព័ត៌មានជាមូលដ្ឋានដូចជា ឈ្មោះ (Display Name), អាសយដ្ឋានអ៊ីមែល (Email), និងរូបភាព Profile (Avatar URL) ដើម្បីផ្ទៀងផ្ទាត់អត្តសញ្ញាណ និងបង្កើតគណនីអ្នកប្រើប្រាស់ក្នុង Firebase Authentication។'
                      : 'When signing in via Google Sign-In / Firebase Auth, we receive basic identifiers including your name, email address, profile avatar, and unique user identifier (UID) to securely maintain your session.'}
                  </p>
                </div>

                <div className="rounded-xl bg-[#16171b] p-3.5 border border-[#2e3035]">
                  <h4 className="font-semibold text-[#f1f3f4] mb-1">
                    {language === 'km' ? 'ខ. សារសន្ទនា និងឯកសារភ្ជាប់ (User Content & Prompts):' : 'B. Prompts, Conversations & Media Uploads:'}
                  </h4>
                  <p className="text-[#8e918f]">
                    {language === 'km'
                      ? 'សំណួរ អត្ថបទដែលអ្នកវាយបញ្ចូល រូបភាពដែលអ្នកបង្ហោះ សំឡេងកត់ត្រា និងឯកសារ PDF/Code ដែលអ្នកភ្ជាប់ ដើម្បីឱ្យម៉ូដែល AI អាចវិភាគ និងឆ្លើយតប។ ទិន្នន័យទាំងនេះត្រូវបានរក្សាទុកក្នុង Firestore សម្រាប់តែបង្ហាញប្រវត្តិ Chat ជូនអ្នកផ្ទាល់ប៉ុណ្ណោះ។'
                      : 'Text prompts, questions, uploaded images, audio voice notes, and documents provided by you to enable AI assistance and analysis. These are stored securely in Firestore for your personal chat continuity.'}
                  </p>
                </div>

                <div className="rounded-xl bg-[#16171b] p-3.5 border border-[#2e3035]">
                  <h4 className="font-semibold text-[#f1f3f4] mb-1">
                    {language === 'km' ? 'គ. ទិន្នន័យបច្ចេកទេស និងការកំណត់ (Technical & Preference Data):' : 'C. Device & Technical Preferences:'}
                  </h4>
                  <p className="text-[#8e918f]">
                    {language === 'km'
                      ? 'ការកំណត់ភាសា (Language preferences), ការកំណត់ Theme (Dark/Light), និងការកំណត់សំឡេង (Haptic feedback & speech synthesis settings)។'
                      : 'Stored preferences including selected language (Khmer/English), UI theme, haptic feedback toggles, and speech synthesis voice selections.'}
                  </p>
                </div>
              </div>
            </section>

            {/* Section 3: AI Processing & Third Parties */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">3.</span>
                <span>{language === 'km' ? 'ដំណើរការបញ្ញាសិប្បនិម្មិត AI & សេវាកម្មភាគីទីបី (AI Processing & Third Parties)' : '3. AI Processing & Third-Party Services'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    ដើម្បីផ្តល់ចម្លើយដ៏ឆ្លាតវៃ កម្មវិធី Makarize AI ដំណើរការសំណួររបស់អ្នកតាមរយៈ API សុវត្ថិភាពរបស់ក្រុមហ៊ុនបច្ចេកវិទ្យាលំដាប់ពិភពលោក រួមមាន៖
                  </>
                ) : (
                  <>
                    To generate intelligent responses, Makarize AI processes user prompts via enterprise-grade, secure API infrastructures provided by:
                  </>
                )}
              </p>
              <ul className="list-disc list-inside space-y-1.5 text-xs sm:text-sm text-[#9aa0a6] pl-2">
                <li><strong>Google Cloud & Google Gemini API</strong>: For advanced reasoning, vision analysis, and multimodal understanding.</li>
                <li><strong>Google Firebase (Auth & Cloud Firestore)</strong>: For encrypted user authentication and real-time database synchronization.</li>
                <li><strong>OpenRouter / OpenAI APIs</strong>: For specialized character personas and supplementary language capabilities.</li>
                <li><strong>National Bank of Cambodia (Bakong KHQR)</strong>: For domestic Cambodian standard digital payment QR processing without storing banking credentials.</li>
              </ul>
            </section>

            {/* Section 4: Data Retention & User Rights */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">4.</span>
                <span>{language === 'km' ? 'សិទ្ធិអ្នកប្រើប្រាស់ និងការលុបទិន្នន័យ (User Rights & Account Deletion)' : '4. User Rights & Data Deletion'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    យោងតាមគោលការណ៍ Google Play Store អ្នកប្រើប្រាស់មានសិទ្ធិពេញលេញលើទិន្នន័យរបស់ខ្លួន៖
                  </>
                ) : (
                  <>
                    In accordance with Google Play developer policies, users maintain full sovereignty over their personal data:
                  </>
                )}
              </p>
              <div className="rounded-2xl bg-[#18191c] p-4 border border-[#2e3035] space-y-2 text-xs sm:text-sm">
                <div className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="text-purple-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#f1f3f4]">{language === 'km' ? 'លុបប្រវត្តិ Chat ភ្លាមៗ (Clear Chat History):' : 'Clear Chat History:'}</strong>{' '}
                    <span>{language === 'km' ? 'លោកអ្នកអាចចុចប៊ូតុង «Clear Conversation History» នៅក្នុង Settings ដើម្បីលុបសារទាំងអស់ចេញពីឧបករណ៍ និង Cloud Firestore។' : 'You can purge all stored conversations directly inside the Settings tab.'}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="text-purple-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#f1f3f4]">{language === 'km' ? 'ការលុបគណនី និងទិន្នន័យអចិន្ត្រៃយ៍ក្នុង App (In-App Permanent Account Deletion):' : 'In-App Permanent Account Deletion:'}</strong>{' '}
                    <span>{language === 'km' ? 'លោកអ្នកអាចចូលទៅកាន់ Settings -> Privacy & Data -> ចុចប៊ូតុង «Delete Account & Data (លុបគណនី និងទិន្នន័យ)» ដើម្បីលុបគណនី Google Auth, ប្រវត្តិ Chat, ការកំណត់ និងទិន្នន័យទាំងអស់ជាស្ថាពរភ្លាមៗដោយស្វ័យប្រវត្តិ។' : 'You can initiate immediate, permanent account deletion directly in the app via Settings -> Privacy & Data -> "Delete Account & Data" to wipe your Google Auth profile, chats, and preferences.'}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="text-purple-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#f1f3f4]">{language === 'km' ? 'ការស្នើសុំលុបគណនីតាមរយៈ Web / Email (External Request):' : 'External Web / Email Deletion Request:'}</strong>{' '}
                    <span>{language === 'km' ? 'ប្រសិនបើអ្នកមិនអាចចូល App បាន លោកអ្នកអាចផ្ញើអ៊ីមែលមកកាន់ ChhuoyMakara@gmail.com ជាមួយចំណងជើង «Delete My Makarize Account» ហើយទិន្នន័យរបស់អ្នកនឹងត្រូវបានលុបចេញទាំងស្រុងក្នុងរយៈពេល ២៤-៤៨ ម៉ោង។' : 'If you cannot access the app, you may email ChhuoyMakara@gmail.com with the subject "Delete My Makarize Account". All associated cloud data will be permanently wiped within 24-48 hours.'}</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Section 5: Children's Privacy */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">5.</span>
                <span>{language === 'km' ? 'ឯកជនភាពកុមារ (Children\'s Privacy - COPPA)' : '5. Children\'s Privacy'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    សេវាកម្មរបស់យើងមិនផ្តោតលើកុមារដែលមានអាយុក្រោម ១៣ ឆ្នាំដោយគ្មានការយល់ព្រមពីអាណាព្យាបាលឡើយ។ យើងមិនប្រមូលព័ត៌មានសម្គាល់អត្តសញ្ញាណផ្ទាល់ខ្លួនពីកុមារដោយចេតនានោះទេ។ ប្រសិនបើអ្នកជាឪពុកម្តាយ ឬអាណាព្យាបាល ហើយដឹងថាកូនរបស់អ្នកបានផ្តល់ព័ត៌មានផ្ទាល់ខ្លួនមកយើង សូមទាក់ទងមកយើងដើម្បីលុបទិន្នន័យនោះចេញ។
                  </>
                ) : (
                  <>
                    Makarize AI does not knowingly collect or solicit personally identifiable information from children under the age of 13 without verifiable parental consent. If we become aware that personal data of a minor has been collected, we will take immediate measures to remove such information from our records.
                  </>
                )}
              </p>
            </section>

            {/* Section 6: Contact Information */}
            <section className="rounded-2xl bg-[#16171b] p-6 border border-[#2e3035] space-y-3">
              <h3 className="text-sm sm:text-base font-bold text-[#f1f3f4] flex items-center gap-2">
                <Mail size={16} className="text-purple-400" />
                <span>{language === 'km' ? 'ព័ត៌មានទំនាក់ទំនងផ្លូវការ (Official Contact & Inquiries)' : 'Official Contact & Inquiries'}</span>
              </h3>
              <p className="text-xs sm:text-sm text-[#8e918f]">
                {language === 'km'
                  ? 'ប្រសិនបើលោកអ្នកមានចម្ងល់ សំណូមពរ ឬកង្វល់ទាក់ទងនឹងគោលការណ៍ឯកជនភាពនេះ សូមទាក់ទងមកកាន់យើងខ្ញុំតាមរយៈ៖'
                  : 'If you have any questions, concerns, or data inquiries regarding this Privacy Policy, please contact our support team:'}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                <div className="rounded-xl bg-[#111215] p-3 border border-[#26282d]">
                  <span className="text-[#8e918f] block mb-0.5">Email Support:</span>
                  <a href="mailto:ChhuoyMakara@gmail.com" className="text-purple-300 font-semibold hover:underline">
                    ChhuoyMakara@gmail.com
                  </a>
                </div>
                <div className="rounded-xl bg-[#111215] p-3 border border-[#26282d]">
                  <span className="text-[#8e918f] block mb-0.5">Hotline & Phone:</span>
                  <a href="tel:0979262838" className="text-purple-300 font-semibold hover:underline">
                    +855 97 926 2838 / 077 688 200
                  </a>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TERMS OF SERVICE CONTENT */}
        {/* ========================================================================= */}
        {activeTab === 'terms' && (
          <div className="space-y-8 leading-relaxed text-[#c7cad1]">
            {/* Header Meta */}
            <div className="rounded-2xl bg-[#16171b] p-6 border border-[#2e3035]">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-400 mb-2">
                <Scale size={14} />
                <span>User Agreement & Service Conditions</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#f1f3f4] mb-2">
                {language === 'km' ? 'លក្ខខណ្ឌប្រើប្រាស់សេវាកម្ម Makarize AI' : 'Terms of Service for Makarize AI'}
              </h2>
              <div className="flex flex-wrap gap-4 text-xs text-[#8e918f]">
                <span>កាលបរិច្ឆេទអនុវត្ត (Effective Date): <strong>September 2026</strong></span>
                <span>•</span>
                <span>ទីតាំង (Jurisdiction): <strong>Kingdom of Cambodia</strong></span>
              </div>
            </div>

            {/* Section 1: Acceptance of Terms */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">1.</span>
                <span>{language === 'km' ? 'ការយល់ព្រមលើលក្ខខណ្ឌ (Acceptance of Terms)' : '1. Acceptance of Terms'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    តាមរយៈការចូលប្រើប្រាស់ ទាញយក ឬប្រើប្រាស់កម្មវិធី <strong>Makarize AI</strong> អ្នកយល់ព្រមទទួលស្គាល់ និងគោរពតាមលក្ខខណ្ឌប្រើប្រាស់ទាំងអស់ដែលមានចែងក្នុងឯកសារនេះ។ ប្រសិនបើអ្នកមិនយល់ព្រមលើលក្ខខណ្ឌណាមួយទេ សូមបញ្ឈប់ការប្រើប្រាស់កម្មវិធីនេះ។
                  </>
                ) : (
                  <>
                    By downloading, accessing, or utilizing <strong>Makarize AI</strong>, you agree to be legally bound by these Terms of Service. If you do not agree with any portion of these terms, you must discontinue the use of our services immediately.
                  </>
                )}
              </p>
            </section>

            {/* Section 2: Acceptable Use & Prohibited Content */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">2.</span>
                <span>{language === 'km' ? 'គោលការណ៍ប្រើប្រាស់ត្រឹមត្រូវ និងសកម្មភាពហាមឃាត់ (Acceptable Use)' : '2. Acceptable Use & Prohibited Activities'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    អ្នកប្រើប្រាស់ត្រូវតែប្រើប្រាស់ Makarize AI សម្រាប់គោលបំណងស្របច្បាប់ប៉ុណ្ណោះ។ អ្នកត្រូវបានហាមឃាត់យ៉ាងតឹងរ៉ឹងពីសកម្មភាពដូចខាងក្រោម៖
                  </>
                ) : (
                  <>
                    Users must utilize Makarize AI solely for lawful, constructive purposes. The following activities are strictly prohibited:
                  </>
                )}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm">
                <div className="rounded-xl bg-[#16171b] p-3.5 border border-rose-500/20">
                  <div className="text-rose-400 font-bold mb-1 flex items-center gap-1.5">
                    <AlertTriangle size={15} />
                    <span>{language === 'km' ? 'ខ្លឹមសារខុសច្បាប់ & អំពើហិង្សា' : 'Illegal or Harmful Content'}</span>
                  </div>
                  <p className="text-[#8e918f]">
                    {language === 'km'
                      ? 'ការបង្កើត ឬចែកចាយខ្លឹមសារដែលគំរាមកំហែង បង្កអំពើហិង្សា ការរំលោភបំពានផ្លូវភេទលើកុមារ ឬការបំផ្លិចបំផ្លាញសង្គម។'
                      : 'Generating, distributing, or promoting hate speech, violent extremism, child sexual abuse material (CSAM), or illegal acts.'}
                  </p>
                </div>

                <div className="rounded-xl bg-[#16171b] p-3.5 border border-rose-500/20">
                  <div className="text-rose-400 font-bold mb-1 flex items-center gap-1.5">
                    <AlertTriangle size={15} />
                    <span>{language === 'km' ? 'ការវាយប្រហារបច្ចេកវិទ្យា & Hack' : 'Malicious Code & Cyber Attacks'}</span>
                  </div>
                  <p className="text-[#8e918f]">
                    {language === 'km'
                      ? 'ការព្យាយាម Hack ប្រព័ន្ធ បង្កើត Malware/Ransomware ឬការវាយប្រហារ Denial of Service (DoS) មកលើ Server។'
                      : 'Attempting to exploit vulnerabilities, inject malicious code, reverse-engineer proprietary algorithms, or overload API endpoints.'}
                  </p>
                </div>
              </div>
            </section>

            {/* Section 3: AI Disclaimer & Medical/Financial Advice */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">3.</span>
                <span>{language === 'km' ? 'ការមិនទទួលខុសត្រូវលើព័ត៌មាន AI (AI Disclaimers)' : '3. AI Output Disclaimers'}</span>
              </h3>
              <div className="rounded-2xl bg-[#18191c] p-4 border border-[#2e3035] space-y-2 text-xs sm:text-sm">
                <p>
                  {language === 'km' ? (
                    <>
                      <strong>ចំណាំសំខាន់៖</strong> ចម្លើយដែលបង្កើតឡើងដោយបញ្ញាសិប្បនិម្មិត (AI) គឺសម្រាប់គោលបំណងផ្តល់ព័ត៌មាន ការអប់រំ និងជំនួយការងារប៉ុណ្ណោះ។ AI អាចមានកំហុស ឬភាពមិនសុក្រឹតម្តងម្កាល (AI Hallucinations)។ 
                    </>
                  ) : (
                    <>
                      <strong>Important Notice:</strong> Content generated by AI models is provided for informational, educational, and productivity enhancement purposes. AI models may occasionally produce inaccurate, incomplete, or biased information.
                    </>
                  )}
                </p>
                <p className="text-[#8e918f]">
                  {language === 'km'
                    ? 'ចម្លើយរបស់ AI មិនត្រូវចាត់ទុកជាការប្រឹក្សាវេជ្ជសាស្ត្រផ្លូវការ ការប្រឹក្សាផ្លូវច្បាប់ ឬការប្រឹក្សាវិនិយោគហិរញ្ញវត្ថុឡើយ។ សូមពិគ្រោះជាមួយអ្នកជំនាញពិតប្រាកដមុននឹងធ្វើការសម្រេចចិត្តសំខាន់ៗ។'
                    : 'AI outputs should never replace professional medical diagnosis, certified legal counsel, or accredited financial investment advice.'}
                </p>
              </div>
            </section>

            {/* Section 4: Subscription, Pricing & Payments */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">4.</span>
                <span>{language === 'km' ? 'តម្លៃ និងការទូទាត់ប្រាក់ (Pricing, Upgrades & KHQR)' : '4. Pricing, Upgrades & Payments'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    Makarize AI ផ្តល់ជូនទាំងជម្រើស <strong>ឥតគិតថ្លៃ (Free Tier)</strong> សម្រាប់ជំនួយការប្រចាំថ្ងៃ និងជម្រើស <strong>ម៉ូដែលកម្រិតខ្ពស់ (Premium Tiers: $0.50 - $3.00)</strong>។ ការទូទាត់ប្រាក់ក្នុងស្រុកត្រូវបានធ្វើឡើងតាមរយៈ KHQR (Bakong)។ ក្នុងករណីមានបញ្ហាផ្ទៀងផ្ទាត់ការទូទាត់ សូមទាក់ទងមកកាន់ផ្នែកបម្រើអតិថិជនដើម្បីទទួលបានការគាំទ្រភ្លាមៗ។
                  </>
                ) : (
                  <>
                    Makarize AI offers both a comprehensive <strong>Free Tier</strong> and premium high-performance models ranging from $0.50 to $3.00. Domestic transactions are processed via standard Bakong KHQR. If any transaction verification delay occurs, our official support hotline is available for immediate manual confirmation.
                  </>
                )}
              </p>
            </section>

            {/* Section 5: Governing Law */}
            <section className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#f1f3f4] flex items-center gap-2 border-b border-[#26282d] pb-2">
                <span className="text-purple-400 font-mono">5.</span>
                <span>{language === 'km' ? 'ច្បាប់គ្រប់គ្រង (Governing Law)' : '5. Governing Law & Dispute Resolution'}</span>
              </h3>
              <p className="text-xs sm:text-sm">
                {language === 'km' ? (
                  <>
                    លក្ខខណ្ឌប្រើប្រាស់នេះត្រូវស្ថិតនៅក្រោម និងបកស្រាយស្របតាមច្បាប់នៃ <strong>ព្រះរាជាណាចក្រកម្ពុជា</strong>។ វិវាទទាំងឡាយដែលកើតឡើងពីការប្រើប្រាស់សេវាកម្មនេះ នឹងត្រូវដោះស្រាយដោយសន្តិវិធី និងការចរចាដោយសុចរិត។
                  </>
                ) : (
                  <>
                    These Terms shall be governed and construed in accordance with the laws of the <strong>Kingdom of Cambodia</strong>. Any dispute arising out of or in connection with these terms shall first be resolved through good-faith mutual negotiations.
                  </>
                )}
              </p>
            </section>
          </div>
        )}

        {/* Footer Note */}
        <footer className="mt-12 pt-6 border-t border-[#26282d] text-center text-xs text-[#8e918f] space-y-2">
          <div className="flex items-center justify-center gap-2">
            <MakarizeLogo size={16} />
            <span className="font-semibold text-[#f1f3f4]">Makarize AI</span>
            <span>•</span>
            <span>All Rights Reserved &copy; {new Date().getFullYear()}</span>
          </div>
          <p className="text-[11px] text-[#5f6368]">
            Phnom Penh, Kingdom of Cambodia • Official Developer: Chhuoy Makara
          </p>
        </footer>
      </div>
    </div>
  );
}
