import React, { useState, useEffect } from 'react';
import {
  Copy,
  Check,
  ThumbsUp,
  ThumbsDown,
  Volume2,
  VolumeX,
  Share2,
  RotateCcw,
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useHaptic } from '../lib/useHaptic';
import { ChatMessage } from '../types';

interface MessageActionsProps {
  message: ChatMessage;
  onToggleLike: (id: string) => void;
  onToggleDislike: (id: string) => void;
  onRetry?: () => void;
  className?: string;
}

export default function MessageActions({
  message,
  onToggleLike,
  onToggleDislike,
  onRetry,
  className,
}: MessageActionsProps) {
  const { triggerSelection, triggerSuccess, triggerLight } = useHaptic();
  const [isCopied, setIsCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Clean up speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (isSpeaking && typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isSpeaking]);

  const handleCopy = async () => {
    if (!message.text) return;
    try {
      await navigator.clipboard.writeText(message.text);
      triggerSuccess();
      setIsCopied(true);
      setTimeout(() => {
        setIsCopied(false);
      }, 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const handleLike = () => {
    triggerSelection();
    onToggleLike(message.id);
  };

  const handleDislike = () => {
    triggerSelection();
    onToggleDislike(message.id);
  };

  const handleSpeak = () => {
    triggerLight();
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    // Strip markdown characters for cleaner speech output
    const cleanText = message.text
      .replace(/```[\s\S]*?```/g, 'Code snippet omitted.')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/[*_~#]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');

    window.speechSynthesis.cancel(); // Stop any previous speech
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleShare = async () => {
    triggerLight();
    if (!message.text) return;

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: 'Makarize AI Response',
          text: message.text,
        });
        return;
      } catch (err) {
        // Fallback to copy if user dismissed native share
      }
    }

    // Fallback to copy
    handleCopy();
  };

  return (
    <div
      className={cn(
        'mt-2.5 flex flex-wrap items-center gap-1 text-[#8e918f]',
        className
      )}
    >
      {/* Copy Button */}
      <button
        type="button"
        id={`btn-copy-${message.id}`}
        onClick={handleCopy}
        className={cn(
          'group relative flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs transition-all cursor-pointer border active:scale-95',
          isCopied
            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40 shadow-sm'
            : 'bg-[#1e1f20]/60 border-[#2e3035] hover:bg-[#28292a] hover:border-[#3c4043] hover:text-[#e3e3e3]'
        )}
        title={isCopied ? 'បានចម្លងអត្ថបទរួចរាល់!' : 'ចម្លងអត្ថបទឆ្លើយតប (Copy)'}
      >
        {isCopied ? (
          <>
            <Check size={14} className="text-emerald-400" />
            <span className="text-[11.5px] font-semibold text-emerald-400">បានចម្លង!</span>
          </>
        ) : (
          <>
            <Copy size={14} className="transition-transform group-hover:scale-110" />
            <span className="text-[11px] font-medium hidden sm:inline">ចម្លង</span>
          </>
        )}
      </button>

      {/* Like (Thumbs Up) Button */}
      <button
        type="button"
        id={`btn-like-${message.id}`}
        onClick={handleLike}
        className={cn(
          'group relative flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs transition-all cursor-pointer border active:scale-95',
          message.liked
            ? 'bg-purple-500/20 text-purple-300 border-purple-500/50 shadow-sm ring-1 ring-purple-500/30'
            : 'bg-[#1e1f20]/60 border-[#2e3035] hover:bg-[#28292a] hover:border-[#3c4043] hover:text-[#e3e3e3]'
        )}
        title={message.liked ? 'ដកការពេញចិត្តចេញ' : 'ពេញចិត្តចម្លើយនេះ (Like)'}
      >
        <ThumbsUp
          size={14}
          className={cn(
            'transition-transform group-hover:scale-110',
            message.liked && 'fill-purple-400 text-purple-400'
          )}
        />
        {message.liked && <span className="text-[11px] font-semibold text-purple-300">ពេញចិត្ត</span>}
      </button>

      {/* Dislike (Thumbs Down) Button */}
      <button
        type="button"
        id={`btn-dislike-${message.id}`}
        onClick={handleDislike}
        className={cn(
          'group relative flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs transition-all cursor-pointer border active:scale-95',
          message.disliked
            ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-sm ring-1 ring-rose-500/30'
            : 'bg-[#1e1f20]/60 border-[#2e3035] hover:bg-[#28292a] hover:border-[#3c4043] hover:text-[#e3e3e3]'
        )}
        title={message.disliked ? 'ដកការមិនពេញចិត្តចេញ' : 'មិនពេញចិត្តចម្លើយនេះ (Dislike)'}
      >
        <ThumbsDown
          size={14}
          className={cn(
            'transition-transform group-hover:scale-110',
            message.disliked && 'fill-rose-400 text-rose-400'
          )}
        />
        {message.disliked && <span className="text-[11px] font-semibold text-rose-300">មិនពេញចិត្ត</span>}
      </button>

      {/* Read Aloud Button */}
      <button
        type="button"
        id={`btn-speak-${message.id}`}
        onClick={handleSpeak}
        className={cn(
          'group relative flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs transition-all cursor-pointer border active:scale-95',
          isSpeaking
            ? 'bg-blue-500/20 text-blue-300 border-blue-500/50 animate-pulse'
            : 'bg-[#1e1f20]/60 border-[#2e3035] hover:bg-[#28292a] hover:border-[#3c4043] hover:text-[#e3e3e3]'
        )}
        title={isSpeaking ? 'បញ្ឈប់ការអាន' : 'អានចម្លើយជាសំឡេង (Read aloud)'}
      >
        {isSpeaking ? (
          <>
            <VolumeX size={14} className="text-blue-400" />
            <span className="text-[11px] font-medium text-blue-300 hidden sm:inline">បញ្ឈប់</span>
          </>
        ) : (
          <Volume2 size={14} className="transition-transform group-hover:scale-110" />
        )}
      </button>

      {/* Share Button */}
      <button
        type="button"
        id={`btn-share-${message.id}`}
        onClick={handleShare}
        className="group relative flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-xs bg-[#1e1f20]/60 border border-[#2e3035] hover:bg-[#28292a] hover:border-[#3c4043] hover:text-[#e3e3e3] transition-all cursor-pointer active:scale-95"
        title="ចែករំលែកចម្លើយ (Share)"
      >
        <Share2 size={14} className="transition-transform group-hover:scale-110" />
      </button>

      {/* Optional Retry / Regenerate button */}
      {onRetry && (
        <button
          type="button"
          id={`btn-retry-${message.id}`}
          onClick={() => {
            triggerLight();
            onRetry();
          }}
          className="group relative flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-xs bg-[#1e1f20]/60 border border-[#2e3035] hover:bg-[#28292a] hover:border-[#3c4043] hover:text-[#e3e3e3] transition-all cursor-pointer active:scale-95"
          title="ឆ្លើយសារនេះឡើងវិញ (Regenerate)"
        >
          <RotateCcw size={14} className="transition-transform group-hover:scale-110" />
        </button>
      )}
    </div>
  );
}
