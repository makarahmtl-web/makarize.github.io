import React from 'react';
import { Sparkles } from 'lucide-react';

interface SuggestionChipsProps {
  text: string;
  onSelect: (prompt: string) => void;
}

// Detect language of text
function detectLanguage(text: string): 'km' | 'zh' | 'vi' | 'id' | 'ja' | 'en' {
  if (!text) return 'km';
  
  // Khmer Unicode block: \u1780-\u17FF, \u19E0-\u19FF
  if (/[\u1780-\u17FF\u19E0-\u19FF]/.test(text)) {
    return 'km';
  }
  // Chinese
  if (/[\u4E00-\u9FFF]/.test(text)) {
    return 'zh';
  }
  // Japanese
  if (/[\u3040-\u309F\u30A0-\u30FF]/.test(text)) {
    return 'ja';
  }
  // Vietnamese characters
  if (/[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/i.test(text)) {
    return 'vi';
  }
  // Indonesian / Malay keywords
  const lower = text.toLowerCase();
  if (/\b(yang|dan|dengan|untuk|adalah|ini|itu|bisa|terima kasih)\b/i.test(lower)) {
    return 'id';
  }

  return 'en';
}

export default function SuggestionChips({ text, onSelect }: SuggestionChipsProps) {
  // Dynamic contextual suggestion chips in the exact matching language
  const suggestions = React.useMemo(() => {
    const lang = detectLanguage(text);
    const lower = text.toLowerCase();
    const options: string[] = [];

    if (lang === 'km') {
      if (lower.includes('កូដ') || lower.includes('code') || lower.includes('function') || lower.includes('typescript') || lower.includes('python')) {
        options.push('ពន្យល់កូដនេះលម្អិតបន្ថែម', 'បង្កើនប្រសិទ្ធភាពកូដនេះ', 'សរសេរ Unit Test សម្រាប់កូដនេះ');
      } else if (lower.includes('អាជីវកម្ម') || lower.includes('ទីផ្សារ') || lower.includes('លុយ') || lower.includes('លក់') || lower.includes('business')) {
        options.push('រៀបចំផែនការយុទ្ធសាស្ត្រ', 'តើមានហានិភ័យអ្វីខ្លះ?', 'ផ្តល់ជម្រើសយុទ្ធសាស្ត្រផ្សេងទៀត');
      } else if (lower.includes('រូបភាព') || lower.includes('រចនា') || lower.includes('design') || lower.includes('image')) {
        options.push('ផ្តល់គំនិតកែលម្អបន្ថែម', 'បង្កើតទម្រង់បន្ថែម', 'ពិពណ៌នាអំពីរចនាប័ទ្មនេះ');
      } else if (lower.includes('សង្ខេប') || lower.includes('អត្ថបទ') || lower.includes('សៀវភៅ')) {
        options.push('សង្ខេបចំណុចសំខាន់ៗ ៣ យ៉ាង', 'ផ្តល់ឧទាហរណ៍ជាក់ស្តែង', 'ពន្យល់ជាភាសាងាយយល់បំផុត');
      }

      // Default Khmer fallback
      if (options.length === 0) {
        options.push('ប្រាប់បន្ថែមទៀត', 'តើអាចផ្តល់ឧទាហរណ៍បានទេ?', 'សង្ខេបចំណុចសំខាន់ៗ');
      }
    } else if (lang === 'zh') {
      if (lower.includes('code') || lower.includes('代码') || lower.includes('函数')) {
        options.push('详细解释这段代码', '优化这段代码', '为此编写测试用例');
      } else {
        options.push('了解更多详情', '能提供一个具体例子吗？', '总结核心要点');
      }
    } else if (lang === 'vi') {
      if (lower.includes('code') || lower.includes('mã') || lower.includes('hàm')) {
        options.push('Giải thích chi tiết mã này', 'Tối ưu hóa mã nguồn này', 'Viết unit test cho mã này');
      } else {
        options.push('Cho tôi biết thêm chi tiết', 'Bạn có thể cho ví dụ không?', 'Tóm tắt các điểm chính');
      }
    } else if (lang === 'id') {
      options.push('Jelaskan lebih lanjut', 'Bisakah berikan contoh?', 'Ringkas poin-poin penting');
    } else if (lang === 'ja') {
      options.push('詳しく教えて', '具体例を挙げていただけますか？', '要点をまとめて');
    } else {
      // English
      if (lower.includes('code') || lower.includes('function') || lower.includes('typescript')) {
        options.push('Explain this code in detail', 'Optimize this code', 'Write unit tests for this');
      } else if (lower.includes('business') || lower.includes('marketing')) {
        options.push('Generate a strategic plan', 'What are the main risks?', 'Suggest alternative approaches');
      } else if (lower.includes('image') || lower.includes('photo') || lower.includes('design')) {
        options.push('Suggest design improvements', 'Generate variations', 'Describe visual elements');
      } else {
        options.push('Tell me more', 'Can you provide an example?', 'Summarize key points');
      }
    }

    return options.slice(0, 3);
  }, [text]);

  if (!suggestions || suggestions.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2 mt-3">
      {suggestions.map((suggestion, idx) => (
        <button
          key={idx}
          type="button"
          onClick={() => onSelect(suggestion)}
          className="flex items-center gap-1.5 rounded-full border border-[#3c4043] bg-[#1e1f20] px-3.5 py-1.5 text-xs text-[#e3e3e3] hover:bg-[#28292a] hover:border-[#9333ea] active:scale-95 transition-all shadow-sm cursor-pointer"
        >
          <Sparkles size={13} className="text-[#c084fc] shrink-0" />
          <span>{suggestion}</span>
        </button>
      ))}
    </div>
  );
}

