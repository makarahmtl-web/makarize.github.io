import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Plus,
  Mic,
  MicOff,
  Send,
  ArrowUp,
  FileText,
  Square,
  Sparkles,
  ChevronDown,
  Check,
  BrainCircuit,
  FileCode,
  Image as ImageIcon,
  X,
  Eye,
  Lock,
  Unlock,
  CreditCard,
  Presentation,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FileAttachment, ModelOption } from '../types';
import { cn } from '../lib/utils';
import { formatBytes } from '../lib/fileUtils';
import { useHaptic } from '../lib/useHaptic';
import KHQRPaymentModal from './KHQRPaymentModal';
import ModelSelectorModal from './ModelSelectorModal';
import { t } from '../lib/i18n';
import { User, fetchUserUnlocksFromFirebase } from '../lib/firebase';

interface ChatInputProps {
  onSend: (text: string, attachments: FileAttachment[], modelId?: string) => void;
  onOpenAttachmentSheet: () => void;
  onOpenVoiceSheet: () => void;
  onOpenSlideStyleSheet?: () => void;
  onViewAttachment: (att: FileAttachment) => void;
  attachments: FileAttachment[];
  onRemoveAttachment: (id: string) => void;
  disabled?: boolean;
  placeholder?: string;
  selectedModel?: string;
  onModelChange?: (modelId: string) => void;
  language?: string;
  user?: User | null;
  insertedText?: string;
  onInsertedTextConsumed?: () => void;
}

export const AVAILABLE_MODELS: ModelOption[] = [
  {
    id: "gemini-2.5-flash",
    name: "Aroch 2.5 Flash",
    provider: "ARUCH Engine",
    badge: "Aroch Free",
    isFree: true,
    isLocked: false,
    isPremium: false,
    price: "Free",
    tagline: "ប្រព័ន្ធវៃឆ្លាតលឿនរហ័ស ស្ទាត់ជំនាញភាសា និងការវិភាគរូបភាព។",
    description: "ប្រព័ន្ធវៃឆ្លាតលឿនរហ័ស ស្ទាត់ជំនាញភាសា និងការវិភាគរូបភាព។",
    category: "Free Tier",
  },
  {
    id: "groq-llama-3.3-70b",
    name: "Aroch Speed 70B",
    provider: "ARUCH Engine",
    badge: "Aroch Speed",
    isFree: true,
    isLocked: false,
    isPremium: false,
    price: "Free",
    tagline: "ដំណើរការឆ្លើយតបលឿនបំផុត ខ្លាំងខាងតក្កវិជ្ជា ការគិត និងសរសេរកូដ។",
    description: "ដំណើរការឆ្លើយតបលឿនបំផុត ខ្លាំងខាងតក្កវិជ្ជា ការគិត និងសរសេរកូដ។",
    category: "Free Tier",
  },
  {
    id: "gemini-3.7-flash",
    name: "Aroch 3.7 Pro",
    provider: "ARUCH Core",
    badge: "PRO $2.00 🔒",
    isFree: false,
    isLocked: true,
    isPremium: true,
    price: "$2.00",
    tagline: "សមត្ថភាពវិភាគកម្រិតខ្ពស់ យល់រូបភាព និងដោះស្រាយការងារស្មុគស្មាញ។",
    description: "សមត្ថភាពវិភាគកម្រិតខ្ពស់ យល់រូបភាព និងដោះស្រាយការងារស្មុគស្មាញ។",
    category: "PRO $2.00",
  },
  {
    id: "gemini-3.8-flash",
    name: "Aroch 3.8 Pro",
    provider: "ARUCH Core",
    badge: "PRO $2.00 🔒",
    isFree: false,
    isLocked: true,
    isPremium: true,
    price: "$2.00",
    tagline: "បច្ចេកវិទ្យាកំពូលឆ្លាតវៃ ដំណើរការស្វ័យប្រវត្តិ និងឆ្លើយតបរហ័សបំផុត។",
    description: "បច្ចេកវិទ្យាកំពូលឆ្លាតវៃ ដំណើរការស្វ័យប្រវត្តិ និងឆ្លើយតបរហ័សបំផុត។",
    category: "PRO $2.00",
  },
];

export default function ChatInput({
  onSend,
  onOpenAttachmentSheet,
  onOpenVoiceSheet,
  onOpenSlideStyleSheet,
  onViewAttachment,
  attachments,
  onRemoveAttachment,
  disabled = false,
  placeholder,
  selectedModel = 'openai/gpt-4o',
  onModelChange,
  language = 'km',
  user,
  insertedText,
  onInsertedTextConsumed,
}: ChatInputProps) {
  const userEmail = user?.email?.toLowerCase().trim() || '';
  const userId = user?.uid || '';

  const defaultPlaceholder = placeholder || t('inputPlaceholder', language) || 'សួរ ARUCH AI...';
  const [text, setText] = useState('');

  // Handle external text insertion from bottom sheets (such as Slide Styles)
  useEffect(() => {
    if (insertedText) {
      setText(insertedText);
      if (onInsertedTextConsumed) onInsertedTextConsumed();
      if (textareaRef.current) {
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.focus();
            textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
          }
        }, 50);
      }
    }
  }, [insertedText, onInsertedTextConsumed]);
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [activeModel, setActiveModel] = useState(selectedModel);
  const [paymentModalModel, setPaymentModalModel] = useState<ModelOption | null>(null);

  const [openRouterModels, setOpenRouterModels] = useState<ModelOption[]>([]);

  useEffect(() => {
    fetch('/api/models')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setOpenRouterModels(data);
        }
      })
      .catch((err) => console.warn('Network issue fetching models:', err.message));
  }, []);

  const combinedModels = useMemo(() => {
    const map = new Map<string, ModelOption>();
    for (const m of AVAILABLE_MODELS) {
      if (m && m.id) map.set(m.id, m);
    }
    for (const m of openRouterModels) {
      if (m && m.id) map.set(m.id, { ...map.get(m.id), ...m });
    }
    return Array.from(map.values());
  }, [openRouterModels]);

  const [unlockedModels, setUnlockedModels] = useState<string[]>([]);

  // Strictly bind unlocked models to the specific Firebase user email
  useEffect(() => {
    if (!userEmail) {
      setUnlockedModels([]);
      return;
    }

    const userStorageKey = `makarize_unlocked_models_${userEmail}`;
    let localUnlocks: string[] = [];
    try {
      const saved = localStorage.getItem(userStorageKey);
      if (saved) localUnlocks = JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }

    setUnlockedModels(localUnlocks);

    if (userId) {
      fetchUserUnlocksFromFirebase(userId, userEmail).then((firebaseUnlocks) => {
        if (firebaseUnlocks && firebaseUnlocks.length > 0) {
          const merged = Array.from(new Set([...localUnlocks, ...firebaseUnlocks]));
          setUnlockedModels(merged);
          try {
            localStorage.setItem(userStorageKey, JSON.stringify(merged));
          } catch (e) {}
        }
      });
    }
  }, [userEmail, userId]);

  const { triggerSelection, triggerMedium, triggerLight, triggerWarning } = useHaptic();

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const modelPickerRef = useRef<HTMLDivElement>(null);
  const [isRecording, setIsRecording] = useState(false);
  const isRecordingRef = useRef(false);
  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition in Khmer (km-KH) with persistent auto-restart
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.lang = 'km-KH'; // ចាប់យកភាសាខ្មែរ
        recognition.continuous = true; // ឱ្យស្តាប់បន្តបន្ទាប់
        recognition.interimResults = true; // បង្ហាញអក្សរភ្លាមៗពេលកំពុងនិយាយ

        // ទទួលយកអត្ថបទដែលនិយាយរួច
        recognition.onresult = (event: any) => {
          let transcript = '';
          for (let i = 0; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
          }
          if (transcript) {
            setText(transcript);
          }
        };

        // ការពារកុំឱ្យ Timeout ឬបិទស្វ័យប្រវត្តិ
        recognition.onend = () => {
          if (isRecordingRef.current) {
            try {
              recognition.start();
            } catch (e) {
              console.log('Restarting speech listener...', e);
            }
          }
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech recognition notice:', event?.error);
          if (isRecordingRef.current && event?.error !== 'aborted') {
            try {
              recognition.start();
            } catch (e) {}
          }
        };

        recognitionRef.current = recognition;
      }
    }

    return () => {
      isRecordingRef.current = false;
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, []);

  const startListening = () => {
    isRecordingRef.current = true;
    setIsRecording(true);
    triggerMedium();

    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.log('Already started');
      }
    } else {
      onOpenVoiceSheet();
    }
  };

  const stopListening = () => {
    isRecordingRef.current = false;
    setIsRecording(false);
    triggerLight();

    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
  };

  const toggleVoiceRecording = () => {
    if (!isRecordingRef.current) {
      startListening();
    } else {
      stopListening();
    }
  };

  const handlePreviewText = () => {
    stopListening();
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }, 50);
  };

  useEffect(() => {
    if (selectedModel) setActiveModel(selectedModel);
  }, [selectedModel]);

  // Helper to determine if a model is locked
  const isModelLocked = (model: ModelOption | undefined) => {
    if (!model || !model.isPremium) return false;
    return !unlockedModels.includes(model.id) && !unlockedModels.includes('*');
  };

  const handleSelectModel = (model: ModelOption) => {
    if (isModelLocked(model)) {
      triggerWarning();
      setPaymentModalModel(model);
      setShowModelPicker(false);
      return;
    }
    triggerSelection();
    setActiveModel(model.id);
    if (onModelChange) onModelChange(model.id);
    setShowModelPicker(false);
  };

  const handleUnlockSuccess = (modelId: string, unlockAll?: boolean) => {
    let updatedList: string[];
    if (unlockAll) {
      updatedList = combinedModels.map((m) => m.id);
      updatedList.push('*');
    } else {
      updatedList = Array.from(new Set([...unlockedModels, modelId]));
    }
    setUnlockedModels(updatedList);

    if (userEmail) {
      const userStorageKey = `makarize_unlocked_models_${userEmail}`;
      try {
        localStorage.setItem(userStorageKey, JSON.stringify(updatedList));
      } catch (e) {
        console.error(e);
      }
    }

    setPaymentModalModel(null);
    setActiveModel(modelId);
    if (onModelChange) onModelChange(modelId);
  };

  // Auto-grow textarea height
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [text]);

  // Close model picker on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modelPickerRef.current && !modelPickerRef.current.contains(event.target as Node)) {
        setShowModelPicker(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if ((!text.trim() && attachments.length === 0) || disabled) return;
    triggerMedium();
    onSend(text.trim(), attachments, activeModel);
    setText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const currentModelObj = combinedModels.find((m) => m.id === activeModel) || combinedModels[0];
  const isCurrentModelLocked = isModelLocked(currentModelObj);

  return (
    <div className="relative w-full max-w-3xl mx-auto">
      {/* KHQR Payment Modal */}
      <KHQRPaymentModal
        isOpen={Boolean(paymentModalModel)}
        onClose={() => setPaymentModalModel(null)}
        targetModel={paymentModalModel}
        onUnlockSuccess={handleUnlockSuccess}
        user={user}
      />

      {/* Full Screen / Bottom Sheet Model Selector Modal */}
      <ModelSelectorModal
        isOpen={showModelPicker}
        onClose={() => setShowModelPicker(false)}
        models={combinedModels}
        activeModel={activeModel}
        unlockedModels={unlockedModels}
        onSelectModel={handleSelectModel}
        language={language}
      />

      {/* Model Selector Trigger & Active Tag */}
      <div className="mb-2 flex items-center justify-between px-2 text-xs">
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="btn-model-selector-trigger"
            onClick={() => {
              triggerLight();
              setShowModelPicker(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-full bg-[#18191c] px-3 py-1 text-xs font-medium text-[#e3e3e3] border border-[#2e3035] hover:border-[#4b4e54] hover:bg-[#202124] transition-all cursor-pointer shadow-sm active:scale-95"
          >
            {isCurrentModelLocked ? (
              <Lock size={12} className="text-amber-400" />
            ) : (
              <Sparkles size={12} className="text-[#a855f7]" />
            )}
            <span className="font-semibold">{currentModelObj?.name || 'Loading...'}</span>
            {isCurrentModelLocked && (
              <span className="rounded bg-amber-500/20 px-1.5 py-0.2 text-[9px] font-extrabold text-amber-400">
                Lock
              </span>
            )}
            <ChevronDown size={12} className="opacity-70 text-[#8e918f]" />
          </button>
        </div>

        <div className="text-[11px] text-[#8e918f] hidden sm:block">
          Shift + Enter for new line • Khmer Voice Enabled
        </div>
      </div>

      {/* Main Gemini Style Chat Bar (Pill Shape) */}
      <div className="relative rounded-[30px] border border-[#2e3038] bg-[#1e1f24] px-3.5 py-2 shadow-[0_4px_15px_rgba(0,0,0,0.3)] transition-all duration-300 focus-within:border-[#4285f4]/60 focus-within:ring-1 focus-within:ring-[#4285f4]/30">
        {/* Attachment Chips Previews */}
        {attachments.length > 0 && (
          <div className="mb-2 flex flex-wrap gap-2 px-1 pt-1">
            {attachments.map((att) => {
              const isImage = att.type?.startsWith('image/') || att.previewUrl?.startsWith('data:image/');
              return (
                <div
                  key={att.id}
                  className="flex items-center gap-2 rounded-xl border border-[#3c4043] bg-[#141516] px-2.5 py-1 text-xs text-[#e3e3e3] shadow-sm hover:border-[#4285f4]/50 transition-all"
                >
                  {isImage ? (
                    <img
                      src={att.previewUrl || `data:${att.type || att.mimeType};base64,${att.data}`}
                      alt={att.name}
                      className="h-6 w-6 rounded-md object-cover cursor-pointer"
                      onClick={() => {
                        triggerLight();
                        onViewAttachment(att);
                      }}
                    />
                  ) : (
                    <FileCode size={16} className="text-[#a8c7fa]" />
                  )}
                  <span
                    onClick={() => {
                      triggerLight();
                      onViewAttachment(att);
                    }}
                    className="max-w-[140px] truncate font-medium cursor-pointer hover:underline"
                    title={att.name}
                  >
                    {att.name}
                  </span>
                  <span className="text-[10px] text-[#8e918f]">({formatBytes(att.size)})</span>
                  <button
                    type="button"
                    onClick={() => {
                      triggerWarning();
                      onRemoveAttachment(att.id);
                    }}
                    className="rounded-full p-0.5 text-[#8e918f] hover:bg-[#28292a] hover:text-[#ea4335]"
                    title="Remove attachment"
                  >
                    <X size={13} />
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* Input Bar Content */}
        <div className="chat-input-bar flex items-center gap-2">
          {/* ប៊ូតុងសញ្ញាបូក (+) Add File */}
          <button
            type="button"
            id="btnPlusAttachment"
            onClick={() => {
              triggerLight();
              onOpenAttachmentSheet();
            }}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[#e3e3e3] hover:bg-white/10 hover:text-white transition-all active:scale-95 cursor-pointer"
            title="Add File / បន្ថែមឯកសារ"
          >
            <Plus size={22} />
          </button>

          {/* Central Input Content (Textarea or Waveform) */}
          <div className="flex-1 flex items-center min-w-0 mx-1">
            {isRecording ? (
              <div
                id="waveform"
                className="flex items-center justify-center gap-1.5 w-full h-8 cursor-pointer py-1"
                onClick={handlePreviewText}
                title="ចុចដើម្បីពិនិត្យ/កែសម្រួលអត្ថបទ"
              >
                <div className="gemini-wave-bar" style={{ animationDelay: '0.0s' }} />
                <div className="gemini-wave-bar" style={{ animationDelay: '0.2s' }} />
                <div className="gemini-wave-bar" style={{ animationDelay: '0.4s' }} />
                <div className="gemini-wave-bar" style={{ animationDelay: '0.1s' }} />
                <div className="gemini-wave-bar" style={{ animationDelay: '0.3s' }} />
                <div className="gemini-wave-bar" style={{ animationDelay: '0.5s' }} />
                <span className="ml-2 text-xs text-[#7cacf8] font-medium animate-pulse">
                  កំពុងស្តាប់ជាភាសាខ្មែរ...
                </span>
              </div>
            ) : (
              <textarea
                ref={textareaRef}
                id="chatInput"
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={defaultPlaceholder}
                rows={1}
                disabled={disabled}
                className="chat-input max-h-[160px] w-full resize-none"
              />
            )}
          </div>

          {/* Actions: Preview, Mic, Send */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* ប៊ូតុងមើល/កែអត្ថបទ (Preview Text) */}
            {(isRecording || (text && isRecording)) && (
              <button
                type="button"
                id="btnPreview"
                onClick={handlePreviewText}
                className="flex h-8 px-2.5 items-center justify-center gap-1 rounded-lg border border-[#444746] bg-[#28292a] text-[#c4c7c5] hover:bg-[#333537] hover:text-white transition-all text-xs active:scale-95"
                title="ពិនិត្យអត្ថបទ (Preview & Edit Text)"
              >
                <FileText size={14} />
                <span className="hidden sm:inline text-[11px]">កែអត្ថបទ</span>
              </button>
            )}

            {/* ប៊ូតុងមីក្រូហ្វូន (Mic) */}
            <button
              type="button"
              id="btnMic"
              onClick={toggleVoiceRecording}
              className={cn(
                'flex h-9 w-9 items-center justify-center rounded-full transition-all active:scale-95 cursor-pointer',
                isRecording
                  ? 'bg-red-500/20 text-[#ff5555] ring-2 ring-red-500/50 animate-pulse'
                  : 'text-[#a8c7fa] hover:bg-white/10'
              )}
              title={isRecording ? 'បញ្ឈប់ការនិយាយ (Stop)' : 'និយាយសំឡេងជាភាសាខ្មែរ (Voice Input)'}
            >
              <Mic size={19} />
            </button>

            {/* ប៊ូតុងផ្ញើ (Send) */}
            {(text.trim() || attachments.length > 0 || isRecording) && (
              <button
                type="button"
                id="btnSend"
                disabled={disabled || (!text.trim() && attachments.length === 0)}
                onClick={() => {
                  stopListening();
                  handleSend();
                }}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-[#2b66d9] text-white shadow-md hover:bg-[#3b76e9] transition-all active:scale-95 disabled:opacity-40 cursor-pointer"
                title="ផ្ញើ (Send)"
              >
                <ArrowUp size={18} strokeWidth={2.5} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
