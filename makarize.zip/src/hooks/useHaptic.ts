export * from '../lib/useHaptic';
export { default } from '../lib/useHaptic';
