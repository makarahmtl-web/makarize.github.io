import { useState } from 'react';
import { signInWithPopup } from '../lib/firebase';
import { motion } from 'motion/react';
import MakarizeLogo from './MakarizeLogo';
import { Shield, Scale } from 'lucide-react';

export default function AuthScreen({
  auth,
  provider,
  onOpenLegal,
}: {
  auth: any;
  provider: any;
  onOpenLegal?: (tab: 'privacy' | 'terms') => void;
}) {
  const [loading, setLoading] = useState(false);

  const handleSignIn = async () => {
    setLoading(true);
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#131314] p-4 text-[#e3e3e3]">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-md rounded-3xl border border-[#3c4043] bg-[#1e1f20] p-8 text-center shadow-2xl"
      >
        <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-3xl bg-[#28292a] border border-[#3c4043] p-3 shadow-xl">
          <MakarizeLogo size={68} />
        </div>

        <h1 className="mb-4 text-3xl font-bold tracking-tight text-[#e3e3e3]">Welcome to Makarize</h1>

        <p className="mb-8 text-sm text-[#8e918f]">
          Your next-generation AI assistant. Sign in with Google to start chatting, generating code, and analyzing ideas.
        </p>

        <button
          type="button"
          onClick={handleSignIn}
          disabled={loading}
          className="flex w-full items-center justify-center gap-3 rounded-2xl bg-white px-6 py-3.5 text-sm font-semibold text-black transition-all hover:bg-[#f1f3f4] hover:shadow-lg disabled:opacity-70 cursor-pointer"
        >
          {loading ? (
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-black border-t-transparent" />
          ) : (
            <>
              <svg className="h-5 w-5" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              <span>Continue with Google</span>
            </>
          )}
        </button>

        {/* Legal & Policy Links for Google Play Compliance */}
        <div className="mt-8 pt-6 border-t border-[#2e3035] flex flex-col items-center gap-2 text-xs text-[#8e918f]">
          <span>By signing in, you acknowledge that you agree to our:</span>
          <div className="flex items-center gap-3 font-medium">
            <button
              type="button"
              onClick={() => (onOpenLegal ? onOpenLegal('privacy') : (window.location.href = '/privacy'))}
              className="text-purple-400 hover:text-purple-300 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Shield size={12} />
              <span>Privacy Policy</span>
            </button>
            <span className="text-[#3c4043]">•</span>
            <button
              type="button"
              onClick={() => (onOpenLegal ? onOpenLegal('terms') : (window.location.href = '/terms'))}
              className="text-purple-400 hover:text-purple-300 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Scale size={12} />
              <span>Terms of Service</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
