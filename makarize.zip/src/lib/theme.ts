export type ThemeMode = 'dark' | 'light' | 'midnight' | 'purple' | 'system';

export interface ThemeConfig {
  id: ThemeMode;
  name: string;
  nameKm: string;
  background: string;
  surface: string;
  surfaceHover: string;
  textPrimary: string;
  textSecondary: string;
  border: string;
  primary: string;
  headerBg: string;
  sidebarBg: string;
  inputBg: string;
  cardBg: string;
}

export const THEMES: Record<'dark' | 'light' | 'midnight' | 'purple', ThemeConfig> = {
  dark: {
    id: 'dark',
    name: 'Obsidian Dark',
    nameKm: 'ងងឹត (Dark)',
    background: '#131314',
    surface: '#1e1f20',
    surfaceHover: '#28292a',
    textPrimary: '#e3e3e3',
    textSecondary: '#8e918f',
    border: '#3c4043',
    primary: '#9333ea',
    headerBg: '#131314',
    sidebarBg: '#17181b',
    inputBg: '#1e1f20',
    cardBg: '#18191a',
  },
  light: {
    id: 'light',
    name: 'Clean Light',
    nameKm: 'ភ្លឺ (Light)',
    background: '#f8f9fa',
    surface: '#ffffff',
    surfaceHover: '#f1f3f4',
    textPrimary: '#1f2024',
    textSecondary: '#5f6368',
    border: '#dadce0',
    primary: '#9333ea',
    headerBg: '#ffffff',
    sidebarBg: '#f1f3f4',
    inputBg: '#ffffff',
    cardBg: '#ffffff',
  },
  midnight: {
    id: 'midnight',
    name: 'Midnight Navy',
    nameKm: 'ខៀវរាត្រី (Midnight)',
    background: '#0b0f19',
    surface: '#111827',
    surfaceHover: '#1f2937',
    textPrimary: '#f3f4f6',
    textSecondary: '#9ca3af',
    border: '#1f2937',
    primary: '#6366f1',
    headerBg: '#0b0f19',
    sidebarBg: '#0f172a',
    inputBg: '#111827',
    cardBg: '#111827',
  },
  purple: {
    id: 'purple',
    name: 'Makarize Violet',
    nameKm: 'ពណ៌ស្វាយ (Violet)',
    background: '#120822',
    surface: '#1e0e33',
    surfaceHover: '#2d124d',
    textPrimary: '#f3e8ff',
    textSecondary: '#d8b4fe',
    border: '#3b0764',
    primary: '#a855f7',
    headerBg: '#120822',
    sidebarBg: '#170b2c',
    inputBg: '#1e0e33',
    cardBg: '#1e0e33',
  },
};

export function resolveTheme(mode: ThemeMode): 'dark' | 'light' | 'midnight' | 'purple' {
  if (mode === 'system') {
    if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
      return 'light';
    }
    return 'dark';
  }
  return mode || 'dark';
}

export function applyTheme(mode: ThemeMode) {
  if (typeof document === 'undefined') return;

  const resolved = resolveTheme(mode);
  const theme = THEMES[resolved] || THEMES.dark;
  const root = document.documentElement;

  root.setAttribute('data-theme', resolved);
  root.classList.remove('dark', 'light', 'midnight', 'purple');
  root.classList.add(resolved);

  // Set CSS variables
  root.style.setProperty('--color-background', theme.background);
  root.style.setProperty('--color-surface', theme.surface);
  root.style.setProperty('--color-surface-hover', theme.surfaceHover);
  root.style.setProperty('--color-text-primary', theme.textPrimary);
  root.style.setProperty('--color-text-secondary', theme.textSecondary);
  root.style.setProperty('--color-border', theme.border);
  root.style.setProperty('--color-primary', theme.primary);
  root.style.setProperty('--color-header-bg', theme.headerBg);
  root.style.setProperty('--color-sidebar-bg', theme.sidebarBg);
  root.style.setProperty('--color-input-bg', theme.inputBg);
  root.style.setProperty('--color-card-bg', theme.cardBg);
}
