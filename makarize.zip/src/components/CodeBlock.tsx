import React, { useState, useEffect } from 'react';
import { Check, Copy, Terminal, Code2, ExternalLink } from 'lucide-react';
import Prism from 'prismjs';
import 'prismjs/themes/prism-tomorrow.css';
import { useHaptic } from '../lib/useHaptic';
// Add basic language syntaxes
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-markdown';

interface CodeBlockProps {
  language?: string;
  code: string;
  onOpenInViewer?: (code: string, language: string) => void;
}

export default function CodeBlock({ language = 'text', code, onOpenInViewer }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const [highlightedCode, setHighlightedCode] = useState(code);
  const { triggerSuccess, triggerLight } = useHaptic();

  const cleanLang = (language || 'typescript').toLowerCase().replace('language-', '');

  useEffect(() => {
    try {
      const prismLang = Prism.languages[cleanLang] || Prism.languages.javascript || Prism.languages.text;
      if (prismLang) {
        setHighlightedCode(Prism.highlight(code, prismLang, cleanLang));
      } else {
        setHighlightedCode(code);
      }
    } catch {
      setHighlightedCode(code);
    }
  }, [code, cleanLang]);

  const handleCopy = async () => {
    try {
      triggerSuccess();
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  const handleDownload = () => {
    triggerLight();
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code-${Date.now()}.${cleanLang || 'txt'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const lineCount = code.split('\n').length;

  return (
    <div className="relative my-4 overflow-hidden rounded-2xl border border-[#3c4043] bg-[#141516] shadow-xl text-left">
      {/* Code Block Header */}
      <div className="flex items-center justify-between border-b border-[#28292a] bg-[#1c1d1f] px-4 py-2.5 text-xs text-[#8e918f]">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-[#a855f7]">
            <Code2 size={15} />
            <span className="font-mono font-semibold uppercase tracking-wider text-[11px] text-[#d8b4fe]">
              {cleanLang}
            </span>
          </div>
          <span className="text-[#5f6368]">•</span>
          <span className="text-[11px] text-[#8e918f] font-mono">{lineCount} {lineCount === 1 ? 'line' : 'lines'}</span>
        </div>

        <div className="flex items-center gap-1.5">
          {onOpenInViewer && (
            <button
              type="button"
              onClick={() => {
                triggerLight();
                onOpenInViewer(code, cleanLang);
              }}
              title="Expand in Bottom Sheet"
              className="flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] text-[#8e918f] hover:bg-[#28292a] hover:text-[#e3e3e3] transition-colors"
            >
              <ExternalLink size={12} />
              <span>Expand</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleDownload}
            title="Download code as file"
            className="flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] text-[#8e918f] hover:bg-[#28292a] hover:text-[#e3e3e3] transition-colors"
          >
            <span>Download</span>
          </button>

          <button
            type="button"
            onClick={handleCopy}
            title="Copy code to clipboard"
            className="flex items-center gap-1.5 rounded-lg bg-[#28292a] px-2.5 py-1 text-[11px] font-medium text-[#e3e3e3] hover:bg-[#333537] hover:text-white transition-all shadow-sm active:scale-95"
          >
            {copied ? (
              <>
                <Check size={12} className="text-[#34a853]" />
                <span className="text-[#34a853]">Copied!</span>
              </>
            ) : (
              <>
                <Copy size={12} />
                <span>Copy code</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Code Content */}
      <div className="overflow-x-auto p-4 font-mono text-[13px] leading-relaxed">
        <pre className="!m-0 !p-0 !bg-transparent text-[#e3e3e3]">
          <code
            className={`language-${cleanLang}`}
            dangerouslySetInnerHTML={{ __html: highlightedCode }}
          />
        </pre>
      </div>
    </div>
  );
}
