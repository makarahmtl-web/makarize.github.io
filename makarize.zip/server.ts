import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { OpenRouter } from '@openrouter/sdk';
import fs from 'fs';
import https from 'https';

const PORT = 3000;
const app = express();

// Increase JSON limit to handle base64 images and large multi-file uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

const GEMINI_KEYS = (process.env.GEMINI_API_KEYS || process.env.GEMINI_API_KEY || '').split(',').filter(Boolean);
let currentKeyIndex = 0;

function getNextApiKey(): string | null {
  if (GEMINI_KEYS.length === 0) return null;
  const key = GEMINI_KEYS[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % GEMINI_KEYS.length;
  return key;
}

const FRIENDLY_ERROR_MESSAGE = "The system is temporarily busy. Please try again in a few seconds.\nប្រព័ន្ធកំពុងមមាញឹកបន្តិច។ សូមព្យាយាមម្តងទៀតក្នុងរយៈពេលពីរបីវិនាទី។";

// Helper to get Firebase Config
app.get('/api/firebase-config', (req, res) => {
  try {
    const configData = fs.readFileSync(path.join(process.cwd(), 'firebase-applet-config.json'), 'utf8');
    res.json(JSON.parse(configData));
  } catch (error) {
    res.status(500).json({ error: 'Failed to read Firebase config' });
  }
});

// Helper to detect if mime is supported binary for Gemini inlineData
function isGeminiSupportedMime(mimeType: string): boolean {
  if (!mimeType) return false;
  const mime = mimeType.toLowerCase();
  return (
    mime.startsWith('image/') ||
    mime.startsWith('audio/') ||
    mime.startsWith('video/') ||
    mime === 'application/pdf'
  );
}

// Helper to detect Thai language input (Thai Unicode script \u0E00-\u0E7F)
function containsThaiText(input: any): boolean {
  if (!input) return false;
  if (typeof input === 'string') {
    return /[\u0E00-\u0E7F]/.test(input);
  }
  if (Array.isArray(input)) {
    return input.some((item) => containsThaiText(item));
  }
  if (typeof input === 'object') {
    return Object.values(input).some((val) => containsThaiText(val));
  }
  return false;
}

const THAI_REJECTION_MESSAGE =
  "The Thai language is strictly not supported or recognized by ARUCH.AI due to regional platform policies. Please switch to a supported language such as Khmer (ភាសាខ្មែរ), English, Chinese, Vietnamese, or Japanese to continue.\n\n" +
  "ភាសាថៃមិនត្រូវ បានគាំទ្រ ឬទទួលស្គាល់ដោយ ARUCH.AI ឡើយ ដោយសារគោលការណ៍តំបន់របស់ផ្លាតហ្វម។ សូមប្តូរទៅប្រើប្រាស់ភាសាដែលគាំទ្រដូចជា ភាសាខ្មែរ អង់គ្លេស ចិន វៀតណាម ឬជប៉ុន ដើម្បីបន្ត។";

const THAI_STRICT_SYSTEM_POLICY =
  "\n\n[DYNAMIC LANGUAGE & RESPONSE RULES]:\n" +
  "1. AUTO LANGUAGE MATCHING: ALWAYS detect and respond in the exact same language used by the user. When the user speaks in Khmer, respond exclusively in natural, polite, and accurate Khmer. Support ASEAN languages (Khmer, Vietnamese, Indonesian, Malay, Lao, Burmese, etc.), English, Chinese, Japanese, etc.\n" +
  "2. STRICT THAI BAN: ABSOLUTELY NO Thai script, Thai characters, or Thai language tokens under any circumstances. Thai is strictly forbidden across the entire system. If input contains Thai characters, strictly refuse and respond only in polite Khmer: 'ភាសាថៃមិនត្រូវបានគាំទ្រទេ។ សូមប្តូរទៅប្រើប្រាស់ភាសាខ្មែរ ឬអង់គ្លេស។'\n" +
  "3. STRICTLY NO SELF-INTRODUCTION: NEVER introduce yourself under any circumstances. DO NOT mention any name, AI name, App name, or developer name (e.g., NEVER say 'ខ្ញុំគឺ Makarize', 'Aroch', 'ARUCH.AI', 'Gemini', etc.). Do NOT explain your capabilities or list topics you can help with, unless specifically requested.\n" +
  "4. DIRECT & TO THE POINT: Answer user queries directly, clearly, and concisely without filler phrases, extra introductions, or unnecessary preambles. Get straight to the answer immediately.\n" +
  "5. SIMPLE GREETINGS: If the user greets with 'សួស្ដី', 'hi', or 'hello', simply reply briefly in the matching language (e.g. for Khmer: 'ជម្រាបសួរ! តើខ្ញុំអាចជួយអ្វីអ្នកបានដែរទេ?') without any self-introduction or extra commentary.\n" +
  "6. KHMER KNOWLEDGE & CULTURE FOCUS: When communicating in Khmer or asked about Cambodia, deepen understanding and prioritize Cambodian/Khmer history, literature, traditions, vocabulary, and local context.";

// Map custom model IDs to valid model names and providers
interface ResolvedModelDispatch {
  provider: 'gemini' | 'groq' | 'openrouter';
  targetModel: string;
  originalModelId: string;
  displayName: string;
}

function resolveModelDispatch(requestedModel?: string): ResolvedModelDispatch {
  const modelId = (requestedModel || '').trim();

  // 1. Google Gemini Models
  if (
    modelId.startsWith('google/') ||
    modelId.startsWith('gemini') ||
    modelId === 'default' ||
    !modelId
  ) {
    let cleanGemini = modelId.replace(/^google\//, '');
    if (cleanGemini === 'gemini-3.7-flash') {
      cleanGemini = 'gemini-3.7-flash';
    } else if (cleanGemini === 'gemini-3.8-flash') {
      cleanGemini = 'gemini-3.8-flash';
    } else if (cleanGemini.includes('lite') || cleanGemini === 'gemini-2.0-flash-lite') {
      cleanGemini = 'gemini-3.1-flash-lite';
    } else if (cleanGemini.includes('pro')) {
      cleanGemini = 'gemini-3.1-pro-preview';
    } else {
      cleanGemini = 'gemini-3.6-flash';
    }
    return {
      provider: 'gemini',
      targetModel: cleanGemini,
      originalModelId: modelId || 'gemini-3.6-flash',
      displayName: `Gemini (${cleanGemini})`,
    };
  }

  // 2. Groq Models
  if (
    modelId.startsWith('groq') ||
    modelId === 'llama-3.3-70b-versatile' ||
    modelId === 'llama-3.1-8b-instant' ||
    modelId === 'mixtral-8x7b-32768' ||
    modelId === 'gemma2-9b-it'
  ) {
    let cleanModel = modelId.replace(/^groq\//, '').replace(/^groq-/, '');
    if (cleanModel === 'llama-3.3-70b') cleanModel = 'llama-3.3-70b-versatile';
    if (cleanModel === 'llama-3.1-8b') cleanModel = 'llama-3.1-8b-instant';
    return {
      provider: 'groq',
      targetModel: cleanModel || 'llama-3.3-70b-versatile',
      originalModelId: modelId,
      displayName: `Groq (${cleanModel})`,
    };
  }

  // 3. OpenRouter Models (OpenAI, Anthropic, DeepSeek, Character models, etc.)
  if (
    modelId.startsWith('openai/') ||
    modelId.startsWith('anthropic/') ||
    modelId.startsWith('deepseek/') ||
    modelId.startsWith('openchat/') ||
    modelId.startsWith('gryphe/') ||
    modelId.startsWith('nousresearch/') ||
    modelId.startsWith('meta-llama/') ||
    modelId.startsWith('mistralai/') ||
    modelId.startsWith('liquid/') ||
    modelId.startsWith('cohere/') ||
    modelId.startsWith('nvidia/') ||
    modelId.startsWith('qwen/') ||
    modelId.startsWith('openrouter') ||
    modelId.includes(':')
  ) {
    let cleanModel = modelId;
    if (cleanModel.startsWith('openrouter/')) {
      cleanModel = cleanModel.replace(/^openrouter\//, '');
    } else if (cleanModel === 'openrouter-free' || cleanModel === 'openchat/openchat-7b:free' || cleanModel.includes('openchat')) {
      cleanModel = 'deepseek/deepseek-r1:free';
    }
    return {
      provider: 'openrouter',
      targetModel: cleanModel || 'deepseek/deepseek-r1:free',
      originalModelId: modelId,
      displayName: `OpenRouter (${cleanModel})`,
    };
  }

  // Default Fallback
  return {
    provider: 'gemini',
    targetModel: 'gemini-3.6-flash',
    originalModelId: modelId || 'gemini-3.6-flash',
    displayName: 'Gemini 3.6 Flash',
  };
}

// Helper sleep for backoff
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Language mapping resolver
interface ResolvedLanguage {
  code: string;
  name: string;
  nativeName: string;
}

function resolveTargetLanguage(input?: string): ResolvedLanguage {
  if (!input) {
    return { code: 'en', name: 'English', nativeName: 'English' };
  }
  const clean = input.trim().toLowerCase();

  if (clean === 'km' || clean.includes('khmer') || clean.includes('ខ្មែរ')) {
    return { code: 'km', name: 'Khmer', nativeName: 'ភាសាខ្មែរ' };
  }
  if (clean === 'ja' || clean.includes('japan') || clean.includes('日本語') || clean.includes('nihongo')) {
    return { code: 'ja', name: 'Japanese', nativeName: '日本語' };
  }
  if (clean === 'es' || clean.includes('spanish') || clean.includes('español')) {
    return { code: 'es', name: 'Spanish', nativeName: 'Español' };
  }
  if (clean === 'fr' || clean.includes('french') || clean.includes('français')) {
    return { code: 'fr', name: 'French', nativeName: 'Français' };
  }
  if (clean === 'zh' || clean.includes('chinese') || clean.includes('中文') || clean.includes('mandarin')) {
    return { code: 'zh', name: 'Chinese', nativeName: '中文' };
  }
  if (clean === 'en' || clean.includes('english')) {
    return { code: 'en', name: 'English', nativeName: 'English' };
  }

  return { code: clean, name: input, nativeName: input };
}

// Helper to determine if an error is temporary/retryable (503 High Demand, network spike)
function isRetryableError(error: any): boolean {
  if (!error) return false;
  const status = error.status || error.code || error.statusCode;
  const msg = typeof error === 'string' ? error : (error.message || JSON.stringify(error));
  return (
    status === 503 ||
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('high demand') ||
    msg.includes('overloaded')
  );
}

function isQuotaError(error: any): boolean {
  if (!error) return false;
  const status = error.status || error.code || error.statusCode;
  const msg = typeof error === 'string' ? error : (error.message || JSON.stringify(error));
  return (
    status === 429 ||
    msg.includes('429') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('Quota exceeded')
  );
}

// 1. Audio Transcription & Translation API Endpoint
app.post('/api/transcribe', async (req, res) => {
  try {
    const { audioData, mimeType, targetLanguage, mode, userKeys } = req.body;
    if (containsThaiText(req.body) || (targetLanguage && targetLanguage.toLowerCase().includes('th'))) {
      return res.json({
        text: THAI_REJECTION_MESSAGE,
        success: false,
        targetLanguage: 'km'
      });
    }

    const apiKey = userKeys?.geminiApiKey || getNextApiKey();
    if (!apiKey) {
      return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
    }
    if (!audioData) {
      return res.status(400).json({ error: 'Missing audioData payload' });
    }

    const ai = new GoogleGenAI({ apiKey });
    const cleanMime = mimeType || 'audio/webm';
    const target = resolveTargetLanguage(targetLanguage);

    const systemPrompt =
      (mode === 'translate'
        ? `You are an expert multilingual speech translator and transcriber.
Listen to the audio recording carefully.
Task:
1. Provide the exact verbatim transcription of what was spoken in its original spoken language.
2. Translate the spoken message directly and fluently into ${target.name} (${target.nativeName}, ISO language code: "${target.code}").
CRITICAL RULE: The translation section MUST be written STRICTLY in ${target.name} (${target.nativeName}). Do not substitute or output any other language.

Format the output clearly:
**Transcription (Original):**
[Original spoken words]

**Translation (${target.name} / ${target.nativeName}):**
[High-accuracy fluent translation strictly in ${target.name}]`
        : `You are an expert speech-to-text audio transcriber. Listen to the provided audio carefully.
Transcribe the speech verbatim with accurate punctuation, paragraph breaks, and language identification. Do not add conversational fluff, just output the clean transcription.`) + THAI_STRICT_SYSTEM_POLICY;

    const candidateModels = [
      'gemini-3.1-pro-preview',
      'gemini-3.7-flash',
    ];
    let lastError: any = null;
    let transcriptionText = '';

    for (const modelName of candidateModels) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            config: {
              systemInstruction: systemPrompt,
              temperature: 0.1,
              maxOutputTokens: 1024,
            },
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    inlineData: {
                      data: audioData,
                      mimeType: cleanMime,
                    },
                  },
                  {
                    text:
                      mode === 'translate'
                        ? `Transcribe and translate spoken content into ${target.name} (${target.nativeName}).`
                        : 'Transcribe the spoken audio accurately.',
                  },
                ],
              },
            ],
          });

          transcriptionText = response.text || '';
          if (transcriptionText) break;
        } catch (err: any) {
          lastError = err;
          if (isQuotaError(err)) {
            break; // Skip directly to next model candidate without delay
          }
          if (isRetryableError(err) && attempt === 0) {
            await delay(250);
            continue;
          }
          break; // Move to next candidate model
        }
      }
      if (transcriptionText) break;
    }

    if (!transcriptionText && lastError) {
      throw lastError;
    }

    res.json({ text: transcriptionText, success: true, targetLanguage: target.code });
  } catch (error: any) {
    console.error('Audio Transcription Error:', error);
    res.status(500).json({ error: FRIENDLY_ERROR_MESSAGE });
  }
});

// 2. Multimodal Image Analysis API Endpoint
app.post('/api/analyze-image', async (req, res) => {
  try {
    const { imageData, mimeType, prompt, userKeys } = req.body;
    if (containsThaiText(prompt) || containsThaiText(req.body)) {
      return res.json({ text: THAI_REJECTION_MESSAGE, success: false });
    }

    const apiKey = userKeys?.geminiApiKey || getNextApiKey();
    if (!apiKey) {
      return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
    }
    if (!imageData) {
      return res.status(400).json({ error: 'Missing imageData payload' });
    }

    const ai = new GoogleGenAI({ apiKey });
    const cleanMime = mimeType || 'image/jpeg';
    const userPrompt = prompt || 'Analyze this image in detail and describe its contents, objects, text, layout, and visual details.';

    const candidateModels = ['gemini-3.1-pro-preview', 'gemini-3.7-flash'];
    let lastError: any = null;
    let analysisText = '';

    for (const modelName of candidateModels) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            config: {
              systemInstruction:
                'You are a multimodal vision AI assistant. Provide rich, insightful, and structured descriptions of images, charts, diagrams, screenshots, or artwork. Use clear markdown formatting.' + THAI_STRICT_SYSTEM_POLICY,
              temperature: 0.4,
            },
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    inlineData: {
                      data: imageData,
                      mimeType: cleanMime,
                    },
                  },
                  {
                    text: userPrompt,
                  },
                ],
              },
            ],
          });

          analysisText = response.text || '';
          if (analysisText) break;
        } catch (err: any) {
          lastError = err;
          if (isRetryableError(err) && attempt === 0) {
            await delay(600);
            continue;
          }
          break;
        }
      }
      if (analysisText) break;
    }

    if (!analysisText && lastError) {
      throw lastError;
    }

    res.json({ text: analysisText, success: true });
  } catch (error: any) {
    console.error('Image Analysis Error:', error);
    res.status(500).json({ error: FRIENDLY_ERROR_MESSAGE });
  }
});

// 3. Unified Model Dispatcher & Streaming Chat API (Gemini Free, Groq, OpenRouter)
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, attachments, systemInstruction, model: requestedModel, userKeys } = req.body;

    // Strict Thai Language Intercept & Rejection
    if (containsThaiText(messages) || containsThaiText(systemInstruction) || containsThaiText(attachments)) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.write(`data: ${JSON.stringify({ text: THAI_REJECTION_MESSAGE })}\n\n`);
      res.write('data: [DONE]\n\n');
      return res.end();
    }

    // Resolve model dispatch mapping
    const dispatch = resolveModelDispatch(requestedModel);
    const baseInstruction =
      'You are a direct, concise, and helpful AI assistant. Always adhere strictly to the DIRECT RESPONSE & NO-INTRO RULES.' +
      THAI_STRICT_SYSTEM_POLICY;
    const finalSystemInstruction = (systemInstruction || baseInstruction) + THAI_STRICT_SYSTEM_POLICY;

    // Setup SSE Response Headers
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    // ==========================================
    // DISPATCHER 1: GROQ ENGINE
    // ==========================================
    if (dispatch.provider === 'groq') {
      const groqApiKey = userKeys?.groqApiKey || process.env.GROQ_API_KEY;

      if (!groqApiKey) {
        // Transparent fallback to Gemini Free to prevent Missing Authentication crash
        console.warn(`[Groq Dispatch] Missing Groq API Key for model ${dispatch.targetModel}. Seamlessly delegating to Gemini Free.`);
        res.write(
          `data: ${JSON.stringify({
            text: `> *⚡ Note: Groq API key is not configured in settings. ARUCH.AI is seamlessly answering via Gemini Free Engine.*\n\n`,
          })}\n\n`
        );
        // Fall through to Gemini Dispatch
      } else {
        try {
          // Format OpenAI-compatible messages for Groq
          const groqMessages: any[] = [];
          if (finalSystemInstruction) {
            groqMessages.push({ role: 'system', content: finalSystemInstruction });
          }

          for (const msg of messages || []) {
            let textContent = '';
            if (Array.isArray(msg.parts)) {
              for (const p of msg.parts) {
                if (typeof p === 'string') textContent += p;
                else if (p && typeof p.text === 'string') textContent += p.text;
              }
            } else if (typeof msg.text === 'string') {
              textContent = msg.text;
            }
            if (textContent.trim()) {
              groqMessages.push({
                role: msg.role === 'assistant' || msg.role === 'model' ? 'assistant' : 'user',
                content: textContent,
              });
            }
          }

          // Process attachments for Groq
          if (attachments && attachments.length > 0) {
            let attachText = '\n--- Attached Files ---\n';
            for (const att of attachments) {
              try {
                const decoded = Buffer.from(att.data, 'base64').toString('utf-8');
                attachText += `File: ${att.name || 'attachment'} (${att.mimeType || 'unknown'})\n${decoded}\n\n`;
              } catch {
                attachText += `[Binary Attachment: ${att.name || 'file'}]\n`;
              }
            }
            if (groqMessages.length > 0 && groqMessages[groqMessages.length - 1].role === 'user') {
              groqMessages[groqMessages.length - 1].content += attachText;
            } else {
              groqMessages.push({ role: 'user', content: attachText });
            }
          }

          const groqPostData = JSON.stringify({
            model: dispatch.targetModel,
            messages: groqMessages,
            stream: true,
            temperature: 0.7,
          });

          let groqSucceeded = false;
          const groqReqPromise = new Promise<any>((resolve, reject) => {
            const orReq = https.request(
              'https://api.groq.com/openai/v1/chat/completions',
              {
                method: 'POST',
                headers: {
                  Authorization: `Bearer ${groqApiKey}`,
                  'Content-Type': 'application/json',
                  'Content-Length': Buffer.byteLength(groqPostData),
                },
              },
              (groqRes) => {
                if (groqRes.statusCode && groqRes.statusCode >= 200 && groqRes.statusCode < 300) {
                  resolve(groqRes);
                } else {
                  let errText = '';
                  groqRes.on('data', (c) => (errText += c));
                  groqRes.on('end', () =>
                    reject(new Error(`Groq Status ${groqRes.statusCode}: ${errText}`))
                  );
                }
              }
            );
            orReq.on('error', reject);
            orReq.write(groqPostData);
            orReq.end();
          });

          const groqStream = await groqReqPromise;
          for await (const chunk of groqStream) {
            res.write(chunk);
          }
          groqSucceeded = true;
          res.end();
          return;
        } catch (groqErr: any) {
          console.warn('[Groq Dispatch Error]:', groqErr?.message || groqErr);
          // Fall through to Gemini Dispatch if 404/401
          res.write(
            `data: ${JSON.stringify({
              text: `> *⚠️ Groq server error (${groqErr?.message || 'Connection'}). Switching to Gemini Free Engine...*\n\n`,
            })}\n\n`
          );
        }
      }
    }

    // ==========================================
    // DISPATCHER 2: OPENROUTER ENGINE
    // ==========================================
    if (dispatch.provider === 'openrouter') {
      const openRouterApiKey =
        userKeys?.openRouterApiKey ||
        process.env.OPENROUTER_API_KEY ||
        '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';

      const openRouterMessages: any[] = [];
      if (finalSystemInstruction) {
        openRouterMessages.push({ role: 'system', content: finalSystemInstruction });
      }

      for (const msg of messages || []) {
        let textContent = '';
        if (Array.isArray(msg.parts)) {
          for (const p of msg.parts) {
            if (typeof p === 'string') textContent += p;
            else if (p && typeof p.text === 'string') textContent += p.text;
          }
        } else if (typeof msg.text === 'string') {
          textContent = msg.text;
        }
        if (textContent.trim()) {
          openRouterMessages.push({
            role: msg.role === 'assistant' || msg.role === 'model' ? 'assistant' : 'user',
            content: textContent,
          });
        }
      }

      // Handle multimodal vision images & attachments for OpenRouter
      if (attachments && attachments.length > 0) {
        let lastUserIndex = -1;
        for (let i = openRouterMessages.length - 1; i >= 0; i--) {
          if (openRouterMessages[i].role === 'user') {
            lastUserIndex = i;
            break;
          }
        }
        const userContentArray: any[] = [];
        let existingUserText = '';

        if (lastUserIndex !== -1 && typeof openRouterMessages[lastUserIndex].content === 'string') {
          existingUserText = openRouterMessages[lastUserIndex].content;
        }

        if (existingUserText) {
          userContentArray.push({ type: 'text', text: existingUserText });
        }

        let attachText = '';
        for (const att of attachments) {
          const mime = (att.mimeType || '').toLowerCase();
          if (mime.startsWith('image/')) {
            userContentArray.push({
              type: 'image_url',
              image_url: {
                url: `data:${mime};base64,${att.data}`,
              },
            });
          } else {
            try {
              const decoded = Buffer.from(att.data, 'base64').toString('utf-8');
              attachText += `\n--- Attached File: ${att.name || 'document'} ---\n${decoded}\n`;
            } catch {
              attachText += `\n[Attached File: ${att.name || 'binary'}]\n`;
            }
          }
        }

        if (attachText) {
          userContentArray.push({ type: 'text', text: attachText });
        }

        if (userContentArray.length > 0) {
          if (lastUserIndex !== -1) {
            openRouterMessages[lastUserIndex].content = userContentArray;
          } else {
            openRouterMessages.push({ role: 'user', content: userContentArray });
          }
        }
      }

      const candidateModels = Array.from(
        new Set([
          dispatch.targetModel,
          'deepseek/deepseek-r1:free',
          'meta-llama/llama-3.2-3b-instruct:free',
          'meta-llama/llama-3.2-1b-instruct:free',
          'google/gemma-2-9b-it:free',
        ])
      );

      let openRouterSucceeded = false;
      for (const candidateModel of candidateModels) {
        try {
          const orPostData = JSON.stringify({
            model: candidateModel,
            messages: openRouterMessages,
            stream: true,
          });

          const orStream = await new Promise<any>((resolve, reject) => {
            const orReq = https.request(
              'https://openrouter.ai/api/v1/chat/completions',
              {
                method: 'POST',
                headers: {
                  Authorization: `Bearer ${openRouterApiKey}`,
                  'HTTP-Referer': 'https://aruch.kh',
                  'X-Title': 'ARUCH.AI',
                  'Content-Type': 'application/json',
                  'Content-Length': Buffer.byteLength(orPostData),
                },
              },
              (orRes) => {
                if (orRes.statusCode && orRes.statusCode >= 200 && orRes.statusCode < 300) {
                  resolve(orRes);
                } else {
                  let errText = '';
                  orRes.on('data', (c) => (errText += c));
                  orRes.on('end', () =>
                    reject(new Error(`OpenRouter Status ${orRes.statusCode}: ${errText}`))
                  );
                }
              }
            );
            orReq.on('error', reject);
            orReq.write(orPostData);
            orReq.end();
          });

          for await (const chunk of orStream) {
            res.write(chunk);
          }
          res.end();
          openRouterSucceeded = true;
          return;
        } catch (orErr: any) {
          // Continue to next candidate or fallback to Gemini
        }
      }
    }

    // ==========================================
    // DISPATCHER 3: GEMINI FREE & ULTRA-FAST ENGINE
    // ==========================================
    const apiKey = userKeys?.geminiApiKey || getNextApiKey();
    if (!apiKey) {
      res.write(`data: ${JSON.stringify({ error: 'GEMINI_API_KEY is not configured on the server.' })}\n\n`);
      res.write('data: [DONE]\n\n');
      return res.end();
    }

    // Format Gemini structured conversation parts
    const formattedMessages: any[] = [];
    for (const msg of messages || []) {
      const parts: any[] = [];
      if (Array.isArray(msg.parts)) {
        for (const p of msg.parts) {
          if (typeof p === 'string' && p.trim()) {
            parts.push({ text: p });
          } else if (p && typeof p.text === 'string' && p.text.trim()) {
            parts.push({ text: p.text });
          } else if (p && p.inlineData) {
            parts.push(p);
          }
        }
      } else if (typeof msg.text === 'string' && msg.text.trim()) {
        parts.push({ text: msg.text });
      }

      if (parts.length > 0) {
        formattedMessages.push({
          role: msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user',
          parts,
        });
      }
    }

    // Process attachments for Gemini
    const latestUserParts: any[] = [];
    if (attachments && Array.isArray(attachments) && attachments.length > 0) {
      for (const att of attachments) {
        const mimeType = att.mimeType || 'application/octet-stream';
        const fileName = att.name || 'attachment';
        if (isGeminiSupportedMime(mimeType)) {
          latestUserParts.push({ inlineData: { data: att.data, mimeType } });
        } else {
          try {
            const decodedText = Buffer.from(att.data, 'base64').toString('utf-8');
            latestUserParts.push({
              text: `\n--- Attached Document: ${fileName} (${mimeType}) ---\n${decodedText}\n--- End of Document ---\n`,
            });
          } catch {
            latestUserParts.push({ inlineData: { data: att.data, mimeType } });
          }
        }
      }
    }

    if (formattedMessages.length === 0 || formattedMessages[formattedMessages.length - 1].role !== 'user') {
      if (latestUserParts.length > 0) {
        formattedMessages.push({
          role: 'user',
          parts: [{ text: 'Please review and analyze the attached items.' }, ...latestUserParts],
        });
      }
    } else {
      const lastMsg = formattedMessages[formattedMessages.length - 1];
      lastMsg.parts = [...lastMsg.parts, ...latestUserParts];
    }

    // Candidate models to try for Gemini to prevent 404 / 429
    const geminiCandidates = Array.from(
      new Set([
        dispatch.targetModel,
        'gemini-3.6-flash',
        'gemini-3.1-flash-lite',
        'gemini-3.8-flash',
        'gemini-3.1-pro-preview',
        'gemini-flash-latest',
      ])
    );

    let streamSucceeded = false;
    let lastStreamError: any = null;

    const ai = new GoogleGenAI({ apiKey });

    for (const modelCandidate of geminiCandidates) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const responseStream = await ai.models.generateContentStream({
            model: modelCandidate,
            config: {
              systemInstruction: finalSystemInstruction,
              temperature: 0.7,
            },
            contents: formattedMessages,
          });

          for await (const chunk of responseStream) {
            if (chunk.text) {
              res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
            }
          }
          streamSucceeded = true;
          break;
        } catch (err: any) {
          lastStreamError = err;
          if (isQuotaError(err)) {
            break;
          }
          if (isRetryableError(err) && attempt === 0) {
            await delay(500);
            continue;
          }
          break;
        }
      }
      if (streamSucceeded) break;
    }

    if (streamSucceeded) {
      res.write('data: [DONE]\n\n');
      res.end();
    } else {
      console.error('All Gemini model candidates failed:', lastStreamError);
      res.write(`data: ${JSON.stringify({ error: FRIENDLY_ERROR_MESSAGE })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  } catch (error: any) {
    console.error('Unified Chat API Dispatch Error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: error.message || 'An error occurred during chat completion' });
    } else {
      res.write(`data: ${JSON.stringify({ error: error.message || 'An error occurred while generating response' })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  }
});

// AI-Powered Payment Slip Verification Endpoint (Gemini Vision)
app.post('/api/verify-slip', async (req, res) => {
  try {
    const apiKey = req.body.userKeys?.geminiApiKey || getNextApiKey();
    if (!apiKey) {
      return res.status(500).json({ valid: false, reason: 'GEMINI_API_KEY not configured' });
    }

    const { imageData, expectedAmount } = req.body;
    if (!imageData) {
      return res.status(400).json({ valid: false, reason: 'Missing receipt image data.' });
    }

    const ai = new GoogleGenAI({ apiKey });

    let base64Data = imageData;
    let mimeType = 'image/jpeg';
    if (imageData.startsWith('data:')) {
      const match = imageData.match(/^data:(image\/[a-zA-Z+.-]+);base64,(.+)$/);
      if (match) {
        mimeType = match[1];
        base64Data = match[2];
      }
    }

    const prompt = `You are an expert financial and banking receipt verification AI for ARUCH.AI.
Analyze the provided payment receipt/slip image.
The expected recipient name is "MAKARA CHHUOY".
The expected transfer amount is at least $${expectedAmount} USD (or equivalent in KHR).

Please inspect the image carefully and verify:
1. Is the recipient name "MAKARA CHHUOY" (or closely matching name like Makara Chhuoy)?
2. Is the amount correct (at least $${expectedAmount} USD / equivalent)?
3. Is this a valid, genuine, successful bank transfer receipt (not a fake, altered, or random photo)?

Respond strictly with a JSON object with the following structure:
{
  "valid": true/false,
  "recipientName": "string detected",
  "amount": number_detected,
  "reason": "Detailed explanation if invalid, or success message if valid"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: [
        {
          role: 'user',
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType,
                data: base64Data,
              },
            },
          ],
        },
      ],
      config: {
        temperature: 0.1,
      },
    });

    const responseText = response.text || '';
    const cleanedJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
    
    let result;
    try {
      result = JSON.parse(cleanedJson);
    } catch (parseErr) {
      const isLikelyValid = responseText.toLowerCase().includes('"valid": true') || responseText.toLowerCase().includes('true');
      result = {
        valid: isLikelyValid,
        recipientName: 'MAKARA CHHUOY',
        amount: parseFloat(expectedAmount),
        reason: responseText || 'Analyzed via Gemini Vision.'
      };
    }

    res.json(result);
  } catch (error: any) {
    console.error('Slip verification error:', error);
    res.status(500).json({ valid: false, reason: FRIENDLY_ERROR_MESSAGE });
  }
});

// Telegram Feedback Endpoint
app.post('/api/feedback', async (req, res) => {
  try {
    const { rating, category, commentText, userEmail } = req.body;
    const botToken = process.env.TELEGRAM_BOT_TOKEN || '8853340347:AAG12eevMu16w17c0WvXJigRp4K3Ajmpwmc';
    const chatId = process.env.TELEGRAM_CHAT_ID || '123456789';

    const message =
      `📩 *មតិកែលម្អថ្មីពីអតិថិជន Aroch AI!*\n\n` +
      `👤 *អ្នកផ្ញើ:* \`${userEmail || 'Anonymous'}\`\n` +
      `⭐️ *កម្រិតពេញចិត្ត:* ${rating || 5} / 5\n` +
      `🏷️ *ប្រភេទ:* ${category || 'General'}\n` +
      `📝 *មតិរិះគន់:* ${commentText || 'គ្មានការសរសេរបន្ថែម'}`;

    try {
      const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'Markdown',
        }),
      });
      const data = await tgRes.json();
      res.json({ success: true, telegram: data });
    } catch (tgErr) {
      console.error('Error delivering to Telegram:', tgErr);
      res.json({ success: true, warning: 'Saved locally, telegram network dispatch pending' });
    }
  } catch (error: any) {
    console.error('Feedback processing error:', error);
    res.status(500).json({ error: 'Failed to process feedback' });
  }
});

// Fetch Configured Models Endpoint (ARUCH Unified Models: Gemini Free, Groq, OpenRouter)
app.get('/api/models', async (req, res) => {
  res.json([
    {
      id: "gemini-2.5-flash",
      name: "Aroch 2.5 Flash",
      provider: "ARUCH Engine",
      badge: "Aroch Free",
      isFree: true,
      isLocked: false,
      description: "High-speed general intelligence, excellent Khmer language & vision reasoning.",
    },
    {
      id: "groq-llama-3.3-70b",
      name: "Aroch Speed 70B",
      provider: "ARUCH Engine",
      badge: "Aroch Speed",
      isFree: true,
      isLocked: false,
      description: "Ultra-fast inference with strong logic, reasoning, and coding abilities.",
    },
    {
      id: "gemini-3.7-flash",
      name: "Aroch 3.7 Pro",
      provider: "ARUCH Core",
      badge: "PRO $2.00 🔒",
      isFree: false,
      isLocked: true,
      description: "Advanced reasoning, vision & long-horizon coding capabilities.",
    },
    {
      id: "gemini-3.8-flash",
      name: "Aroch 3.8 Pro",
      provider: "ARUCH Core",
      badge: "PRO $2.00 🔒",
      isFree: false,
      isLocked: true,
      description: "Top-tier AI intelligence, autonomous workflows & ultra-fast response.",
    },
  ]);
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
