import { useRef } from 'react';
import { motion } from 'motion/react';
import { Image, Video, FileText, Music, Mic } from 'lucide-react';
import { Attachment } from '../types';
import { getFileCategory, fileToBase64 } from '../lib/fileUtils';

interface AttachmentMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onFilesSelected: (attachments: Attachment[]) => void;
  onStartAudioRecording?: () => void;
}

export default function AttachmentMenu({
  isOpen,
  onClose,
  onFilesSelected,
  onStartAudioRecording,
}: AttachmentMenuProps) {
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const processFiles = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;

    const newAttachments: Attachment[] = [];
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      try {
        const base64Data = await fileToBase64(file);
        const category = getFileCategory(file);
        const previewUrl = category === 'image' || category === 'video' || category === 'audio'
          ? URL.createObjectURL(file)
          : '';

        newAttachments.push({
          id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
          file,
          name: file.name,
          size: file.size,
          data: base64Data,
          mimeType: file.type || 'application/octet-stream',
          previewUrl,
          typeCategory: category,
        });
      } catch (err) {
        console.error('Failed to parse file:', file.name, err);
      }
    }

    if (newAttachments.length > 0) {
      onFilesSelected(newAttachments);
    }
    onClose();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    processFiles(e.target.files);
    e.target.value = '';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 10, scale: 0.96 }}
      transition={{ duration: 0.16, ease: 'easeOut' }}
      className="absolute bottom-16 left-0 z-50 flex w-64 flex-col gap-1 overflow-hidden rounded-2xl border border-[#3c4043] bg-[#28292a] p-2 shadow-2xl backdrop-blur-xl"
    >
      {/* Hidden File Inputs for Specific Categories (all support multiple) */}
      <input
        type="file"
        ref={imageInputRef}
        className="hidden"
        multiple
        accept="image/*"
        onChange={handleInputChange}
      />
      <input
        type="file"
        ref={videoInputRef}
        className="hidden"
        multiple
        accept="video/*"
        onChange={handleInputChange}
      />
      <input
        type="file"
        ref={docInputRef}
        className="hidden"
        multiple
        accept=".pdf,.doc,.docx,.txt,.csv,.json,.md,.html,.js,.ts,.tsx,.py,application/pdf,text/*"
        onChange={handleInputChange}
      />
      <input
        type="file"
        ref={audioInputRef}
        className="hidden"
        multiple
        accept="audio/*"
        onChange={handleInputChange}
      />

      {/* Upload Image Option */}
      <button
        type="button"
        onClick={() => imageInputRef.current?.click()}
        className="group flex w-full items-center gap-3.5 rounded-xl px-3.5 py-3 text-sm font-medium text-[#e3e3e3] transition-all hover:bg-[#3c4043]"
      >
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#4285f4]/15 text-[#4285f4] transition-transform group-hover:scale-110">
          <Image size={18} />
        </div>
        <div className="flex flex-col text-left">
          <span className="text-sm font-medium">Upload Images</span>
          <span className="text-[11px] text-[#8e918f]">PNG, JPG, WebP, GIF</span>
        </div>
      </button>

      {/* Upload Video Option */}
      <button
        type="button"
        onClick={() => videoInputRef.current?.click()}
        className="group flex w-full items-center gap-3.5 rounded-xl px-3.5 py-3 text-sm font-medium text-[#e3e3e3] transition-all hover:bg-[#3c4043]"
      >
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#9b72cb]/15 text-[#9b72cb] transition-transform group-hover:scale-110">
          <Video size={18} />
        </div>
        <div className="flex flex-col text-left">
          <span className="text-sm font-medium">Upload Videos</span>
          <span className="text-[11px] text-[#8e918f]">MP4, WebM, QuickTime</span>
        </div>
      </button>

      {/* Upload Document Option */}
      <button
        type="button"
        onClick={() => docInputRef.current?.click()}
        className="group flex w-full items-center gap-3.5 rounded-xl px-3.5 py-3 text-sm font-medium text-[#e3e3e3] transition-all hover:bg-[#3c4043]"
      >
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#34a853]/15 text-[#34a853] transition-transform group-hover:scale-110">
          <FileText size={18} />
        </div>
        <div className="flex flex-col text-left">
          <span className="text-sm font-medium">Upload Documents</span>
          <span className="text-[11px] text-[#8e918f]">PDF, DOCX, TXT, CSV, Code</span>
        </div>
      </button>

      {/* Upload Audio Option */}
      <button
        type="button"
        onClick={() => audioInputRef.current?.click()}
        className="group flex w-full items-center gap-3.5 rounded-xl px-3.5 py-3 text-sm font-medium text-[#e3e3e3] transition-all hover:bg-[#3c4043]"
      >
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#fbbc04]/15 text-[#fbbc04] transition-transform group-hover:scale-110">
          <Music size={18} />
        </div>
        <div className="flex flex-col text-left">
          <span className="text-sm font-medium">Upload Audio</span>
          <span className="text-[11px] text-[#8e918f]">MP3, WAV, AAC, OGG</span>
        </div>
      </button>

      {onStartAudioRecording && (
        <>
          <div className="my-1 h-[1px] bg-[#3c4043]/60" />
          {/* Record Audio Action */}
          <button
            type="button"
            onClick={() => {
              onClose();
              onStartAudioRecording();
            }}
            className="group flex w-full items-center gap-3.5 rounded-xl px-3.5 py-2.5 text-sm font-medium text-[#e3e3e3] transition-all hover:bg-[#3c4043]"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#ea4335]/15 text-[#ea4335] transition-transform group-hover:scale-110">
              <Mic size={18} />
            </div>
            <div className="flex flex-col text-left">
              <span className="text-sm font-medium">Record Audio</span>
              <span className="text-[11px] text-[#8e918f]">Live voice prompt</span>
            </div>
          </button>
        </>
      )}
    </motion.div>
  );
}
