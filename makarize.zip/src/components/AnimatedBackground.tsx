import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function AnimatedBackground({ mode }: { mode: 'none' | 'rain' | 'snow' | 'matrix' | 'shooting-stars' | 'orbs' | 'aurora' | 'sunset' }) {
  if (mode === 'none') return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {mode === 'rain' && (
        <div className="absolute inset-0 opacity-20">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-[1px] h-10 bg-white"
              initial={{ top: -50, left: `${Math.random() * 100}%` }}
              animate={{ top: '100%' }}
              transition={{ duration: Math.random() * 2 + 1, repeat: Infinity, ease: 'linear', delay: Math.random() * 2 }}
            />
          ))}
        </div>
      )}
      {mode === 'snow' && (
        <div className="absolute inset-0 opacity-40">
          {[...Array(30)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-white rounded-full"
              initial={{ top: -10, left: `${Math.random() * 100}%` }}
              animate={{ top: '100%', left: `${Math.random() * 100}%` }}
              transition={{ duration: Math.random() * 5 + 5, repeat: Infinity, ease: 'linear', delay: Math.random() * 5 }}
            />
          ))}
        </div>
      )}
      {mode === 'matrix' && (
        <div className="absolute inset-0 opacity-20 bg-black">
          {[...Array(40)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-green-500 font-mono text-xs"
              initial={{ top: -20, left: `${Math.random() * 100}%`, opacity: Math.random() }}
              animate={{ top: '100%' }}
              transition={{ duration: Math.random() * 2 + 2, repeat: Infinity, ease: 'linear', delay: Math.random() * 2 }}
            >
              {String.fromCharCode(65 + Math.random() * 26)}
            </motion.div>
          ))}
        </div>
      )}
      {mode === 'shooting-stars' && (
        <div className="absolute inset-0 overflow-hidden bg-[#050510]">
           {[...Array(10)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full"
              initial={{ top: `${Math.random() * 50}%`, left: -10, opacity: 0 }}
              animate={{ top: `${Math.random() * 50}%`, left: '110%', opacity: 1 }}
              transition={{ duration: Math.random() * 2 + 1, repeat: Infinity, delay: Math.random() * 5 }}
            />
          ))}
        </div>
      )}
      {mode === 'orbs' && (
        <div className="absolute inset-0 bg-[#0a0a0a]">
           {[...Array(15)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-16 h-16 bg-purple-500 rounded-full mix-blend-screen blur-xl"
              initial={{ bottom: -100, left: `${Math.random() * 100}%` }}
              animate={{ bottom: '110%', left: `${Math.random() * 100}%` }}
              transition={{ duration: Math.random() * 10 + 5, repeat: Infinity, ease: 'linear' }}
            />
          ))}
        </div>
      )}
      {mode === 'aurora' && (
        <div className="absolute inset-0 bg-gradient-to-r from-green-900 via-blue-900 to-purple-900 opacity-40 animate-pulse" />
      )}
      {mode === 'sunset' && (
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900 via-orange-900 to-black opacity-60" />
      )}
    </div>
  );
}
