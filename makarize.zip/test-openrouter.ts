import { OpenRouter } from '@openrouter/sdk';
console.log(Object.keys(OpenRouter.prototype));
