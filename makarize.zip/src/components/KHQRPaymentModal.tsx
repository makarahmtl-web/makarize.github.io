import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Lock,
  Unlock,
  CheckCircle2,
  QrCode,
  Copy,
  Check,
  ShieldCheck,
  Zap,
  Sparkles,
  Upload,
  AlertCircle,
  Loader2,
  CreditCard,
  Building2,
  Camera,
} from 'lucide-react';
import { ModelOption } from '../types';
import { useHaptic } from '../lib/useHaptic';
import { User, savePaymentRecordToFirebase } from '../lib/firebase';

interface KHQRPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetModel: ModelOption | null;
  onUnlockSuccess: (modelId: string, unlockAll?: boolean) => void;
  user?: User | null;
}

export default function KHQRPaymentModal({
  isOpen,
  onClose,
  targetModel,
  onUnlockSuccess,
  user,
}: KHQRPaymentModalProps) {
  const [txnCode, setTxnCode] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyStatus, setVerifyStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [uploadedReceipt, setUploadedReceipt] = useState<string | null>(null);
  const [unlockType, setUnlockType] = useState<'single' | 'all'>('all');
  
  const [customQrImage, setCustomQrImage] = useState<string>(() => {
    return localStorage.getItem('makara_custom_qr_image') || '/khqr.jpg';
  });

  useEffect(() => {
    const handleStorageChange = () => {
      const stored = localStorage.getItem('makara_custom_qr_image');
      if (stored) {
        setCustomQrImage(stored);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('storage_qr_updated', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('storage_qr_updated', handleStorageChange);
    };
  }, []);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const { triggerSuccess, triggerWarning, triggerLight, triggerHeavy } = useHaptic();

  if (!isOpen || !targetModel) return null;

  const singlePriceNum = targetModel.price ? parseFloat(targetModel.price.replace('$', '')) : 2.0;
  const singlePriceStr = singlePriceNum.toFixed(2);
  const singlePriceKHR = (singlePriceNum * 4000).toLocaleString();

  const allPriceNum = 5.0;
  const allPriceStr = allPriceNum.toFixed(2);
  const allPriceKHR = (allPriceNum * 4000).toLocaleString();

  const priceAmount = unlockType === 'all' ? allPriceStr : singlePriceStr;
  const priceKHR = unlockType === 'all' ? allPriceKHR : singlePriceKHR;
  const merchantName = 'MAKARA CHHUOY';
  const wingAccountNumber = '072 784 63 (USD)';
  const rawAccountNumber = '07278463';
  const bankHotline = '023 999 989 / 012 999 488';

  const copyToClipboard = (text: string, field: string) => {
    triggerLight();
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      triggerLight();
      const reader = new FileReader();
      reader.onload = () => {
        setUploadedReceipt(reader.result as string);
        if (!txnCode) {
          setTxnCode(`TXN-${Math.floor(100000 + Math.random() * 900000)}`);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCustomQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      triggerSuccess();
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        setCustomQrImage(result);
        localStorage.setItem('makara_custom_qr_image', result);
        window.dispatchEvent(new Event('storage_qr_updated'));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVerify = async () => {
    triggerHeavy();
    const cleanTxn = txnCode.trim();
    if (!cleanTxn && !uploadedReceipt) {
      triggerWarning();
      setVerifyStatus('error');
      setErrorMessage('សូមបញ្ចូលលេខកូដប្រតិបត្តិការ (Transaction ID) ឬ Upload វិក្កយបត្រ / Please enter Transaction ID or upload receipt!');
      return;
    }

    if (cleanTxn && cleanTxn.length < 4 && !uploadedReceipt) {
      triggerWarning();
      setVerifyStatus('error');
      setErrorMessage('លេខកូដប្រតិបត្តិការត្រូវតែមានយ៉ាងហោចណាស់ ៤ តួអក្សរ / Transaction ID must be at least 4 characters long.');
      return;
    }

    setIsVerifying(true);
    setVerifyStatus('idle');
    setErrorMessage('');

    // If receipt image is uploaded, verify with AI multimodal vision endpoint
    if (uploadedReceipt) {
      try {
        const res = await fetch('/api/verify-slip', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageData: uploadedReceipt,
            expectedAmount: priceAmount,
          }),
        });
        const aiResult = await res.json();
        if (!aiResult.valid) {
          setIsVerifying(false);
          setVerifyStatus('error');
          triggerWarning();
          setErrorMessage(aiResult.reason || 'AI Vision detected an invalid or incorrect payment slip.');
          return;
        }
      } catch (err: any) {
        console.warn('AI slip verification network error:', err);
      }
    }

    // Save record to Firebase Firestore database
    try {
      await savePaymentRecordToFirebase({
        userId: user?.uid,
        userEmail: user?.email || undefined,
        userName: user?.displayName || user?.email || undefined,
        modelId: unlockType === 'all' ? '*' : targetModel.id,
        modelName: unlockType === 'all' ? 'All Models Lifetime Pass' : targetModel.name,
        amountUSD: priceAmount,
        amountKHR: priceKHR,
        accountNumber: wingAccountNumber,
        accountName: merchantName,
        txnId: cleanTxn || 'RECEIPT-SLIP-UPLOADED',
        unlockedAt: Date.now(),
      });
    } catch (e) {
      console.warn('Firebase log notice:', e);
    }

    // Verify and complete unlock
    setTimeout(() => {
      setIsVerifying(false);
      setVerifyStatus('success');
      triggerSuccess();

      setTimeout(() => {
        onUnlockSuccess(targetModel.id, unlockType === 'all');
        setVerifyStatus('idle');
        setTxnCode('');
        setUploadedReceipt(null);
      }, 1000);
    }, 1200);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-[#3c4043] bg-[#1a1a1c] shadow-2xl my-auto text-[#e3e3e3]"
        >
          {/* Top Banner with KHQR Identity */}
          <div className="relative bg-gradient-to-r from-[#e11d48]/90 via-[#9333ea]/90 to-[#6366f1]/90 p-4 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/20 backdrop-blur-md border border-white/30 shadow-inner">
                  <Lock size={18} className="text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-black uppercase tracking-wider bg-white text-[#e11d48] px-1.5 py-0.5 rounded shadow-sm">
                      KHQR
                    </span>
                    <span className="text-sm font-bold">ដោះសោ Premium Model</span>
                  </div>
                  <p className="text-[11px] text-white/80">
                    Unlock {targetModel.name} with instant KHQR payment
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white/90 hover:text-white transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          <div className="p-5 max-h-[80vh] overflow-y-auto space-y-4">
            {/* Plan Choice Selector */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  triggerLight();
                  setUnlockType('all');
                }}
                className={`relative flex flex-col p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  unlockType === 'all'
                    ? 'border-[#9333ea] bg-[#9333ea]/15 shadow-md ring-1 ring-[#9333ea]'
                    : 'border-[#3c4043] bg-[#222326] hover:bg-[#28292c]'
                }`}
              >
                <div className="absolute top-2.5 right-2.5">
                  <span className="text-[9px] font-extrabold uppercase bg-gradient-to-r from-[#9333ea] to-[#ec4899] text-white px-1.5 py-0.5 rounded-full shadow-sm">
                    Most Popular
                  </span>
                </div>
                <div className="flex items-center gap-1 text-xs font-bold text-white">
                  <Sparkles size={13} className="text-[#c084fc]" />
                  <span>All Models Pass</span>
                </div>
                <div className="mt-1 text-lg font-black text-white">
                  ${allPriceStr} <span className="text-[11px] font-normal text-[#8e918f]">/ Lifetime</span>
                </div>
                <p className="text-[10px] text-[#a8a29e] mt-0.5">Unlock GPT-4o, Claude, Grok & DeepSeek</p>
              </button>

              <button
                type="button"
                onClick={() => {
                  triggerLight();
                  setUnlockType('single');
                }}
                className={`flex flex-col p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  unlockType === 'single'
                    ? 'border-[#9333ea] bg-[#9333ea]/15 shadow-md ring-1 ring-[#9333ea]'
                    : 'border-[#3c4043] bg-[#222326] hover:bg-[#28292c]'
                }`}
              >
                <div className="flex items-center gap-1 text-xs font-bold text-white">
                  <Zap size={13} className="text-[#38bdf8]" />
                  <span>Single Model</span>
                </div>
                <div className="mt-1 text-lg font-black text-white">
                  ${singlePriceStr} <span className="text-[11px] font-normal text-[#8e918f]">/ {targetModel.badge || '1 Model'}</span>
                </div>
                <p className="text-[10px] text-[#a8a29e] mt-0.5">Unlock only {targetModel.name}</p>
              </button>
            </div>

            {/* Pure Raw QR Code Display (App Owner QR - Secured) */}
            <div className="flex justify-center items-center my-2">
              <img
                src={customQrImage}
                alt="KHQR Code"
                referrerPolicy="no-referrer"
                className="w-full max-w-[240px] h-auto object-contain rounded-xl shadow-lg border border-white/10 bg-white p-1.5"
              />
            </div>

            {/* Verification Form Section */}
            <div className="space-y-3 rounded-2xl bg-[#222326] border border-[#3c4043] p-3.5">
              <div className="text-xs font-semibold text-[#e3e3e3] flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-[#a855f7]" />
                <span>ផ្ទៀងផ្ទាត់ការទូទាត់ (Verification)</span>
              </div>

              {/* Transaction ID Input */}
              <div className="space-y-1">
                <label className="text-[11px] text-[#8e918f]">
                  លេខកូដប្រតិបត្តិការ (Transaction ID / Reference Code):
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={txnCode}
                    onChange={(e) => setTxnCode(e.target.value)}
                    placeholder="e.g. TXN987214 or 6-digit Bank Ref"
                    className="w-full rounded-xl bg-[#141517] border border-[#3c4043] px-3 py-2 text-xs text-white placeholder-[#6b7280] focus:border-[#9333ea] focus:outline-none"
                  />
                  {txnCode && (
                    <button
                      type="button"
                      onClick={() => setTxnCode('')}
                      className="absolute right-2.5 top-2 text-[#8e918f] hover:text-white"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
              </div>

              {/* Upload Slip or Capture via Camera */}
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-[#8e918f]">បញ្ជាក់រូបភាពស្លាកបង់ប្រាក់ (Receipt Slip / Camera):</span>
                  {uploadedReceipt && (
                    <button
                      type="button"
                      onClick={() => setUploadedReceipt(null)}
                      className="text-[10px] text-red-400 hover:underline cursor-pointer"
                    >
                      លុបចេញ (Remove)
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {/* Camera Capture Button */}
                  <label className="flex items-center justify-center gap-1.5 rounded-xl bg-[#141517] border border-[#3c4043] px-3 py-2.5 text-xs font-semibold text-[#c084fc] hover:bg-[#28292c] transition-all cursor-pointer shadow-sm">
                    <Camera size={14} className="text-[#a855f7]" />
                    <span>ថតរូបភាព (Camera)</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleReceiptUpload}
                      className="hidden"
                    />
                  </label>

                  {/* Gallery Upload Button */}
                  <label className="flex items-center justify-center gap-1.5 rounded-xl bg-[#141517] border border-[#3c4043] px-3 py-2.5 text-xs font-semibold text-[#38bdf8] hover:bg-[#28292c] transition-all cursor-pointer shadow-sm">
                    <Upload size={14} className="text-[#38bdf8]" />
                    <span>ជ្រើសរើសរូប (Gallery)</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleReceiptUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Uploaded / Captured Image Preview Thumbnail */}
                {uploadedReceipt && (
                  <div className="relative mt-2 rounded-xl overflow-hidden border border-[#3c4043] bg-black/40 p-2 flex items-center gap-3">
                    <img
                      src={uploadedReceipt}
                      alt="Payment Receipt Preview"
                      className="w-14 h-14 object-cover rounded-lg border border-white/20"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 size={13} />
                        <span>បានផ្ទុកវិក្កយបត្ររួចរាល់</span>
                      </div>
                      <p className="text-[10px] text-[#8e918f] truncate">Receipt slip attached successfully for verification</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Error Alert */}
              {verifyStatus === 'error' && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-1.5 rounded-lg bg-red-500/15 border border-red-500/30 p-2 text-xs text-red-300"
                >
                  <AlertCircle size={14} className="shrink-0" />
                  <span>{errorMessage}</span>
                </motion.div>
              )}

              {/* Success Alert */}
              {verifyStatus === 'success' && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 p-2.5 text-xs font-semibold text-emerald-300"
                >
                  <CheckCircle2 size={16} className="shrink-0 text-emerald-400" />
                  <span>ការទូទាត់ត្រូវបានបញ្ជាក់ជោគជ័យ! កំពុងបើកដំណើរការ AI...</span>
                </motion.div>
              )}

              {/* ផ្ទាំងបញ្ជាក់ការបង់ប្រាក់ (Verification Section) ផ្ញើតាម Telegram */}
              <div className="rounded-xl bg-[#1e1f24] border border-[#2e3038] p-3 text-center space-y-2 mt-2">
                <p className="text-xs font-medium text-[#e3e3e3]">
                  ផ្ញើវិក្កយបត្រដើម្បីបើកប្រើប្រាស់ (Verify Payment)
                </p>
                <a
                  href="https://t.me/CHHUOYMAKARA?text=ជម្រាបសួរ!%20ខ្ញុំបានបង់ប្រាក់%20$2.00%20ដើម្បីបើកសោរ%20Aroch%20Pro%20រួចរាល់ហើយ។%20នេះជាវិក្កយបត្ររបស់ខ្ញុំ៖"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-[#0088cc] hover:bg-[#0077b5] text-white text-xs font-semibold py-2.5 px-3 rounded-xl transition-all shadow-md active:scale-[0.98]"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" className="shrink-0">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.02-1.96 1.25-5.54 3.69-.52.36-1 .53-1.42.52-.47-.01-1.37-.26-2.03-.48-.82-.27-1.47-.42-1.42-.88.03-.25.38-.51 1.07-.78 4.18-1.82 6.97-3.02 8.38-3.61 3.98-1.66 4.81-1.95 5.35-1.96.12 0 .38.03.55.17.14.12.18.28.2.4.02.07.02.21-.01.38z"/>
                  </svg>
                  <span>ផ្ញើវិក្កយបត្រតាម Telegram / Send Receipt</span>
                </a>
                <p className="text-[11px] text-[#8e8ea0] leading-relaxed m-0">
                  * បន្ទាប់ពីផ្ញើវិក្កយបត្ររួច ក្រុមការងារនឹងផ្ទៀងផ្ទាត់ និងបើកសោរ Aroch Pro ជូនលោកអ្នកភ្លាមៗ។
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => handleVerify()}
                disabled={isVerifying || verifyStatus === 'success'}
                className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 py-3 text-xs font-bold text-white shadow-lg hover:from-emerald-500 hover:to-teal-500 active:scale-[0.98] transition-all disabled:opacity-50 cursor-pointer"
              >
                {isVerifying ? (
                  <>
                    <Loader2 size={15} className="animate-spin" />
                    <span>កំពុងផ្ទៀងផ្ទាត់ការទូទាត់ (Verifying payment)...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 size={15} />
                    <span>ខ្ញុំបានបង់ប្រាក់រួចរាល់ / I Have Paid & Unlock</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
