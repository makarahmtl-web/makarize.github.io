import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Lock,
  Check,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import { ModelOption } from '../types';
import { useHaptic } from '../lib/useHaptic';
import { cn } from '../lib/utils';

interface ModelSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  models: ModelOption[];
  activeModel: string;
  unlockedModels: string[];
  onSelectModel: (model: ModelOption) => void;
  language?: string;
}

export const MODEL_SELECTOR_I18N: Record<
  string,
  {
    title: string;
    subtitle: string;
    btn_unlock: string;
    badge_free: string;
    models: Record<string, { name: string; description: string }>;
  }
> = {
  km: {
    title: "ជ្រើសរើសម៉ូឌែល Aroch AI",
    subtitle: "ជ្រើសរើសម៉ូឌែលសមស្របតាមតម្រូវការរបស់អ្នក",
    btn_unlock: "បើកសោ",
    badge_free: "ឥតគិតថ្លៃ",
    models: {
      "gemini-2.5-flash": {
        name: "Aroch 2.5 Flash",
        description: "ប្រព័ន្ធវៃឆ្លាតលឿនរហ័ស ស្ទាត់ជំនាញភាសា និងការវិភាគរូបភាព។",
      },
      "groq-llama-3.3-70b": {
        name: "Aroch Speed 70B",
        description: "ដំណើរការឆ្លើយតបលឿនបំផុត ខ្លាំងខាងតក្កវិជ្ជា ការគិត និងសរសេរកូដ។",
      },
      "gemini-3.7-flash": {
        name: "Aroch 3.7 Pro",
        description: "សមត្ថភាពវិភាគកម្រិតខ្ពស់ យល់រូបភាព និងដោះស្រាយការងារស្មុគស្មាញ។",
      },
      "gemini-3.8-flash": {
        name: "Aroch 3.8 Pro",
        description: "បច្ចេកវិទ្យាកំពូលឆ្លាតវៃ ដំណើរការស្វ័យប្រវត្តិ និងឆ្លើយតបរហ័សបំផុត។",
      },
    },
  },
  lo: {
    title: "ເລືອກໂມເດັນ Aroch AI",
    subtitle: "ເລືອກໂມເດັນທີ່ເໝາະສົມກັບຄວາມຕ້ອງການຂອງທ່ານ",
    btn_unlock: "ປົດລັອກ",
    badge_free: "ຟຣີ",
    models: {
      "gemini-2.5-flash": {
        name: "Aroch 2.5 Flash",
        description: "ລະບົບອັດສະລິຍະຄວາມໄວສູງ ເຂົ້າໃຈພາສາ ແລະ ວິເຄາະຮູບພາບ.",
      },
      "groq-llama-3.3-70b": {
        name: "Aroch Speed 70B",
        description: "ປະມວນຜົນໄວທີ່ສຸດ ເກັ່ງດ້ານຕັກກະ ແລະ ການຂຽນໂຄ້ດ.",
      },
      "gemini-3.7-flash": {
        name: "Aroch 3.7 Pro",
        description: "ຄວາມສາມາດວິເຄາະຂັ້ນສູງ ເຂົ້າໃຈຮູບພາບ ແລະ ວຽກງານຊັບຊ້ອນ.",
      },
      "gemini-3.8-flash": {
        name: "Aroch 3.8 Pro",
        description: "ເທັກໂນໂລຢີອັດສະລິຍະຂັ້ນສູງສຸດ ປະມວນຜົນອັດໂຕໂນມັດ ແລະ ຕອບຮອບໄວ.",
      },
    },
  },
  my: {
    title: "Aroch AI မော်ဒယ်ကို ရွေးချယ်ပါ",
    subtitle: "သင့်လိုအပ်ချက်အတွက် သင့်တော်သော မော်ဒယ်ကို ရွေးချယ်ပါ",
    btn_unlock: "သော့ဖွင့်ပါ",
    badge_free: "အခမဲ့",
    models: {
      "gemini-2.5-flash": {
        name: "Aroch 2.5 Flash",
        description: "မြန်ဆန်သော အသိဥာဏ်စနစ်၊ ဘာသာစကားနှင့် ပုံရိပ်များကို ခွဲခြမ်းစိတ်ဖြာနိုင်သည်။",
      },
      "groq-llama-3.3-70b": {
        name: "Aroch Speed 70B",
        description: "အလွန်မြန်ဆန်သော လုပ်ဆောင်ချက်၊ စာရေးသားခြင်းနှင့် ကုတ်ရေးသားခြင်းတွင် လျှင်မြန်သည်။",
      },
      "gemini-3.7-flash": {
        name: "Aroch 3.7 Pro",
        description: "အဆင့်မြင့် ဆင်ခြင်တုံတရားနှင့် ရှုပ်ထွေးသော ပရိုဂရမ်းမင်း စွမ်းရည်များ။",
      },
      "gemini-3.8-flash": {
        name: "Aroch 3.8 Pro",
        description: "ထိပ်တန်း AI အသိဥာဏ်နှင့် အလွန်မြန်ဆန်သော တုံ့ပြန်မှု။",
      },
    },
  },
};

export default function ModelSelectorModal({
  isOpen,
  onClose,
  models,
  activeModel,
  unlockedModels,
  onSelectModel,
  language = 'km',
}: ModelSelectorModalProps) {
  const { triggerLight } = useHaptic();

  const langKey = MODEL_SELECTOR_I18N[language] ? language : 'km';
  const i18n = MODEL_SELECTOR_I18N[langKey];

  const isModelLocked = (model: ModelOption) => {
    if (model.isFree === true || model.isLocked === false) return false;
    if (!model.isPremium && model.isLocked === undefined) return false;
    return !unlockedModels.includes(model.id) && !unlockedModels.includes('*');
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
        {/* Backdrop click to dismiss */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0"
        />

        {/* Modal / Bottom Sheet Card */}
        <motion.div
          initial={{ opacity: 0, y: '100%' }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: '100%' }}
          transition={{ type: 'spring', damping: 26, stiffness: 300 }}
          className="relative w-full max-w-lg overflow-hidden rounded-t-[28px] sm:rounded-3xl border border-[#3c4043] bg-[#18191c] shadow-2xl z-10 max-h-[85vh] flex flex-col text-[#e3e3e3]"
        >
          {/* Mobile Drag Indicator */}
          <div className="mx-auto mt-2.5 h-1.5 w-12 rounded-full bg-[#4a4d52] sm:hidden" />

          {/* Header */}
          <div className="flex items-center justify-between px-5 pt-3.5 pb-3 border-b border-[#28292c]">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-purple-500/20 border border-purple-500/30 text-purple-400">
                <Sparkles size={16} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">{i18n.title}</h3>
                <p className="text-[11px] text-[#8e918f]">{i18n.subtitle}</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                triggerLight();
                onClose();
              }}
              className="p-1.5 rounded-full bg-[#28292c] hover:bg-[#34363a] text-[#8e918f] hover:text-white transition-colors cursor-pointer"
            >
              <X size={17} />
            </button>
          </div>

          {/* Clean Model Items List */}
          <div className="p-4 sm:p-5 overflow-y-auto space-y-2.5 flex-1">
            {models.map((m) => {
              const locked = isModelLocked(m);
              const isSelected = activeModel === m.id && !locked;
              const modelMeta = i18n.models[m.id];
              const displayName = modelMeta?.name || m.name;
              const displayDesc = modelMeta?.description || m.description || m.tagline;

              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    onSelectModel(m);
                  }}
                  className={cn(
                    'w-full flex items-center justify-between p-3.5 rounded-2xl border text-left transition-all cursor-pointer group',
                    isSelected
                      ? 'bg-purple-950/30 border-purple-500 text-white shadow-sm ring-1 ring-purple-500/50'
                      : locked
                      ? 'bg-[#141517] hover:bg-[#1a1b1e] border-[#2e3035] text-[#c4c7c5]'
                      : 'bg-[#1a1b1f] hover:bg-[#232428] border-[#2e3035] text-[#c4c7c5]'
                  )}
                >
                  <div className="flex-1 min-w-0 pr-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-white group-hover:text-purple-300 transition-colors">
                        {displayName}
                      </span>
                      {locked ? (
                        <span className="flex items-center gap-1 rounded bg-amber-500/20 border border-amber-500/40 px-1.5 py-0.5 text-[9.5px] font-bold text-amber-300">
                          <Lock size={10} />
                          <span>PRO {m.price || '$2.00'}</span>
                        </span>
                      ) : (
                        <span className="rounded bg-emerald-500/20 border border-emerald-500/30 px-1.5 py-0.5 text-[9.5px] font-bold text-emerald-400">
                          {i18n.badge_free}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[#8e918f] mt-1 leading-snug">
                      {displayDesc}
                    </p>
                  </div>

                  <div className="shrink-0 flex items-center">
                    {locked ? (
                      <div className="flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/30 shadow-sm">
                        <Lock size={12} />
                        <span>{i18n.btn_unlock}</span>
                      </div>
                    ) : isSelected ? (
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-purple-600 text-white shadow-sm">
                        <Check size={14} />
                      </div>
                    ) : (
                      <ChevronRight size={16} className="text-[#4a4d52] group-hover:text-white transition-colors" />
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}


