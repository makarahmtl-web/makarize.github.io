/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { User, initFirebase, onAuthStateChanged } from './lib/firebase';
import AuthScreen from './components/AuthScreen';
import Chat from './components/Chat';
import LegalPage from './components/LegalPage';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [firebaseData, setFirebaseData] = useState<{ auth: any; provider: any } | null>(null);

  // Standalone Route detection for /privacy and /terms (Google Play compliance)
  const [standaloneLegal, setStandaloneLegal] = useState<'privacy' | 'terms' | null>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (path === '/privacy' || path === '/privacy/' || hash === '#privacy' || hash === '#/privacy') {
        return 'privacy';
      }
      if (path === '/terms' || path === '/terms/' || hash === '#terms' || hash === '#/terms') {
        return 'terms';
      }
    }
    return null;
  });

  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (path === '/privacy' || path === '/privacy/' || hash === '#privacy' || hash === '#/privacy') {
        setStandaloneLegal('privacy');
      } else if (path === '/terms' || path === '/terms/' || hash === '#terms' || hash === '#/terms') {
        setStandaloneLegal('terms');
      } else {
        setStandaloneLegal(null);
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  useEffect(() => {
    let unsubscribe: () => void;

    const setupFirebase = async () => {
      try {
        const { auth, provider } = await initFirebase();
        setFirebaseData({ auth, provider });

        unsubscribe = onAuthStateChanged(auth, (currentUser) => {
          setUser(currentUser);
          setLoading(false);
        });
      } catch (error) {
        console.error('Firebase init failed:', error);
        setLoading(false);
      }
    };

    setupFirebase();

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Standalone view for Google Play Console public verification
  if (standaloneLegal) {
    return (
      <LegalPage
        initialTab={standaloneLegal}
        onBack={() => {
          if (window.history.length > 1) {
            window.history.pushState({}, '', '/');
            setStandaloneLegal(null);
          } else {
            window.location.href = '/';
          }
        }}
      />
    );
  }

  if (loading || !firebaseData) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#131314]">
        <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <>
      {user ? (
        <Chat user={user} auth={firebaseData.auth} />
      ) : (
        <AuthScreen
          auth={firebaseData.auth}
          provider={firebaseData.provider}
          onOpenLegal={(tab) => {
            window.history.pushState({}, '', `/${tab}`);
            setStandaloneLegal(tab);
          }}
        />
      )}
    </>
  );
}

