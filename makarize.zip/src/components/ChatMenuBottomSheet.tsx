import React, { useState } from 'react';
import { Share2, Pin, PinOff, BookOpen, Edit2, HelpCircle, MessageSquare, Trash2, Check, Shield } from 'lucide-react';
import BottomSheet from './BottomSheet';
import { cn } from '../lib/utils';
import { useHaptic } from '../lib/useHaptic';

interface ChatMenuBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  isPinned: boolean;
  onTogglePin: () => void;
  onRename: () => void;
  onDelete: () => void;
  onShare: () => void;
  onAddToNotebook: () => void;
  onHelp: () => void;
  onFeedback: () => void;
  onOpenLegal?: (tab: 'privacy' | 'terms') => void;
}

export default function ChatMenuBottomSheet({
  isOpen,
  onClose,
  isPinned,
  onTogglePin,
  onRename,
  onDelete,
  onShare,
  onAddToNotebook,
  onHelp,
  onFeedback,
  onOpenLegal,
}: ChatMenuBottomSheetProps) {
  const haptics = useHaptic();
  const [deleteConfirm, setDeleteConfirm] = useState(false);

  // Reset delete confirmation when modal closes
  React.useEffect(() => {
    if (!isOpen) {
      setDeleteConfirm(false);
    }
  }, [isOpen]);

  const handleAction = (action: () => void) => {
    haptics.triggerMedium();
    action();
    onClose();
  };

  const menuItems = [
    {
      id: 'share',
      icon: <Share2 size={20} className="text-[#a8abb0]" />,
      label: 'Share conversation',
      sublabel: 'ចែករំលែកការសន្ទនា',
      onClick: () => handleAction(onShare),
      danger: false,
    },
    {
      id: 'pin',
      icon: isPinned ? <PinOff size={20} className="text-purple-400" /> : <Pin size={20} className="text-[#a8abb0]" />,
      label: isPinned ? 'Remove Pin' : 'Pin conversation',
      sublabel: isPinned ? 'ដកការខ្ទាស់ចេញ' : 'ខ្ទាស់ការសន្ទនាទុកនៅខាងលើ',
      onClick: () => handleAction(onTogglePin),
      danger: false,
    },
    {
      id: 'notebook',
      icon: <BookOpen size={20} className="text-[#a8abb0]" />,
      label: 'Add to notebook',
      sublabel: 'រក្សាទុកក្នុងសៀវភៅកត់ត្រា',
      onClick: () => handleAction(onAddToNotebook),
      danger: false,
    },
    {
      id: 'rename',
      icon: <Edit2 size={20} className="text-[#a8abb0]" />,
      label: 'Rename',
      sublabel: 'ប្តូរឈ្មោះប្រធានបទ',
      onClick: () => handleAction(onRename),
      danger: false,
    },
    {
      id: 'help',
      icon: <HelpCircle size={20} className="text-purple-400" />,
      label: 'Help & AI Guide',
      sublabel: 'មជ្ឈមណ្ឌលជំនួយ & ការណែនាំ AI',
      onClick: () => handleAction(onHelp),
      danger: false,
    },
    {
      id: 'feedback',
      icon: <MessageSquare size={20} className="text-pink-400" />,
      label: 'Feedback',
      sublabel: 'ផ្ញើមតិកែលម្អ & វាយតម្លៃ',
      onClick: () => handleAction(onFeedback),
      danger: false,
    },
    {
      id: 'legal',
      icon: <Shield size={20} className="text-purple-400" />,
      label: 'Privacy Policy & Terms',
      sublabel: 'គោលការណ៍ឯកជនភាព & លក្ខខណ្ឌ',
      onClick: () => {
        handleAction(() => {
          if (onOpenLegal) onOpenLegal('privacy');
          else window.location.href = '/privacy';
        });
      },
      danger: false,
    },
  ];

  return (
    <BottomSheet isOpen={isOpen} onClose={onClose} showHandle={true} maxHeight="max-h-[90vh]">
      <div className="flex flex-col p-2 gap-1 mb-6">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={item.onClick}
            className={cn(
              "flex items-center justify-between w-full p-3.5 rounded-2xl transition-all cursor-pointer",
              "hover:bg-[#28292a] active:scale-[0.98]",
              item.danger ? "text-red-400 hover:text-red-300" : "text-[#e3e3e3]"
            )}
          >
            <div className="flex items-center gap-3.5">
              <div className="flex-shrink-0">
                {item.icon}
              </div>
              <div className="text-left">
                <span className="text-sm font-medium block">{item.label}</span>
                {item.sublabel && (
                  <span className="text-[11px] text-[#8e918f] block">{item.sublabel}</span>
                )}
              </div>
            </div>
          </button>
        ))}

        {/* Delete Action - with confirmation */}
        {deleteConfirm ? (
          <div className="flex flex-col gap-3 mt-4 p-4 rounded-2xl bg-red-500/10 border border-red-500/20">
            <p className="text-sm text-red-400 font-medium text-center">Permanently delete this chat?</p>
            <div className="flex gap-2">
              <button
                onClick={() => setDeleteConfirm(false)}
                className="flex-1 py-3 rounded-xl bg-[#28292a] text-[#e3e3e3] font-medium hover:bg-[#3c4043] transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleAction(onDelete)}
                className="flex-1 py-3 rounded-xl bg-red-500 text-white font-medium hover:bg-red-600 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => {
              haptics.triggerMedium();
              setDeleteConfirm(true);
            }}
            className={cn(
              "flex items-center gap-4 w-full p-4 rounded-2xl transition-all mt-2 cursor-pointer",
              "hover:bg-red-500/10 active:scale-[0.98] text-red-400"
            )}
          >
            <div className="flex-shrink-0">
              <Trash2 size={20} />
            </div>
            <span className="text-base font-medium">Delete chat</span>
          </button>
        )}
      </div>
    </BottomSheet>
  );
}
