import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  BookOpen,
  PenTool,
  MessageSquareText,
  Sparkles,
  Check,
  Copy,
  ChevronRight,
  HelpCircle,
  Lightbulb,
  Cpu,
  FileSearch,
  Volume2,
  Share2,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useHaptic } from '../lib/useHaptic';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUsePrompt?: (promptText: string) => void;
}

type HelpTab = 'usage' | 'prompts' | 'chatting' | 'features';

export default function HelpModal({ isOpen, onClose, onUsePrompt }: HelpModalProps) {
  const [activeTab, setActiveTab] = useState<HelpTab>('usage');
  const [copiedPromptIndex, setCopiedPromptIndex] = useState<number | null>(null);
  const { triggerSelection, triggerLight, triggerSuccess } = useHaptic();

  if (!isOpen) return null;

  const handleCopyPrompt = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    triggerSuccess();
    setCopiedPromptIndex(index);
    setTimeout(() => setCopiedPromptIndex(null), 2000);
  };

  const handleUsePrompt = (text: string) => {
    triggerSelection();
    if (onUsePrompt) {
      onUsePrompt(text);
      onClose();
    }
  };

  const promptExamples = [
    {
      title: 'សរសេរអត្ថបទទីផ្សារ / Marketing Post',
      prompt: 'សូមជួយសរសេរ Caption ហ្វេសប៊ុកសម្រាប់ផ្សព្វផ្សាយផលិតផលថែរក្សាស្បែក ដោយប្រើពាក្យទាក់ទាញ មាន Emoji សមរម្យ និងមាន Call-to-Action ច្បាស់លាស់។',
      category: 'ទីផ្សារ & មាតិកា',
    },
    {
      title: 'បង្កើតគំនិតអាជីវកម្ម / Business Strategy',
      prompt: 'ខ្ញុំចង់ចាប់ផ្តើមអាជីវកម្មខ្នាតតូចទាក់ទងនឹងសេវាកម្មដឹកជញ្ជូនរហ័សនៅកម្ពុជា។ សូមវិភាគចំណុចខ្លាំង ចំណុចខ្សោយ (SWOT) និងយុទ្ធសាស្ត្រទាក់ទាញអតិថិជនដំបូង។',
      category: 'យុទ្ធសាស្ត្រអាជីវកម្ម',
    },
    {
      title: 'ជួយសរសេរ និងពិនិត្យកូដ / Coding Assistant',
      prompt: 'សូមជួយបង្កើតមុខងារ JavaScript សម្រាប់ Validate លេខទូរស័ព្ទនៅប្រទេសកម្ពុជា (Smart, Cellcard, Metfone) និងពន្យល់កូដមួយជំហានៗ។',
      category: 'ព័ត៌មានវិទ្យា & កូដ',
    },
    {
      title: 'បកប្រែ និងកែសម្រួលវេយ្យាករណ៍ / Translation & Editing',
      prompt: 'សូមជួយបកប្រែអត្ថបទខាងក្រោមពីភាសាអង់គ្លេសមកភាសាខ្មែរផ្លូវការ ឱ្យមានន័យស្រទន់ និងត្រឹមត្រូវតាមក្បួនវេយ្យាករណ៍ខ្មែរ៖ [ដាក់អត្ថបទនៅទីនេះ]',
      category: 'ការបកប្រែភាសា',
    },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
        <motion.div
          initial={{ opacity: 0, y: '100%' }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: '100%' }}
          transition={{ type: 'spring', damping: 26, stiffness: 300 }}
          className="relative w-full max-w-2xl overflow-hidden rounded-t-[28px] sm:rounded-3xl border border-[#3c4043] bg-[#18191c] shadow-2xl z-10 max-h-[90vh] flex flex-col text-[#e3e3e3]"
        >
          {/* Mobile Handle */}
          <div className="mx-auto mt-2.5 h-1.5 w-12 rounded-full bg-[#4a4d52] sm:hidden" />

          {/* Modal Header */}
          <div className="flex items-center justify-between px-5 pt-3.5 pb-3 border-b border-[#28292c]">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-500/20 border border-purple-500/30 text-purple-400">
                <HelpCircle size={20} />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">មជ្ឈមណ្ឌលជំនួយ & ការណែនាំ AI</h3>
                <p className="text-[11.5px] text-[#8e918f]">ស្វែងយល់ពីរបៀបប្រើប្រាស់ និងគន្លឹះឆ្លាតវៃជាមួយ Aroch AI</p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-[#28292a] text-[#8e918f] hover:text-white transition-colors cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Horizontal Navigation Tabs */}
          <div className="flex items-center gap-1.5 px-4 pt-3 pb-2 border-b border-[#28292c] bg-[#141517] overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => {
                triggerLight();
                setActiveTab('usage');
              }}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border',
                activeTab === 'usage'
                  ? 'bg-purple-600 border-purple-500 text-white shadow-sm'
                  : 'bg-[#1e1f23] border-[#2e3035] text-[#8e918f] hover:text-white'
              )}
            >
              <BookOpen size={13} />
              <span>១. របៀបប្រើប្រាស់</span>
            </button>

            <button
              type="button"
              onClick={() => {
                triggerLight();
                setActiveTab('prompts');
              }}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border',
                activeTab === 'prompts'
                  ? 'bg-purple-600 border-purple-500 text-white shadow-sm'
                  : 'bg-[#1e1f23] border-[#2e3035] text-[#8e918f] hover:text-white'
              )}
            >
              <PenTool size={13} />
              <span>២. របៀបសរសេរ Prompt</span>
            </button>

            <button
              type="button"
              onClick={() => {
                triggerLight();
                setActiveTab('chatting');
              }}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border',
                activeTab === 'chatting'
                  ? 'bg-purple-600 border-purple-500 text-white shadow-sm'
                  : 'bg-[#1e1f23] border-[#2e3035] text-[#8e918f] hover:text-white'
              )}
            >
              <MessageSquareText size={13} />
              <span>៣. ការសន្ទនាជាមួយ AI</span>
            </button>

            <button
              type="button"
              onClick={() => {
                triggerLight();
                setActiveTab('features');
              }}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border',
                activeTab === 'features'
                  ? 'bg-purple-600 border-purple-500 text-white shadow-sm'
                  : 'bg-[#1e1f23] border-[#2e3035] text-[#8e918f] hover:text-white'
              )}
            >
              <Sparkles size={13} />
              <span>៤. មុខងារពិសេសៗ</span>
            </button>
          </div>

          {/* Modal Content Area */}
          <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 text-xs sm:text-sm text-[#c4c7c5] leading-relaxed">
            {/* TAB 1: របៀបប្រើប្រាស់ */}
            {activeTab === 'usage' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-4 rounded-2xl bg-[#1e1f23] border border-[#2e3035] space-y-3">
                  <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
                    <Lightbulb size={16} />
                    <span>ជំហានចាប់ផ្តើមប្រើប្រាស់រហ័ស</span>
                  </div>
                  <ul className="space-y-2.5 text-xs text-[#a8abb0]">
                    <li className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-bold">1</span>
                      <span><strong>វាយសំណួរ ឬបញ្ជា៖</strong> បញ្ចូលសារ ឬសំណួររបស់អ្នកទៅក្នុងប្រអប់ខាងក្រោម រួចចុចប៊ូតុងផ្ញើ (Enter ឬប៊ូតុងព្រួញ)។</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-bold">2</span>
                      <span><strong>ជ្រើសរើសម៉ូឌែល AI៖</strong> ចុចលើប៊ូតុងឈ្មោះម៉ូឌែល (ឧ. Aroch 2.5 Flash) ដើម្បីប្តូរទៅកាន់ម៉ូឌែលសមស្របតាមតម្រូវការ។</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-bold">3</span>
                      <span><strong>បញ្ចូលរូបភាព ឬសំឡេង៖</strong> ចុចសញ្ញាបូក (+) ដើម្បីភ្ជាប់រូបភាព ស្កេនវិក្កយបត្រ ឬថតសំឡេងនិយាយផ្ទាល់។</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-bold">4</span>
                      <span><strong>គ្រប់គ្រងការសន្ទនា៖</strong> ចុចមីនុយបីចំណុច (...) ដើម្បី Rename, ខ្ទាស់ Pin Chat ឬចែករំលែក Share ការសន្ទនា។</span>
                    </li>
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-purple-950/20 border border-purple-500/30 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-xs font-semibold text-white">ត្រូវការបង្កើតប្រធានបទថ្មី?</p>
                    <p className="text-[11px] text-[#8e918f]">ចុចប៊ូតុង New Chat នៅផ្នែកខាងលើដើម្បីចាប់ផ្តើម</p>
                  </div>
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-medium cursor-pointer transition-colors"
                  >
                    ចាប់ផ្តើមឆាត
                  </button>
                </div>
              </div>
            )}

            {/* TAB 2: របៀបសរសេរ Prompt */}
            {activeTab === 'prompts' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-4 rounded-2xl bg-[#1e1f23] border border-[#2e3035] space-y-2">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <PenTool size={15} className="text-purple-400" />
                    <span>រូបមន្ត ៣ ចំណុចដើម្បីសរសេរ Prompt ឱ្យបានលទ្ធផលល្អបំផុត</span>
                  </h4>
                  <p className="text-xs text-[#a8abb0]">
                    AI នឹងឆ្លើយបានច្បាស់លាស់ និងចំគោលដៅបំផុត នៅពេលអ្នកផ្តល់ព័ត៌មានលម្អិត៖
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                    <div className="p-3 rounded-xl bg-[#141517] border border-[#28292c]">
                      <p className="font-bold text-purple-300 text-xs mb-1">១. តួនាទី (Role)</p>
                      <p className="text-[11px] text-[#8e918f]">ប្រាប់ AI ថាគាត់ត្រូវដើរតួជាអ្វី (ឧ. អ្នកជំនាញទីផ្សារ, គ្រូបង្រៀន, អ្នកសរសេរកូដ)</p>
                    </div>
                    <div className="p-3 rounded-xl bg-[#141517] border border-[#28292c]">
                      <p className="font-bold text-purple-300 text-xs mb-1">២. បរិបទ (Context)</p>
                      <p className="text-[11px] text-[#8e918f]">ប្រាប់ពីគោលបំណង ទស្សនិកជន និងព័ត៌មានលម្អិតនៃកិច្ចការរបស់អ្នក</p>
                    </div>
                    <div className="p-3 rounded-xl bg-[#141517] border border-[#28292c]">
                      <p className="font-bold text-purple-300 text-xs mb-1">៣. ទម្រង់ (Format)</p>
                      <p className="text-[11px] text-[#8e918f]">ស្នើសុំទម្រង់ឆ្លើយតបជាក់លាក់ (ឧ. ជាចំណុចៗ, ជាតារាង, ឬជាកូដ)</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2.5">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider text-[#8e918f]">
                    គំរូ Prompt ជាក់ស្តែងសម្រាប់សាកល្បង៖
                  </h4>
                  {promptExamples.map((ex, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-2xl bg-[#1a1b1f] border border-[#2e3035] hover:border-purple-500/40 transition-all space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{ex.title}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-medium">
                          {ex.category}
                        </span>
                      </div>
                      <p className="text-xs text-[#a8abb0] bg-[#141517] p-2.5 rounded-xl border border-[#28292c] font-mono select-all">
                        {ex.prompt}
                      </p>
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => handleCopyPrompt(ex.prompt, idx)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#28292a] hover:bg-[#343538] text-xs text-[#e3e3e3] cursor-pointer transition-colors"
                        >
                          {copiedPromptIndex === idx ? (
                            <>
                              <Check size={12} className="text-emerald-400" />
                              <span className="text-emerald-400 font-semibold">បានចម្លង!</span>
                            </>
                          ) : (
                            <>
                              <Copy size={12} />
                              <span>ចម្លង Prompt</span>
                            </>
                          )}
                        </button>
                        {onUsePrompt && (
                          <button
                            type="button"
                            onClick={() => handleUsePrompt(ex.prompt)}
                            className="flex items-center gap-1 px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white cursor-pointer transition-colors"
                          >
                            <span>យកទៅប្រើ</span>
                            <ChevronRight size={12} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: ការសន្ទនាជាមួយ AI */}
            {activeTab === 'chatting' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-4 rounded-2xl bg-[#1e1f23] border border-[#2e3035] space-y-3">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <MessageSquareText size={16} className="text-purple-400" />
                    <span>គន្លឹះក្នុងការជជែក និងសន្ទនាបន្ត</span>
                  </h4>
                  <div className="space-y-2.5 text-xs text-[#a8abb0]">
                    <div className="p-3 rounded-xl bg-[#141517] border border-[#28292c]">
                      <p className="font-bold text-white mb-1">១. ការសួរសំណួរបន្ត (Continuous Context)</p>
                      <p>Aroch AI ចងចាំបរិបទនៃការសន្ទនាខាងលើ ដូច្នេះអ្នកមិនចាំបាច់រៀបរាប់ដើមទងឡើងវិញទេ។ អ្នកគ្រាន់តែសួរដូចជា៖ <em>"សូមពន្យល់ចំណុចទី ២ បន្ថែម"</em> ឬ <em>"កែប្រែឱ្យខ្លីជាងនេះបន្តិច"</em>។</p>
                    </div>

                    <div className="p-3 rounded-xl bg-[#141517] border border-[#28292c]">
                      <p className="font-bold text-white mb-1">២. ការវាយតម្លៃចម្លើយ (👍 Like / 👎 Dislike)</p>
                      <p>នៅខាងក្រោមសារនីមួយៗរបស់ AI មានប៊ូតុងមេដៃឡើង (Like) និងមេដៃចុះ (Dislike)។ អ្នកអាចចុចដើម្បីផ្តល់មតិពេញចិត្ត ឬមិនពេញចិត្ត ដែលជួយឱ្យប្រព័ន្ធបង្កើនគុណភាពឆ្លើយតប។</p>
                    </div>

                    <div className="p-3 rounded-xl bg-[#141517] border border-[#28292c]">
                      <p className="font-bold text-white mb-1">៣. ការចម្លង (Copy) និងចែករំលែក (Share)</p>
                      <p>ចុចលើរូប Copy 📋 ក្រោមសារ ដើម្បីចម្លងអត្ថបទទាំងមូលយកទៅប្រើប្រាស់ភ្លាមៗ ឬចុចរូប Speaker 🔊 ដើម្បីឱ្យ AI អានជាសំឡេង។</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: មុខងារពិសេសៗ */}
            {activeTab === 'features' && (
              <div className="space-y-3 animate-in fade-in duration-150">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-2xl bg-[#1e1f23] border border-[#2e3035] space-y-1.5">
                    <div className="flex items-center gap-2 text-purple-300 font-bold text-xs">
                      <Cpu size={16} />
                      <span>ម៉ាស៊ីនឆ្លាតវៃ Aroch Multi-Core</span>
                    </div>
                    <p className="text-[11.5px] text-[#8e918f]">ដំណើរការដោយ Google Gemini ជំនាន់ចុងក្រោយ ឆ្លើយបានរហ័ស និងមានហេតុផលស៊ីជម្រៅ។</p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#1e1f23] border border-[#2e3035] space-y-1.5">
                    <div className="flex items-center gap-2 text-pink-300 font-bold text-xs">
                      <Sparkles size={16} />
                      <span>ភាសាខ្មែរសុទ្ធសាធ (Pure Khmer)</span>
                    </div>
                    <p className="text-[11.5px] text-[#8e918f]">យល់ច្បាស់ពីវប្បធម៌ខ្មែរ ប្រវត្តិសាស្ត្រ និងអក្ខរាវិរុទ្ធវេយ្យាករណ៍ខ្មែរត្រឹមត្រូវ ១០០%។</p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#1e1f23] border border-[#2e3035] space-y-1.5">
                    <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                      <FileSearch size={16} />
                      <span>ស្កេនរូបភាព & វិក្កយបត្រ (Vision OCR)</span>
                    </div>
                    <p className="text-[11.5px] text-[#8e918f]">វិភាគរូបភាព ឯកសារ និងផ្ទៀងផ្ទាត់ស្លីបធនាគារ (KHQR Bakong) ដោយស្វ័យប្រវត្តិ។</p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#1e1f23] border border-[#2e3035] space-y-1.5">
                    <div className="flex items-center gap-2 text-blue-300 font-bold text-xs">
                      <Volume2 size={16} />
                      <span>សំឡេង & ជំនួយការឆ្លាតវៃ (Speech)</span>
                    </div>
                    <p className="text-[11.5px] text-[#8e918f]">មុខងារថតសំឡេង និងការអានអត្ថបទឆ្លើយតបជាសំឡេង (Text-to-Speech) យ៉ាងរលូន។</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="p-4 border-t border-[#28292c] bg-[#141517] flex items-center justify-between">
            <span className="text-[11px] text-[#8e918f]">Aroch AI • ជំនួយការឆ្លាតវៃសម្រាប់កម្ពុជា</span>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-[#28292a] hover:bg-[#343538] text-xs font-semibold text-white transition-colors cursor-pointer"
            >
              យល់ព្រម
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
