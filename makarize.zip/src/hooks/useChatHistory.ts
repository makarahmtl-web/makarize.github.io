import { useState, useEffect, useCallback, useMemo } from 'react';
import { ChatSession, ChatMessage } from '../types';
import {
  subscribeToUserChatSessions,
  saveChatSessionToFirestore,
  deleteChatSessionFromFirestore,
  clearAllChatSessionsFromFirestore,
} from '../lib/firebase';

interface UseChatHistoryOptions {
  userId?: string;
  userEmail?: string;
  defaultModel?: string;
}

export interface UseChatHistoryReturn {
  sessions: ChatSession[];
  setSessions: React.Dispatch<React.SetStateAction<ChatSession[]>>;
  currentSessionId: string;
  currentSession: ChatSession;
  isLoading: boolean;
  error: Error | null;
  setCurrentSessionId: (id: string) => void;
  createNewSession: (initialModel?: string) => ChatSession;
  saveSession: (session: ChatSession) => Promise<void>;
  updateSessionMessages: (
    sessionId: string,
    messages: ChatMessage[],
    options?: { modelUsed?: string; title?: string }
  ) => Promise<void>;
  deleteSession: (sessionId: string) => Promise<void>;
  renameSession: (sessionId: string, newTitle: string) => Promise<void>;
  togglePinSession: (sessionId: string) => Promise<void>;
  clearAllSessions: () => Promise<void>;
}

export function useChatHistory({
  userId,
  userEmail = '',
  defaultModel = 'openai/gpt-4o',
}: UseChatHistoryOptions): UseChatHistoryReturn {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const storageKeySessions = useMemo(() => {
    return userEmail ? `makarize_chat_sessions_${userEmail}` : 'makarize_chat_sessions_guest';
  }, [userEmail]);

  const storageKeyActive = useMemo(() => {
    return userEmail ? `makarize_active_session_${userEmail}` : 'makarize_active_session_guest';
  }, [userEmail]);

  // Initial load from localStorage
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(storageKeySessions);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}

    const initialSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: defaultModel,
    };
    return [initialSession];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>(() => {
    try {
      const activeSaved = localStorage.getItem(storageKeyActive);
      if (activeSaved && sessions.some((s) => s.id === activeSaved)) {
        return activeSaved;
      }
    } catch {}
    return sessions[0]?.id || `session-${Date.now()}`;
  });

  // Keep active session ID saved to localStorage across reloads
  useEffect(() => {
    if (!currentSessionId) return;
    try {
      localStorage.setItem(storageKeyActive, currentSessionId);
    } catch {}
  }, [currentSessionId, storageKeyActive]);

  // Save local cache whenever sessions change
  useEffect(() => {
    try {
      localStorage.setItem(storageKeySessions, JSON.stringify(sessions));
    } catch (e) {
      console.warn('Failed to cache sessions locally:', e);
    }
  }, [sessions, storageKeySessions]);

  // Real-time Firestore Chat Sessions Subscription
  useEffect(() => {
    if (!userId || userId === 'guest') {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const unsubscribe = subscribeToUserChatSessions(
      userId,
      (cloudSessions) => {
        setIsLoading(false);
        setError(null);
        if (cloudSessions && cloudSessions.length > 0) {
          setSessions(cloudSessions);
          // Restore active session ID or keep current if valid
          setCurrentSessionId((prevId) => {
            if (cloudSessions.some((s) => s.id === prevId)) {
              return prevId;
            }
            const storedActive = localStorage.getItem(storageKeyActive);
            if (storedActive && cloudSessions.some((s) => s.id === storedActive)) {
              return storedActive;
            }
            return cloudSessions[0].id;
          });
        }
      },
      (err) => {
        setIsLoading(false);
        setError(err);
        console.warn('[useChatHistory] Firestore subscription error:', err);
      }
    );

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, [userId, storageKeyActive]);

  // Active session object helper
  const currentSession: ChatSession = useMemo(() => {
    const found = sessions.find((s) => s.id === currentSessionId);
    if (found) return found;
    if (sessions.length > 0) return sessions[0];
    return {
      id: `session-${Date.now()}`,
      title: 'New conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: defaultModel,
    };
  }, [sessions, currentSessionId, defaultModel]);

  // Save/Upsert a full session to local state + Firestore
  const saveSession = useCallback(
    async (session: ChatSession) => {
      if (!session || !session.id) return;

      const sessionWithTimestamp: ChatSession = {
        ...session,
        updatedAt: Date.now(),
        createdAt: session.createdAt || Date.now(),
        model: session.model || defaultModel,
      };

      setSessions((prev) => {
        const exists = prev.some((s) => s.id === session.id);
        if (exists) {
          return prev.map((s) => (s.id === session.id ? sessionWithTimestamp : s));
        }
        return [sessionWithTimestamp, ...prev];
      });

      if (userId && userId !== 'guest') {
        try {
          await saveChatSessionToFirestore(userId, userEmail, sessionWithTimestamp);
        } catch (err) {
          console.error('[useChatHistory] Error saving session to Firestore:', err);
        }
      }
    },
    [userId, userEmail, defaultModel]
  );

  // Update messages in a session
  const updateSessionMessages = useCallback(
    async (
      sessionId: string,
      messages: ChatMessage[],
      options?: { modelUsed?: string; title?: string }
    ) => {
      let updatedSession: ChatSession | undefined;

      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === sessionId) {
            let nextTitle = s.title;
            if (options?.title) {
              nextTitle = options.title;
            } else if ((!s.messages || s.messages.length === 0) && messages.length > 0) {
              const firstUser = messages.find((m) => m.role === 'user');
              if (firstUser?.text) {
                nextTitle = firstUser.text.slice(0, 36).trim() + (firstUser.text.length > 36 ? '...' : '');
              }
            }

            updatedSession = {
              ...s,
              title: nextTitle,
              model: options?.modelUsed || s.model || defaultModel,
              messages,
              updatedAt: Date.now(),
            };
            return updatedSession;
          }
          return s;
        })
      );

      if (updatedSession && userId && userId !== 'guest') {
        try {
          await saveChatSessionToFirestore(userId, userEmail, updatedSession);
        } catch (err) {
          console.error('[useChatHistory] Error updating session messages:', err);
        }
      }
    },
    [userId, userEmail, defaultModel]
  );

  // Create a brand new session
  const createNewSession = useCallback(
    (initialModel?: string): ChatSession => {
      const newSession: ChatSession = {
        id: `session-${Date.now()}`,
        title: 'New conversation',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
        model: initialModel || currentSession?.model || defaultModel,
      };

      setSessions((prev) => [newSession, ...prev]);
      setCurrentSessionId(newSession.id);

      if (userId && userId !== 'guest') {
        saveChatSessionToFirestore(userId, userEmail, newSession).catch(console.error);
      }

      return newSession;
    },
    [userId, userEmail, currentSession?.model, defaultModel]
  );

  // Delete a session
  const deleteSession = useCallback(
    async (sessionId: string) => {
      setSessions((prev) => {
        const filtered = prev.filter((s) => s.id !== sessionId);
        if (filtered.length === 0) {
          const fresh: ChatSession = {
            id: `session-${Date.now()}`,
            title: 'New conversation',
            createdAt: Date.now(),
            updatedAt: Date.now(),
            messages: [],
            model: defaultModel,
          };
          setCurrentSessionId(fresh.id);
          if (userId && userId !== 'guest') {
            saveChatSessionToFirestore(userId, userEmail, fresh).catch(console.error);
          }
          return [fresh];
        }
        if (currentSessionId === sessionId) {
          setCurrentSessionId(filtered[0].id);
        }
        return filtered;
      });

      if (userId && userId !== 'guest') {
        try {
          await deleteChatSessionFromFirestore(userId, sessionId);
        } catch (err) {
          console.error('[useChatHistory] Error deleting session:', err);
        }
      }
    },
    [userId, userEmail, currentSessionId, defaultModel]
  );

  // Rename a session
  const renameSession = useCallback(
    async (sessionId: string, newTitle: string) => {
      let updated: ChatSession | undefined;
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === sessionId) {
            updated = { ...s, title: newTitle, updatedAt: Date.now() };
            return updated;
          }
          return s;
        })
      );

      if (updated && userId && userId !== 'guest') {
        try {
          await saveChatSessionToFirestore(userId, userEmail, updated);
        } catch (err) {
          console.error('[useChatHistory] Error renaming session:', err);
        }
      }
    },
    [userId, userEmail]
  );

  // Toggle pin
  const togglePinSession = useCallback(
    async (sessionId: string) => {
      let updated: ChatSession | undefined;
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === sessionId) {
            updated = { ...s, isPinned: !s.isPinned, updatedAt: Date.now() };
            return updated;
          }
          return s;
        })
      );

      if (updated && userId && userId !== 'guest') {
        try {
          await saveChatSessionToFirestore(userId, userEmail, updated);
        } catch (err) {
          console.error('[useChatHistory] Error toggling pin:', err);
        }
      }
    },
    [userId, userEmail]
  );

  // Clear all sessions
  const clearAllSessions = useCallback(async () => {
    const fresh: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: defaultModel,
    };
    setSessions([fresh]);
    setCurrentSessionId(fresh.id);

    if (userId && userId !== 'guest') {
      try {
        await clearAllChatSessionsFromFirestore(userId);
        await saveChatSessionToFirestore(userId, userEmail, fresh);
      } catch (err) {
        console.error('[useChatHistory] Error clearing chat history:', err);
      }
    }
  }, [userId, userEmail, defaultModel]);

  return {
    sessions,
    setSessions,
    currentSessionId,
    currentSession,
    isLoading,
    error,
    setCurrentSessionId,
    createNewSession,
    saveSession,
    updateSessionMessages,
    deleteSession,
    renameSession,
    togglePinSession,
    clearAllSessions,
  };
}
