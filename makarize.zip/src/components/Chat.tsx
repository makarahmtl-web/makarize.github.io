import React, { useState, useRef, useEffect } from 'react';
import {
  Menu,
  FileCode,
  Sparkles,
  SquarePen,
  MoreVertical,
  CloudCheck,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import ChatInput from './ChatInput';
import Sidebar from './Sidebar';
import AttachmentBottomSheet from './AttachmentBottomSheet';
import MediaViewerBottomSheet from './MediaViewerBottomSheet';
import SettingsBottomSheet from './SettingsBottomSheet';
import ChatMenuBottomSheet from './ChatMenuBottomSheet';
import SlideStyleBottomSheet from './SlideStyleBottomSheet';
import MessageActions from './MessageActions';
import LegalPage from './LegalPage';
import DeleteAccountModal from './DeleteAccountModal';
import HelpModal from './HelpModal';
import FeedbackModal from './FeedbackModal';
import CodeBlock from './CodeBlock';
import {
  User,
  signOut,
  subscribeToUserChatSessions,
  saveChatSessionToFirestore,
  deleteChatSessionFromFirestore,
  clearAllChatSessionsFromFirestore,
  saveUserSettingsToFirestore,
} from '../lib/firebase';
import { ChatMessage, Attachment, ChatSession, AppSettings } from '../types';
import { useChatHistory } from '../hooks/useChatHistory';
import { cn } from '../lib/utils';
import { formatBytes } from '../lib/fileUtils';
import MakarizeLogo from './MakarizeLogo';
import AnimatedBackground from './AnimatedBackground';
import SuggestionChips from './SuggestionChips';
import PaidUpgradeModal from './PaidUpgradeModal';
import { applyTheme } from '../lib/theme';

const DEFAULT_SETTINGS: AppSettings = {
  language: 'km',
  colorMode: 'dark',
  backgroundMode: 'none',
  fontStyle: 'sans',
  voice: 'Puck',
  hapticFeedback: true,
  capabilities: {
    codeExecution: true,
    webBrowsing: true,
    imageGeneration: true,
    extendedReasoning: true,
  },
  connectors: {
    googleDrive: true,
    github: true,
    notion: false,
    figma: false,
  },
  permissions: {
    microphone: true,
    camera: true,
    clipboard: true,
    notifications: true,
  },
  focusDuration: 25,
  dataSharing: false,
};

const STORAGE_KEY_SETTINGS = 'makarize_app_settings_v2';

export default function Chat({ user, auth }: { user: User; auth: any }) {
  // Sidebar state
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentNav, setCurrentNav] = useState<'chats' | 'projects' | 'artifacts'>('chats');

  // Bottom Sheet States
  const [isAttachmentSheetOpen, setIsAttachmentSheetOpen] = useState(false);
  const [isSlideStyleSheetOpen, setIsSlideStyleSheetOpen] = useState(false);
  const [isSettingsSheetOpen, setIsSettingsSheetOpen] = useState(false);
  const [isViewerSheetOpen, setIsViewerSheetOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [isChatMenuOpen, setIsChatMenuOpen] = useState(false);
  const [activeViewerAttachment, setActiveViewerAttachment] = useState<Attachment | null>(null);
  const [activeViewerCode, setActiveViewerCode] = useState<{ code: string; language: string } | null>(null);
  const [insertedInputPrompt, setInsertedInputPrompt] = useState<string>('');
  const [legalPageTab, setLegalPageTab] = useState<'privacy' | 'terms' | null>(null);
  const [isDeleteAccountOpen, setIsDeleteAccountOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);

  // Active Pending Input Attachments
  const [pendingAttachments, setPendingAttachments] = useState<Attachment[]>([]);

  const userEmail = user?.email?.toLowerCase().trim() || 'guest';
  const userId = user?.uid || 'guest';

  // Settings State
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Chat history state via custom useChatHistory Firestore hook
  const {
    sessions,
    setSessions,
    currentSessionId,
    currentSession,
    setCurrentSessionId,
    createNewSession,
    saveSession,
    deleteSession,
    renameSession,
    togglePinSession,
    clearAllSessions,
  } = useChatHistory({
    userId,
    userEmail,
    defaultModel: 'openai/gpt-4o',
  });

  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const messages = currentSession ? currentSession.messages : [];

  // Persist settings
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch (e) {}

    if (userId && userId !== 'guest') {
      saveUserSettingsToFirestore(userId, settings).catch(() => {});
    }
  }, [settings, userId]);

  // Auto-scroll on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  const handleNewChat = () => {
    createNewSession(currentSession?.model || 'openai/gpt-4o');
    setCurrentNav('chats');
  };

  const handleShareConversation = () => {
    const chatText = (currentSession.messages || [])
      .map((m) => `${m.role.toUpperCase()}:\n${m.text}`)
      .join('\n\n');
    if (navigator.share) {
      navigator
        .share({
          title: currentSession.title,
          text: chatText,
        })
        .catch((err) => {
          if (err.name !== 'AbortError' && !err.message.includes('canceled') && !err.message.includes('cancelled')) {
            console.error('Share failed:', err);
          }
        });
    } else {
      navigator.clipboard.writeText(chatText).then(() => {
        alert('Conversation copied to clipboard for sharing!');
      });
    }
  };

  const handleTogglePin = (targetId?: string) => {
    togglePinSession(targetId || currentSessionId);
  };

  const handleAddToNotebook = () => {
    alert('Conversation added to Notebook!');
  };

  const handleRenameCurrentChat = () => {
    const newTitle = prompt('Enter new chat title:', currentSession.title);
    if (newTitle && newTitle.trim()) {
      renameSession(currentSessionId, newTitle.trim());
    }
  };

  const handleHelp = () => {
    setIsHelpModalOpen(true);
  };

  const handleFeedback = () => {
    setIsFeedbackModalOpen(true);
  };

  const handleDeleteCurrentChat = () => {
    deleteSession(currentSessionId);
  };

  const handleDeleteSession = (id: string) => {
    deleteSession(id);
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    renameSession(id, newTitle);
  };

  const handleClearAllHistory = () => {
    clearAllSessions();
  };

  const handleAddPendingAttachment = (att: Attachment) => {
    setPendingAttachments((prev) => [...prev, att]);
  };

  const handleRemovePendingAttachment = (id: string) => {
    setPendingAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleOpenViewerForAttachment = (att: Attachment) => {
    setActiveViewerAttachment(att);
    setActiveViewerCode(null);
    setIsViewerSheetOpen(true);
  };

  const handleOpenViewerForCode = (code: string, language: string) => {
    setActiveViewerCode({ code, language });
    setActiveViewerAttachment(null);
    setIsViewerSheetOpen(true);
  };

  // Direct Transcribe Action (from Audio Recording Bottom Sheet)
  const handleTranscribeDirect = (transcriptText: string, audioAttachment?: Attachment) => {
    const atts = audioAttachment ? [audioAttachment] : [];
    handleSend(transcriptText, atts, currentSession.model);
  };

  // Direct Vision Analysis Action (from Media Viewer Bottom Sheet)
  const handleAnalyzeWithVision = (attachment: Attachment) => {
    handleSend(
      'Please analyze this image in detail and describe its layout, objects, text, and key insights.',
      [attachment],
      currentSession.model
    );
  };

  const handleToggleLike = (msgId: string) => {
    const updatedMessages = (currentSession.messages || []).map((m) => {
      if (m.id === msgId) {
        return {
          ...m,
          liked: !m.liked,
          disliked: false,
        };
      }
      return m;
    });

    const updatedSession: ChatSession = {
      ...currentSession,
      messages: updatedMessages,
      updatedAt: Date.now(),
    };

    saveSession(updatedSession).catch(console.error);
  };

  const handleToggleDislike = (msgId: string) => {
    const updatedMessages = (currentSession.messages || []).map((m) => {
      if (m.id === msgId) {
        return {
          ...m,
          disliked: !m.disliked,
          liked: false,
        };
      }
      return m;
    });

    const updatedSession: ChatSession = {
      ...currentSession,
      messages: updatedMessages,
      updatedAt: Date.now(),
    };

    saveSession(updatedSession).catch(console.error);
  };

  const handleRetryMessage = (msgIndex: number) => {
    const sessionMsgs = currentSession?.messages || [];
    for (let i = msgIndex - 1; i >= 0; i--) {
      if (sessionMsgs[i].role === 'user' && sessionMsgs[i].text) {
        handleSend(sessionMsgs[i].text, sessionMsgs[i].attachments || [], currentSession.model);
        break;
      }
    }
  };

  const handleSend = async (text: string, attachments: Attachment[] = [], modelId?: string) => {
    const activeModel = modelId || currentSession.model || 'openai/gpt-4o';

    const newUserMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text,
      attachments: attachments.length > 0 ? attachments : undefined,
      timestamp: Date.now(),
    };

    // Auto-derive title
    let updatedTitle = currentSession.title;
    if ((!currentSession.messages || currentSession.messages.length === 0) && text) {
      updatedTitle = text.slice(0, 36).trim() + (text.length > 36 ? '...' : '');
    }

    const updatedSessionWithUser: ChatSession = {
      ...currentSession,
      title: updatedTitle,
      model: activeModel,
      updatedAt: Date.now(),
      messages: [...(currentSession.messages || []), newUserMsg],
    };

    // Save user message immediately
    saveSession(updatedSessionWithUser).catch(console.error);

    // Clear pending attachments
    setPendingAttachments([]);
    setLoading(true);

    try {
      const payloadMessages = (currentSession.messages || [])
        .map((m) => ({
          role: m.role,
          parts: [{ text: m.text }],
        }))
        .concat({
          role: 'user',
          parts: text ? [{ text }] : [],
        });

      // Check if we have user-provided keys for the provider
      let userKeys = {};
      try {
        const storedKeys = localStorage.getItem('makarize_user_api_keys');
        if (storedKeys) {
          userKeys = JSON.parse(storedKeys);
        }
      } catch (err) {
        console.warn('Could not parse user_api_keys from local storage:', err);
      }

      let response: Response;
      const fetchPayload = {
        messages: payloadMessages,
        model: activeModel,
        attachments: attachments.map((a) => ({
          data: a.data,
          mimeType: a.mimeType || a.type,
          name: a.name,
        })),
        userKeys,
      };

      try {
        response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fetchPayload),
        });
      } catch (networkErr: any) {
        // Automatic retry after 600ms on transient network disconnect
        console.warn('Network issue during chat fetch, retrying...', networkErr);
        await new Promise((resolve) => setTimeout(resolve, 600));
        response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fetchPayload),
        });
      }

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with status ${response.status}`);
      }

      if (!response.body) throw new Error('No streaming body in response');

      const asstMsgId = (Date.now() + 1).toString();
      let accumulatedAssistantText = '';

      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSessionId
            ? {
                ...s,
                messages: [
                  ...s.messages,
                  { id: asstMsgId, role: 'assistant', text: '', timestamp: Date.now() },
                ],
              }
            : s
        )
      );

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let done = false;
      let sseBuffer = '';

      while (!done) {
        const { value, done: doneReading } = await reader.read();
        done = doneReading;
        if (value) {
          sseBuffer += decoder.decode(value, { stream: true });
          const lines = sseBuffer.split('\n');
          // Keep the last partial line in the buffer
          sseBuffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data: ')) {
              const dataStr = trimmed.slice(6).trim();
              if (dataStr === '[DONE]') {
                done = true;
                break;
              }
              try {
                const data = JSON.parse(dataStr);
                if (data.error) {
                  accumulatedAssistantText += (accumulatedAssistantText ? '\n\n' : '') + `⚠️ ${data.error}`;
                } else if (data.text) {
                  accumulatedAssistantText += data.text;
                } else if (data.choices && data.choices.length > 0) {
                  const delta = data.choices[0].delta;
                  const content = delta?.content || data.choices[0].text || delta?.text || '';
                  if (content) accumulatedAssistantText += content;
                }

                setSessions((prev) =>
                  prev.map((s) =>
                    s.id === currentSessionId
                      ? {
                          ...s,
                          messages: s.messages.map((m) =>
                            m.id === asstMsgId ? { ...m, text: accumulatedAssistantText } : m
                          ),
                        }
                      : s
                  )
                );
              } catch (e) {}
            }
          }
        }
      }

      // Final save to Firestore with full assistant response
      const finalSession: ChatSession = {
        ...updatedSessionWithUser,
        updatedAt: Date.now(),
        messages: [
          ...updatedSessionWithUser.messages,
          { id: asstMsgId, role: 'assistant', text: accumulatedAssistantText, timestamp: Date.now() },
        ],
      };
      saveSession(finalSession).catch(console.error);
    } catch (error: any) {
      console.error('Chat error:', error);
      const errMsg = (error.message || '').toLowerCase();
      if (
        errMsg.includes('quota') ||
        errMsg.includes('rate limit') ||
        errMsg.includes('429') ||
        errMsg.includes('locked')
      ) {
        setIsUpgradeModalOpen(true);
      } else {
        const fallbackMsg: ChatMessage = {
          id: (Date.now() + 2).toString(),
          role: 'assistant',
          text: `⚠️ **បញ្ហាការតភ្ជាប់បណ្តាញ**: ${error.message || 'មិនអាចតភ្ជាប់ទៅកាន់ម៉ាស៊ីនបម្រើបាន'}\n\nសូមពិនិត្យមើលការតភ្ជាប់អ៊ីនធឺណិត ឬ API Key នៅក្នុងផ្ទាំង Settings ឬជ្រើសរើសម៉ូដែលផ្សេងទៀត។`,
          timestamp: Date.now(),
        };
        const errorSession: ChatSession = {
          ...updatedSessionWithUser,
          updatedAt: Date.now(),
          messages: [...updatedSessionWithUser.messages.filter((m) => m.text !== ''), fallbackMsg],
        };
        saveSession(errorSession).catch(console.error);
      }
    } finally {
      setLoading(false);
    }
  };

  const getThemeClass = () => {
    switch (settings.colorMode) {
      case 'purple':
        return 'bg-[#120822] text-[#f3e8ff]';
      case 'midnight':
        return 'bg-[#0b0f19] text-[#e2e8f0]';
      case 'light':
        return 'bg-[#f8f9fa] text-[#202124]';
      default:
        return 'bg-[#131314] text-[#e3e3e3]';
    }
  };

  const getFontFamily = () => {
    switch (settings.fontStyle) {
      case 'serif':
        return 'font-serif';
      case 'mono':
        return 'font-mono';
      case 'modern':
        return 'font-sans tracking-wide';
      default:
        return 'font-sans';
    }
  };

  return (
    <div
      className={cn(
        'flex h-screen w-screen overflow-hidden transition-colors duration-200',
        getThemeClass(),
        getFontFamily()
      )}
    >
      <AnimatedBackground mode={settings.backgroundMode || 'none'} />
      {/* Collapsible Left Sidebar with Cloud Sync & Search */}
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        onTogglePinSession={handleTogglePin}
        onClearAllHistory={handleClearAllHistory}
        user={user}
        onOpenSettings={() => setIsSettingsSheetOpen(true)}
        currentNav={currentNav}
        onNavChange={setCurrentNav}
        language={settings.language}
      />

      {/* Main Chat Interface */}
      <div className="relative flex flex-1 flex-col h-full overflow-hidden">
        {/* Top App Header */}
        <header className="flex h-14 items-center justify-between px-4 sm:px-6 border-b border-[#28292a] bg-inherit z-10">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-full hover:bg-[#28292a] text-[#8e918f] hover:text-[#e3e3e3] transition-colors cursor-pointer"
              title="Toggle sidebar"
            >
              <Menu size={20} />
            </button>

            {/* Brand Logo & Name */}
            <div
              onClick={() => setIsSettingsSheetOpen(true)}
              className="flex items-center gap-2.5 px-3 py-1.5 rounded-full hover:bg-[#28292a] cursor-pointer group transition-colors"
            >
              <MakarizeLogo size={24} />
              <span className="text-lg font-bold tracking-tight text-[#e3e3e3]">Makarize</span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* New Chat Pencil Icon Button */}
            <button
              type="button"
              onClick={handleNewChat}
              className="flex items-center justify-center p-2 rounded-full text-[#8e918f] hover:text-[#e3e3e3] hover:bg-[#28292a] active:scale-95 transition-all cursor-pointer"
              title="Start New Chat"
            >
              <SquarePen size={20} />
            </button>
            {/* Three Dot Menu Button */}
            <button
              type="button"
              onClick={() => setIsChatMenuOpen(true)}
              className="flex items-center justify-center p-2 rounded-full text-[#8e918f] hover:text-[#e3e3e3] hover:bg-[#28292a] active:scale-95 transition-all cursor-pointer"
              title="More options"
            >
              <MoreVertical size={20} />
            </button>
          </div>
        </header>

        {/* Chat Message Scrollable Container */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6">
          <div className="mx-auto max-w-3xl">
            {messages.length === 0 ? (
              <div className="flex flex-col justify-center pt-10 pb-6 px-1 sm:px-4">
                <div className="welcome-container mb-6">
                  <h1 className="welcome-title text-[30px] sm:text-[36px] font-semibold mb-2 leading-tight">
                    Hello, <span className="user-name">{user.displayName?.split(' ')[0] || user.email?.split('@')[0] || 'Makara'}</span>
                  </h1>
                  <p className="welcome-subtitle text-[20px] sm:text-[24px] text-[#8e8ea0] font-normal leading-normal">
                    Where should we start?
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-6">
                {messages.map((msg, msgIndex) => (
                  <div
                    key={msg.id}
                    className={cn(
                      'flex gap-3 sm:gap-4',
                      msg.role === 'user' ? 'justify-end' : 'justify-start'
                    )}
                  >
                    {/* Bot Avatar Icon */}
                    {msg.role === 'assistant' && (
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#28292a] border border-[#9333ea]/40 shadow-md p-1 mt-1">
                        <MakarizeLogo size={22} />
                      </div>
                    )}

                    <div
                      className={cn(
                        'flex flex-col max-w-[88%]',
                        msg.role === 'user' ? 'items-end' : 'items-start'
                      )}
                    >
                      {/* Attached Items within Message Bubble */}
                      {msg.attachments && msg.attachments.length > 0 && (
                        <div className="mb-2.5 flex flex-wrap gap-2">
                          {msg.attachments.map((att) => {
                            const isImg =
                              att.type?.startsWith('image/') ||
                              att.mimeType?.startsWith('image/') ||
                              att.previewUrl?.startsWith('data:image/');
                            return (
                              <div
                                key={att.id}
                                onClick={() => handleOpenViewerForAttachment(att)}
                                className="flex items-center gap-2 rounded-2xl border border-[#3c4043] bg-[#1e1f20] p-2 pr-3 text-xs shadow-sm cursor-pointer hover:border-[#9333ea] transition-all"
                              >
                                {isImg ? (
                                  <img
                                    src={att.previewUrl || `data:${att.mimeType || att.type};base64,${att.data}`}
                                    alt={att.name}
                                    className="h-10 w-10 rounded-xl object-cover"
                                  />
                                ) : (
                                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#28292a] text-[#a855f7]">
                                    <FileCode size={18} />
                                  </div>
                                )}
                                <div className="flex flex-col">
                                  <span className="truncate max-w-[150px] font-semibold text-[#e3e3e3]">
                                    {att.name}
                                  </span>
                                  <span className="text-[10px] text-[#8e918f]">
                                    {formatBytes(att.size)} • Click to inspect
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Text Content */}
                      {msg.text && (
                        <div
                          className={cn(
                            'rounded-3xl px-6 py-4 text-[15.3px] leading-[1.45]',
                            msg.role === 'user'
                              ? 'bg-[#28292a] text-[#e3e3e3] border border-[#3c4043]'
                              : 'prose prose-invert max-w-none bg-transparent w-full'
                          )}
                        >
                          {msg.role === 'user' ? (
                            <p className="whitespace-pre-wrap text-[15.3px] leading-[1.45]">{msg.text}</p>
                          ) : (
                            <div className="markdown-body">
                              <ReactMarkdown
                                remarkPlugins={[remarkGfm]}
                                components={{
                                  code({ node, inline, className, children, ...props }: any) {
                                    const match = /language-(\w+)/.exec(className || '');
                                    const codeContent = String(children).replace(/\n$/, '');

                                    if (!inline && match) {
                                      return (
                                        <CodeBlock
                                          language={match[1]}
                                          code={codeContent}
                                          onOpenInViewer={handleOpenViewerForCode}
                                        />
                                      );
                                    }
                                    return (
                                      <code className={className} {...props}>
                                        {children}
                                      </code>
                                    );
                                  },
                                }}
                              >
                                {msg.text}
                              </ReactMarkdown>
                            </div>
                          )}
                          {msg.role === 'assistant' && !loading && (
                            <SuggestionChips text={msg.text} onSelect={(prompt) => handleSend(prompt)} />
                          )}
                        </div>
                      )}

                      {/* AI-Generated Message Action Toolbar (Like, Copy, Read Aloud, Share, Retry) */}
                      {msg.role === 'assistant' && msg.text && (
                        <MessageActions
                          message={msg}
                          onToggleLike={handleToggleLike}
                          onToggleDislike={handleToggleDislike}
                          onRetry={() => handleRetryMessage(msgIndex)}
                        />
                      )}
                    </div>
                  </div>
                ))}

                {/* Loading indicator */}
                {loading && (
                  <div className="ai-loading-container">
                    {/* 1. Logo AI ខាងឆ្វេង */}
                    <div className="ai-logo">
                      <MakarizeLogo size={22} />
                    </div>

                    {/* 2. ប្រអប់គ្រាប់លោត ៣ គ្រាប់ (គ្មានអក្សរ) */}
                    <div className="bouncing-dots-bubble">
                      <span className="dot" />
                      <span className="dot" />
                      <span className="dot" />
                    </div>
                  </div>
                )}

                <div ref={bottomRef} />
              </div>
            )}
          </div>
        </div>

        {/* Bottom-Anchored Chat Input Area */}
        <div className="mx-auto w-full max-w-3xl px-4 sm:px-8 pb-4 pt-2">
          <ChatInput
            onSend={(text, atts, model) => handleSend(text, atts, model)}
            onOpenAttachmentSheet={() => setIsAttachmentSheetOpen(true)}
            onOpenVoiceSheet={() => setIsAttachmentSheetOpen(true)}
            onOpenSlideStyleSheet={() => setIsSlideStyleSheetOpen(true)}
            onViewAttachment={handleOpenViewerForAttachment}
            attachments={pendingAttachments}
            onRemoveAttachment={handleRemovePendingAttachment}
            disabled={loading}
            selectedModel={currentSession?.model}
            language={settings.language}
            user={user}
            insertedText={insertedInputPrompt}
            onInsertedTextConsumed={() => setInsertedInputPrompt('')}
            onModelChange={(newModel) => {
              setSessions((prev) =>
                prev.map((s) => {
                  if (s.id === currentSessionId) {
                    const updated = { ...s, model: newModel, updatedAt: Date.now() };
                    if (userId && userId !== 'guest') {
                      saveChatSessionToFirestore(userId, updated).catch(console.error);
                    }
                    return updated;
                  }
                  return s;
                })
              );
            }}
          />
        </div>
      </div>

      {/* 1. SLIDE-UP ATTACHMENT BOTTOM SHEET (Voice, Audio, Camera, Photos, Docs) */}
      <AttachmentBottomSheet
        isOpen={isAttachmentSheetOpen}
        onClose={() => setIsAttachmentSheetOpen(false)}
        onAddAttachment={handleAddPendingAttachment}
        onTranscribeDirect={handleTranscribeDirect}
      />

      {/* 2. SLIDE-UP SLIDE STYLES & PRESENTATION BOTTOM SHEET */}
      <SlideStyleBottomSheet
        isOpen={isSlideStyleSheetOpen}
        onClose={() => setIsSlideStyleSheetOpen(false)}
        onApplyStyle={(promptText, autoSend) => {
          if (autoSend) {
            handleSend(promptText, []);
          } else {
            setInsertedInputPrompt(promptText);
          }
        }}
      />

      {/* 3. SLIDE-UP MEDIA & CODE VIEWER BOTTOM SHEET */}
      <MediaViewerBottomSheet
        isOpen={isViewerSheetOpen}
        onClose={() => setIsViewerSheetOpen(false)}
        attachment={activeViewerAttachment}
        codeSnippet={activeViewerCode}
        onAnalyzeWithVision={handleAnalyzeWithVision}
      />

      {/* 4. SLIDE-UP SETTINGS & PREFERENCES BOTTOM SHEET */}
      <SettingsBottomSheet
        isOpen={isSettingsSheetOpen}
        onClose={() => setIsSettingsSheetOpen(false)}
        user={user}
        onSignOut={handleSignOut}
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
        onClearHistory={handleClearAllHistory}
        onOpenLegal={(tab) => setLegalPageTab(tab)}
        onOpenDeleteAccount={() => setIsDeleteAccountOpen(true)}
      />

      {/* 5. UPGRADE MODAL */}
      <PaidUpgradeModal
        isOpen={isUpgradeModalOpen}
        onClose={() => setIsUpgradeModalOpen(false)}
        onUnlock={() => {
          setIsUpgradeModalOpen(false);
          setIsSettingsSheetOpen(true);
        }}
        onFallback={() => {
          setIsUpgradeModalOpen(false);
        }}
      />

      {/* 6. SLIDE-UP CHAT MENU BOTTOM SHEET */}
      <ChatMenuBottomSheet
        isOpen={isChatMenuOpen}
        onClose={() => setIsChatMenuOpen(false)}
        isPinned={!!currentSession.isPinned}
        onTogglePin={() => handleTogglePin(currentSessionId)}
        onRename={handleRenameCurrentChat}
        onDelete={handleDeleteCurrentChat}
        onShare={handleShareConversation}
        onAddToNotebook={handleAddToNotebook}
        onHelp={handleHelp}
        onFeedback={handleFeedback}
        onOpenLegal={(tab) => setLegalPageTab(tab)}
      />

      {/* 7. FULLSCREEN LEGAL PAGE MODAL (Privacy Policy & Terms of Service) */}
      {legalPageTab && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-[#0f1013] animate-in fade-in duration-200">
          <LegalPage
            initialTab={legalPageTab}
            onBack={() => setLegalPageTab(null)}
            isModal={true}
          />
        </div>
      )}

      {/* 8. GOOGLE PLAY COMPLIANT DELETE ACCOUNT MODAL */}
      <DeleteAccountModal
        isOpen={isDeleteAccountOpen}
        onClose={() => setIsDeleteAccountOpen(false)}
        user={user}
        language={settings.language === 'en' ? 'en' : 'km'}
        onAccountDeleted={() => {
          setIsDeleteAccountOpen(false);
          setIsSettingsSheetOpen(false);
          window.location.reload();
        }}
      />

      {/* 9. INTERACTIVE HELP & AI GUIDE MODAL */}
      <HelpModal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
        onUsePrompt={(promptText) => {
          setInsertedInputPrompt(promptText);
        }}
      />

      {/* 10. FEEDBACK & RATING MODAL */}
      <FeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={() => setIsFeedbackModalOpen(false)}
        userEmail={userEmail}
      />
    </div>
  );
}

