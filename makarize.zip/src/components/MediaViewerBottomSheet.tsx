import React, { useState } from 'react';
import {
  FileText,
  Image as ImageIcon,
  Mic,
  Video,
  Download,
  Copy,
  Check,
  Sparkles,
  ExternalLink,
  Loader2,
  Trash2,
} from 'lucide-react';
import BottomSheet from './BottomSheet';
import CodeBlock from './CodeBlock';
import { FileAttachment } from '../types';
import { formatBytes } from '../lib/fileUtils';

interface MediaViewerBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  attachment: FileAttachment | null;
  codeSnippet?: { code: string; language: string } | null;
  onAnalyzeWithVision?: (attachment: FileAttachment) => void;
}

export default function MediaViewerBottomSheet({
  isOpen,
  onClose,
  attachment,
  codeSnippet,
  onAnalyzeWithVision,
}: MediaViewerBottomSheetProps) {
  const [copied, setCopied] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  if (!isOpen) return null;

  const isImage =
    attachment?.type.startsWith('image/') ||
    attachment?.previewUrl?.startsWith('data:image/');
  const isAudio = attachment?.type.startsWith('audio/');
  const isVideo = attachment?.type.startsWith('video/');

  const handleCopyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  const handleDownload = () => {
    if (!attachment) return;
    const a = document.createElement('a');
    a.href = attachment.previewUrl || `data:${attachment.type};base64,${attachment.data}`;
    a.download = attachment.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleVisionAnalysis = async () => {
    if (!attachment || !onAnalyzeWithVision) return;
    setIsAnalyzing(true);
    onAnalyzeWithVision(attachment);
    setIsAnalyzing(false);
    onClose();
  };

  // If viewing a standalone code snippet
  if (codeSnippet) {
    return (
      <BottomSheet
        isOpen={isOpen}
        onClose={onClose}
        title="Code Inspector"
        subtitle={`Language: ${codeSnippet.language}`}
        icon={<FileText size={20} />}
        maxHeight="max-h-[90vh]"
      >
        <div className="py-2">
          <CodeBlock language={codeSnippet.language} code={codeSnippet.code} />
        </div>
      </BottomSheet>
    );
  }

  if (!attachment) return null;

  return (
    <BottomSheet
      isOpen={isOpen}
      onClose={onClose}
      title={attachment.name}
      subtitle={`${attachment.type} • ${formatBytes(attachment.size)}`}
      icon={
        isImage ? (
          <ImageIcon size={20} />
        ) : isAudio ? (
          <Mic size={20} />
        ) : isVideo ? (
          <Video size={20} />
        ) : (
          <FileText size={20} />
        )
      }
      maxHeight="max-h-[90vh]"
      footer={
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-1.5 rounded-xl border border-[#3c4043] bg-[#28292a] px-4 py-2.5 text-xs font-medium text-[#e3e3e3] hover:bg-[#333537]"
          >
            <Download size={14} />
            <span>Download</span>
          </button>

          {isImage && onAnalyzeWithVision && (
            <button
              type="button"
              disabled={isAnalyzing}
              onClick={handleVisionAnalysis}
              className="flex items-center gap-2 rounded-xl bg-[#9333ea] px-5 py-2.5 text-xs font-semibold text-white shadow-md hover:bg-[#7e22ce] transition-all disabled:opacity-50"
            >
              {isAnalyzing ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Sparkles size={14} />
              )}
              <span>Analyze with Multimodal Vision</span>
            </button>
          )}
        </div>
      }
    >
      <div className="flex flex-col items-center justify-center py-4 text-center">
        {/* Render Image */}
        {isImage && (
          <div className="flex flex-col items-center gap-3">
            <img
              src={attachment.previewUrl || `data:${attachment.type};base64,${attachment.data}`}
              alt={attachment.name}
              className="max-h-[50vh] w-auto max-w-full rounded-2xl border border-[#3c4043] object-contain shadow-xl"
            />
          </div>
        )}

        {/* Render Audio */}
        {isAudio && (
          <div className="w-full max-w-md rounded-2xl border border-[#3c4043] bg-[#18191a] p-6 shadow-xl flex flex-col items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#9333ea]/20 text-[#c084fc] border border-[#9333ea]/30">
              <Mic size={32} />
            </div>
            <div className="w-full">
              <audio
                controls
                src={attachment.previewUrl || `data:${attachment.type};base64,${attachment.data}`}
                className="w-full"
              />
            </div>
          </div>
        )}

        {/* Render Video */}
        {isVideo && (
          <div className="w-full max-w-lg rounded-2xl border border-[#3c4043] overflow-hidden bg-black shadow-xl">
            <video
              controls
              src={attachment.previewUrl || `data:${attachment.type};base64,${attachment.data}`}
              className="w-full max-h-[50vh]"
            />
          </div>
        )}

        {/* Render Document or Decoded Text */}
        {!isImage && !isAudio && !isVideo && (
          <div className="w-full rounded-2xl border border-[#3c4043] bg-[#18191a] p-5 text-left shadow-xl">
            <div className="mb-3 flex items-center justify-between border-b border-[#28292a] pb-2 text-xs text-[#8e918f]">
              <span className="font-semibold text-[#e3e3e3]">File Content / Text</span>
              <button
                type="button"
                onClick={() => {
                  try {
                    const text = atob(attachment.data);
                    handleCopyText(text);
                  } catch {
                    handleCopyText(attachment.data);
                  }
                }}
                className="flex items-center gap-1 text-[11px] text-[#a855f7] hover:underline"
              >
                {copied ? <Check size={12} /> : <Copy size={12} />}
                <span>{copied ? 'Copied' : 'Copy file text'}</span>
              </button>
            </div>

            <pre className="max-h-60 overflow-y-auto font-mono text-xs text-[#c4c7c5] whitespace-pre-wrap">
              {(() => {
                try {
                  return atob(attachment.data);
                } catch {
                  return 'Binary file payload attached.';
                }
              })()}
            </pre>
          </div>
        )}
      </div>
    </BottomSheet>
  );
}
