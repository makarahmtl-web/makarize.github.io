import { FileTypeCategory } from '../types';

export function formatBytes(bytes: number, decimals = 1): string {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

export function getFileCategory(file: File): FileTypeCategory {
  const mime = file.type.toLowerCase();
  const name = file.name.toLowerCase();

  if (mime.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp|svg|bmp|ico|avif)$/i.test(name)) {
    return 'image';
  }
  if (mime.startsWith('video/') || /\.(mp4|webm|mov|mkv|avi|m4v)$/i.test(name)) {
    return 'video';
  }
  if (mime.startsWith('audio/') || /\.(mp3|wav|ogg|m4a|aac|webm|flac)$/i.test(name)) {
    return 'audio';
  }
  if (mime === 'application/pdf' || name.endsWith('.pdf')) {
    return 'pdf';
  }
  if (
    /\.(js|jsx|ts|tsx|html|css|json|py|rs|go|cpp|c|java|sql|sh|yaml|yml|xml|env)$/i.test(name) ||
    mime === 'application/json' ||
    mime === 'text/javascript' ||
    mime === 'application/xml'
  ) {
    return 'code';
  }
  if (
    mime.startsWith('text/') ||
    /\.(doc|docx|txt|rtf|csv|md|markdown|ppt|pptx|xls|xlsx)$/i.test(name)
  ) {
    return 'document';
  }
  return 'other';
}

export function getFileExtension(filename: string): string {
  const parts = filename.split('.');
  if (parts.length > 1) {
    return parts.pop()?.toUpperCase() || 'FILE';
  }
  return 'FILE';
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      let result = reader.result as string;
      if (result.includes(',')) {
        result = result.split(',')[1];
      }
      resolve(result);
    };
    reader.onerror = error => reject(error);
  });
}
