import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlertTriangle,
  Trash2,
  X,
  ShieldAlert,
  CheckCircle2,
  Database,
  MessageSquareX,
  KeyRound,
  Mail,
  Loader2,
} from 'lucide-react';
import { User, deleteUserAccountAndData, signInWithPopup, initFirebase } from '../lib/firebase';
import { useHaptic } from '../lib/useHaptic';

interface DeleteAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  language?: 'en' | 'km';
  onAccountDeleted?: () => void;
}

export default function DeleteAccountModal({
  isOpen,
  onClose,
  user,
  language = 'km',
  onAccountDeleted,
}: DeleteAccountModalProps) {
  const isKhmer = language === 'km';
  const { triggerWarning, triggerSuccess, triggerLight } = useHaptic();

  const [confirmText, setConfirmText] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [needsReauth, setNeedsReauth] = useState(false);

  if (!isOpen) return null;

  const targetKeyword = isKhmer ? 'DELETE' : 'DELETE';
  const isConfirmValid =
    (confirmText.trim().toUpperCase() === targetKeyword || confirmText.trim() === 'លុប') && agreedToTerms;

  const handleDelete = async () => {
    if (!isConfirmValid || isDeleting) return;

    triggerWarning();
    setIsDeleting(true);
    setErrorMsg(null);

    try {
      const result = await deleteUserAccountAndData(user);

      if (result.success) {
        triggerSuccess();
        if (onAccountDeleted) {
          onAccountDeleted();
        } else {
          window.location.reload();
        }
      } else if (result.requiresReauth) {
        setNeedsReauth(true);
        setErrorMsg(
          isKhmer
            ? 'Google តម្រូវឱ្យផ្ទៀងផ្ទាត់ឡើងវិញមុននឹងលុបគណនី។ សូមចុចប៊ូតុងខាងក្រោមដើម្បី Login ម្តងទៀត រួចបន្តការលុប។'
            : 'Google requires recent authentication before account deletion. Please re-authenticate below to proceed.'
        );
      } else {
        setErrorMsg(result.error || 'Failed to delete account. Please try again or contact support.');
      }
    } catch (err: any) {
      console.error('Delete account failed:', err);
      if (err?.code === 'auth/requires-recent-login') {
        setNeedsReauth(true);
        setErrorMsg(
          isKhmer
            ? 'Google តម្រូវឱ្យផ្ទៀងផ្ទាត់ឡើងវិញមុននឹងលុបគណនី។ សូមចុចប៊ូតុងខាងក្រោមដើម្បី Login ម្តងទៀត រួចបន្តការលុប។'
            : 'Google requires recent authentication before account deletion. Please re-authenticate below to proceed.'
        );
      } else {
        setErrorMsg(err.message || 'An error occurred during account deletion.');
      }
    } finally {
      setIsDeleting(false);
    }
  };

  const handleReauthAndRetry = async () => {
    try {
      setIsDeleting(true);
      setErrorMsg(null);
      const { auth, provider } = await initFirebase();
      await signInWithPopup(auth, provider);
      setNeedsReauth(false);
      // Retry deletion
      if (auth.currentUser) {
        const result = await deleteUserAccountAndData(auth.currentUser);
        if (result.success) {
          triggerSuccess();
          if (onAccountDeleted) onAccountDeleted();
          else window.location.reload();
        }
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Re-authentication failed.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-red-500/30 bg-[#16171a] shadow-2xl text-[#e3e3e3]"
        >
          {/* Header Accent */}
          <div className="bg-gradient-to-r from-red-600/20 via-red-500/10 to-transparent p-5 sm:p-6 border-b border-red-500/20 flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-red-500/20 text-red-400 border border-red-500/30">
                <AlertTriangle size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  {isKhmer ? 'លុបគណនី និងទិន្នន័យ (Delete Account)' : 'Delete Account & Data'}
                </h3>
                <p className="text-xs text-red-300/80">
                  {isKhmer ? 'Google Play Data Safety & User Rights Compliance' : 'Permanent Account Deletion'}
                </p>
              </div>
            </div>
            <button
              type="button"
              id="btn-close-delete-modal"
              onClick={() => {
                triggerLight();
                onClose();
              }}
              disabled={isDeleting}
              className="rounded-full p-2 text-[#8e918f] hover:bg-[#28292a] hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Body Content */}
          <div className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
            {/* Warning Banner */}
            <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-xs leading-relaxed text-red-200 flex items-start gap-3">
              <ShieldAlert size={18} className="shrink-0 text-red-400 mt-0.5" />
              <div>
                <span className="font-bold block mb-0.5 text-red-300">
                  {isKhmer ? '⚠️ សកម្មភាពនេះមិនអាចត្រឡប់ក្រោយវិញបានទេ' : '⚠️ This action is permanent and irreversible'}
                </span>
                {isKhmer
                  ? 'នៅពេលអ្នកបញ្ជាក់ការលុប គណនីរបស់អ្នកនឹងត្រូវបានលុបចេញពីប្រព័ន្ធទាំងស្រុង។ រាល់ទិន្នន័យទាំងអស់ខាងក្រោមនឹងត្រូវបានលុបជាអចិន្ត្រៃយ៍ភ្លាមៗពី Google Firestore Database និង Firebase Authentication៖'
                  : 'Once confirmed, your account and all associated data will be immediately and permanently erased from our Google Firestore Database and Firebase Authentication servers:'}
              </div>
            </div>

            {/* List of Data To Be Erased */}
            <div className="rounded-2xl border border-[#2e3035] bg-[#111215] p-3.5 space-y-2.5 text-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#8e918f] block">
                {isKhmer ? 'ទិន្នន័យដែលនឹងត្រូវបានលុបបំបាត់ (Data to be purged):' : 'Data to be purged:'}
              </span>

              <div className="flex items-center gap-2.5 text-[#c4c7c5]">
                <MessageSquareX size={15} className="text-red-400 shrink-0" />
                <span>
                  {isKhmer
                    ? 'ប្រវត្តិសារសន្ទនា (Chat Sessions) និងឯកសារ Attachments ទាំងអស់'
                    : 'All chat histories, prompt logs, and uploaded files/attachments'}
                </span>
              </div>

              <div className="flex items-center gap-2.5 text-[#c4c7c5]">
                <KeyRound size={15} className="text-red-400 shrink-0" />
                <span>
                  {isKhmer
                    ? 'ការកំណត់គណនី (Settings), Custom API Keys, និង Theme Preferences'
                    : 'User preferences, custom API credentials, and theme customizations'}
                </span>
              </div>

              <div className="flex items-center gap-2.5 text-[#c4c7c5]">
                <Database size={15} className="text-red-400 shrink-0" />
                <span>
                  {isKhmer
                    ? 'កំណត់ត្រាការដោះសោ AI Models (Model unlocks) និង Cache ទិន្នន័យក្នុង Browser'
                    : 'Unlocked model records, saved tokens, and local cache storage'}
                </span>
              </div>
            </div>

            {/* User Account Info */}
            <div className="rounded-2xl border border-[#2e3035] bg-[#18191a] p-3 text-xs flex items-center justify-between">
              <span className="text-[#8e918f]">{isKhmer ? 'គណនីដែលត្រូវលុប:' : 'Account to delete:'}</span>
              <span className="font-semibold text-white truncate max-w-[220px]">
                {user.email || user.displayName || user.uid}
              </span>
            </div>

            {/* Error Message if any */}
            {errorMsg && (
              <div className="rounded-2xl border border-red-500/50 bg-red-950/40 p-3.5 text-xs text-red-200">
                <p className="font-semibold">{errorMsg}</p>
                {needsReauth && (
                  <button
                    type="button"
                    onClick={handleReauthAndRetry}
                    className="mt-2.5 w-full rounded-xl bg-white px-4 py-2 font-semibold text-black hover:bg-[#f1f3f4] transition-all cursor-pointer"
                  >
                    {isKhmer ? 'Login ផ្ទៀងផ្ទាត់ជាមួយ Google ម្តងទៀត' : 'Re-authenticate with Google'}
                  </button>
                )}
              </div>
            )}

            {/* Confirmation Checkbox */}
            <label className="flex items-start gap-3 rounded-2xl border border-[#2e3035] bg-[#111215] p-3.5 text-xs text-[#c4c7c5] cursor-pointer hover:border-red-500/40 transition-colors">
              <input
                type="checkbox"
                id="checkbox-confirm-delete"
                checked={agreedToTerms}
                onChange={(e) => setAgreedToTerms(e.target.checked)}
                disabled={isDeleting}
                className="mt-0.5 h-4 w-4 rounded border-[#3c4043] bg-[#1f2023] text-red-600 accent-red-600 focus:ring-0 cursor-pointer"
              />
              <span>
                {isKhmer
                  ? 'ខ្ញុំបានយល់ច្បាស់ថា ទិន្នន័យទាំងអស់របស់ខ្ញុំនឹងត្រូវបានលុបជាស្ថាពរ ហើយមិនអាចសង្គ្រោះឡើងវិញបានទេ។'
                  : 'I understand that this action is irreversible and all my data will be permanently wiped.'}
              </span>
            </label>

            {/* Confirmation Word Input */}
            <div className="space-y-1.5">
              <label className="text-xs text-[#8e918f] block">
                {isKhmer
                  ? `ដើម្បីបញ្ជាក់ សូមវាយពាក្យថា `
                  : `To confirm, please type `}
                <span className="font-bold text-red-400">DELETE</span>
                {isKhmer ? ' ក្នុងប្រអប់ខាងក្រោម៖' : ' in the box below:'}
              </label>
              <input
                type="text"
                id="input-confirm-delete-account"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="DELETE"
                disabled={isDeleting}
                className="w-full rounded-xl border border-[#3c4043] bg-[#111215] px-3.5 py-2.5 text-sm text-white placeholder-[#5e6165] focus:border-red-500 focus:outline-none focus:ring-1 focus:ring-red-500"
              />
            </div>

            {/* Offline Deletion Notice (Play Store Requirement) */}
            <div className="pt-2 border-t border-[#2e3035] flex items-center justify-between text-[11px] text-[#8e918f]">
              <span className="flex items-center gap-1">
                <Mail size={12} className="text-purple-400" />
                <span>Web / Email Request:</span>
              </span>
              <a href="mailto:ChhuoyMakara@gmail.com?subject=Account%20Deletion%20Request" className="text-purple-400 hover:underline">
                ChhuoyMakara@gmail.com
              </a>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="p-5 sm:p-6 bg-[#111215] border-t border-[#2e3035] flex items-center justify-end gap-3">
            <button
              type="button"
              id="btn-cancel-delete-account"
              onClick={() => {
                triggerLight();
                onClose();
              }}
              disabled={isDeleting}
              className="rounded-xl border border-[#3c4043] bg-[#1f2023] px-4 py-2.5 text-xs font-semibold text-[#e3e3e3] hover:bg-[#28292a] transition-all cursor-pointer"
            >
              {isKhmer ? 'បោះបង់ (Cancel)' : 'Cancel'}
            </button>

            <button
              type="button"
              id="btn-confirm-delete-account"
              onClick={handleDelete}
              disabled={!isConfirmValid || isDeleting}
              className="flex items-center gap-2 rounded-xl bg-red-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-red-700 disabled:opacity-40 disabled:hover:bg-red-600 transition-all shadow-lg shadow-red-600/20 cursor-pointer"
            >
              {isDeleting ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>{isKhmer ? 'កំពុងលុបទិន្នន័យ...' : 'Deleting...'}</span>
                </>
              ) : (
                <>
                  <Trash2 size={14} />
                  <span>{isKhmer ? 'លុបគណនីជាស្ថាពរ (Delete Account)' : 'Delete Permanently'}</span>
                </>
              )}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
