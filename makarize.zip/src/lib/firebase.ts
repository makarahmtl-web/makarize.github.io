import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, deleteUser, User } from 'firebase/auth';
import {
  getFirestore,
  initializeFirestore,
  doc,
  setDoc,
  getDoc,
  getDocFromServer,
  collection,
  addDoc,
  deleteDoc,
  query,
  where,
  getDocs,
  onSnapshot,
  serverTimestamp,
  writeBatch,
} from 'firebase/firestore';
import { ChatSession } from '../types';
import staticFirebaseConfig from '../../firebase-applet-config.json';

let app: any;
let auth: ReturnType<typeof getAuth>;
let provider: GoogleAuthProvider;
let db: ReturnType<typeof getFirestore>;
let initPromise: Promise<{ auth: ReturnType<typeof getAuth>; provider: GoogleAuthProvider; db: ReturnType<typeof getFirestore> }> | null = null;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMessage = error instanceof Error ? error.message : String(error);
  const errInfo = {
    error: errMessage,
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
    },
    operationType,
    path,
  };
  if (errMessage.includes('unavailable') || errMessage.includes('the client is offline')) {
    console.warn('Firestore offline/reconnecting:', errMessage);
  } else {
    console.error('Firestore Error: ', JSON.stringify(errInfo));
  }
  return errInfo;
}

function getOrInitializeDb(firebaseApp: any, databaseId?: string) {
  if (db) return db;
  try {
    db = initializeFirestore(
      firebaseApp,
      {
        experimentalForceLongPolling: true,
        ignoreUndefinedProperties: true,
      },
      databaseId || undefined
    );
  } catch {
    try {
      db = databaseId ? getFirestore(firebaseApp, databaseId) : getFirestore(firebaseApp);
    } catch {
      db = getFirestore(firebaseApp);
    }
  }
  return db;
}

export const initFirebase = async () => {
  if (initPromise) return initPromise;

  initPromise = (async () => {
    let config: any = staticFirebaseConfig;
    try {
      const response = await fetch('/api/firebase-config');
      if (response.ok) {
        config = await response.json();
      }
    } catch {
      // Fallback to staticFirebaseConfig
    }

    if (!getApps().length) {
      app = initializeApp(config);
    } else {
      app = getApp();
    }

    auth = getAuth(app);
    provider = new GoogleAuthProvider();
    db = getOrInitializeDb(app, config.firestoreDatabaseId);

    // Optional connection check
    try {
      getDocFromServer(doc(db, 'test', 'connection')).catch(() => {});
    } catch {}

    return { auth, provider, db };
  })();

  return initPromise;
};

// -------------------------------------------------------------
// CHAT SESSIONS PERSISTENCE IN FIRESTORE (USER DATA ISOLATION)
// Path: users/{userId}/chats/{chatId}
// -------------------------------------------------------------

/**
 * Real-time subscription to user's chat sessions from Firestore
 * Uses isolated path: users/{userId}/chats
 */
export const subscribeToUserChatSessions = (
  userId: string,
  onUpdate: (sessions: ChatSession[]) => void,
  onError?: (err: any) => void
) => {
  if (!userId) return () => {};

  let isUnsubscribed = false;
  let unsubscribeFirestore: (() => void) | null = null;

  initFirebase().then(({ db: firestoreDb }) => {
    if (isUnsubscribed || !firestoreDb) return;

    try {
      // User-Isolated Sub-collection: users/{userId}/chats
      const userChatsRef = collection(firestoreDb, 'users', userId, 'chats');

      unsubscribeFirestore = onSnapshot(
        userChatsRef,
        async (snapshot) => {
          const sessions: ChatSession[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            sessions.push({
              id: data.id || docSnap.id,
              title: data.title || 'New conversation',
              createdAt: data.createdAt || Date.now(),
              updatedAt: data.updatedAt || Date.now(),
              messages: Array.isArray(data.messages) ? data.messages : [],
              model: data.model || 'gemini-2.5-flash',
              isPinned: Boolean(data.isPinned),
            });
          });

          // If no isolated chats yet, check for any legacy chat_sessions to auto-migrate seamlessly
          if (sessions.length === 0) {
            try {
              const legacyQuery = query(collection(firestoreDb, 'chat_sessions'), where('userId', '==', userId));
              const legacySnap = await getDocs(legacyQuery);
              if (!legacySnap.empty) {
                legacySnap.forEach((docSnap) => {
                  const data = docSnap.data();
                  const legacySession: ChatSession = {
                    id: data.id || docSnap.id,
                    title: data.title || 'New conversation',
                    createdAt: data.createdAt || Date.now(),
                    updatedAt: data.updatedAt || Date.now(),
                    messages: Array.isArray(data.messages) ? data.messages : [],
                    model: data.model || 'gemini-2.5-flash',
                    isPinned: Boolean(data.isPinned),
                  };
                  sessions.push(legacySession);
                  // Auto-save to new isolated path
                  saveChatSessionToFirestore(userId, legacySession);
                });
              }
            } catch (legacyErr) {
              console.warn('Legacy chat migration notice:', legacyErr);
            }
          }

          // Sort by updatedAt descending
          sessions.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
          onUpdate(sessions);
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, `users/${userId}/chats`);
          if (onError) onError(error);
        }
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, `users/${userId}/chats`);
      if (onError) onError(error);
    }
  });

  return () => {
    isUnsubscribed = true;
    if (unsubscribeFirestore) unsubscribeFirestore();
  };
};

/**
 * Save or update a single chat session in Firestore under users/{userId}/chats/{chatId}
 */
export const saveChatSessionToFirestore = async (
  userId: string,
  sessionOrEmail: any,
  sessionParam?: any
) => {
  if (!userId) return;
  const session: ChatSession = sessionParam && typeof sessionParam === 'object' ? sessionParam : sessionOrEmail;
  const userEmail = typeof sessionOrEmail === 'string' ? sessionOrEmail : '';

  if (!session?.id) return;
  try {
    const { db: firestoreDb } = await initFirebase();
    if (!firestoreDb) return;

    // Sanitize messages so no raw undefined values break Firestore serializer
    const cleanMessages = (session.messages || []).map((m) => ({
      id: m.id || Date.now().toString(),
      role: m.role || 'user',
      text: m.text || '',
      timestamp: m.timestamp || Date.now(),
      attachments: (m.attachments || []).map((a) => ({
        id: a.id,
        name: a.name,
        size: a.size,
        mimeType: a.mimeType || a.type || 'application/octet-stream',
        data: a.data ? a.data.slice(0, 100000) : '',
      })),
    }));

    // Save to isolated subcollection: users/{userId}/chats/{sessionId}
    const sessionDocRef = doc(firestoreDb, 'users', userId, 'chats', session.id);
    await setDoc(
      sessionDocRef,
      {
        id: session.id,
        userId,
        userEmail: userEmail || '',
        title: session.title || 'New conversation',
        createdAt: session.createdAt || Date.now(),
        updatedAt: session.updatedAt || Date.now(),
        messages: cleanMessages,
        model: session.model || 'gemini-2.5-flash',
        isPinned: Boolean(session.isPinned),
        syncedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${userId}/chats/${session?.id || 'unknown'}`);
  }
};

/**
 * Delete a chat session from Firestore under users/{userId}/chats/{sessionId}
 */
export const deleteChatSessionFromFirestore = async (userId: string, sessionId: string) => {
  if (!userId || !sessionId) return;
  try {
    const { db: firestoreDb } = await initFirebase();
    if (!firestoreDb) return;
    
    // Delete from isolated collection
    const sessionDocRef = doc(firestoreDb, 'users', userId, 'chats', sessionId);
    await deleteDoc(sessionDocRef);

    // Also remove from legacy collection if present
    try {
      await deleteDoc(doc(firestoreDb, 'chat_sessions', sessionId));
    } catch {}
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `users/${userId}/chats/${sessionId}`);
  }
};

/**
 * Clear all chat sessions for a user in Firestore (users/{userId}/chats)
 */
export const clearAllChatSessionsFromFirestore = async (userId: string) => {
  if (!userId) return;
  try {
    const { db: firestoreDb } = await initFirebase();
    if (!firestoreDb) return;

    const userChatsRef = collection(firestoreDb, 'users', userId, 'chats');
    const snapshot = await getDocs(userChatsRef);

    const batch = writeBatch(firestoreDb);
    snapshot.forEach((docSnap) => {
      batch.delete(docSnap.ref);
    });
    await batch.commit();

    // Clean legacy chat_sessions if any
    try {
      const legacyQuery = query(collection(firestoreDb, 'chat_sessions'), where('userId', '==', userId));
      const legacySnap = await getDocs(legacyQuery);
      if (!legacySnap.empty) {
        const legacyBatch = writeBatch(firestoreDb);
        legacySnap.forEach((docSnap) => {
          legacyBatch.delete(docSnap.ref);
        });
        await legacyBatch.commit();
      }
    } catch {}
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `users/${userId}/chats`);
  }
};

// -------------------------------------------------------------
// USER API KEYS & UNLOCKS PERSISTENCE
// -------------------------------------------------------------

export const saveUserSettingsToFirestore = async (userId: string, settings: any) => {
  if (!userId) return;
  try {
    const { db: firestoreDb } = await initFirebase();
    if (!firestoreDb) return;

    await setDoc(
      doc(firestoreDb, 'user_settings', userId),
      {
        userId,
        ...settings,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `user_settings/${userId}`);
  }
};

export const fetchUserSettingsFromFirestore = async (userId: string): Promise<any | null> => {
  if (!userId) return null;
  try {
    const { db: firestoreDb } = await initFirebase();
    if (!firestoreDb) return null;

    const docSnap = await getDoc(doc(firestoreDb, 'user_settings', userId));
    if (docSnap.exists()) {
      return docSnap.data();
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `user_settings/${userId}`);
  }
  return null;
};

export const fetchUserUnlocksFromFirebase = async (userId: string, userEmail?: string): Promise<string[]> => {
  try {
    const { db: firestoreDb } = await initFirebase();
    if (!firestoreDb || !userId) return [];

    const userDocRef = doc(firestoreDb, 'user_unlocks', userId);
    const docSnap = await getDoc(userDocRef);
    if (docSnap.exists()) {
      const data = docSnap.data();
      return data?.unlockedModels || [];
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `user_unlocks/${userId}`);
  }
  return [];
};

export const savePaymentRecordToFirebase = async (record: {
  userId?: string;
  userEmail?: string;
  userName?: string;
  modelId: string;
  modelName: string;
  amountUSD: string;
  amountKHR: string;
  accountNumber: string;
  accountName: string;
  txnId?: string;
  unlockedAt: number;
}) => {
  try {
    const { db: firestoreDb } = await initFirebase();
    if (firestoreDb) {
      await addDoc(collection(firestoreDb, 'khqr_payments'), {
        ...record,
        timestamp: serverTimestamp(),
      });
      if (record.userId) {
        let existingUnlocks: string[] = [];
        try {
          const docSnap = await getDoc(doc(firestoreDb, 'user_unlocks', record.userId));
          if (docSnap.exists()) {
            existingUnlocks = docSnap.data()?.unlockedModels || [];
          }
        } catch (e) {}

        const updatedUnlocks = Array.from(new Set([...existingUnlocks, record.modelId]));
        await setDoc(
          doc(firestoreDb, 'user_unlocks', record.userId),
          {
            userId: record.userId,
            userEmail: record.userEmail,
            unlockedModels: updatedUnlocks,
            updatedAt: serverTimestamp(),
          },
          { merge: true }
        );
      }
    }
  } catch (err) {
    console.warn('Firebase sync notice:', err);
  }
};

/**
 * Permanently deletes user account and all associated Firestore data (Google Play compliant)
 */
export const deleteUserAccountAndData = async (user: User): Promise<{ success: boolean; requiresReauth?: boolean; error?: string }> => {
  if (!user || !user.uid) {
    return { success: false, error: 'No active user session' };
  }
  const userId = user.uid;

  // 1. Delete all Firestore records first (chats, settings, unlocks)
  try {
    const { db: firestoreDb } = await initFirebase();
    if (firestoreDb) {
      // 1a. Delete all user chat sessions (isolated and legacy)
      try {
        const userChatsRef = collection(firestoreDb, 'users', userId, 'chats');
        const userChatsSnap = await getDocs(userChatsRef);
        const batch = writeBatch(firestoreDb);
        userChatsSnap.forEach((docSnap) => {
          batch.delete(docSnap.ref);
        });
        await batch.commit();

        const sessionsRef = collection(firestoreDb, 'chat_sessions');
        const q = query(sessionsRef, where('userId', '==', userId));
        const snapshot = await getDocs(q);
        const legacyBatch = writeBatch(firestoreDb);
        snapshot.forEach((docSnap) => {
          legacyBatch.delete(docSnap.ref);
        });
        await legacyBatch.commit();
      } catch (err) {
        console.warn('Notice deleting chat sessions during account deletion:', err);
      }

      // 1b. Delete user settings
      try {
        await deleteDoc(doc(firestoreDb, 'user_settings', userId));
      } catch (err) {
        console.warn('Notice deleting user settings during account deletion:', err);
      }

      // 1c. Delete user unlocks
      try {
        await deleteDoc(doc(firestoreDb, 'user_unlocks', userId));
      } catch (err) {
        console.warn('Notice deleting user unlocks during account deletion:', err);
      }
    }
  } catch (err) {
    console.error('Firestore cleanup failed during account deletion:', err);
  }

  // 2. Clear all local cache & stored tokens
  try {
    localStorage.clear();
    sessionStorage.clear();
  } catch (e) {}

  // 3. Delete Firebase Authentication User account
  try {
    await deleteUser(user);
    return { success: true };
  } catch (authError: any) {
    console.warn('Auth deletion notice:', authError);
    if (authError?.code === 'auth/requires-recent-login') {
      return { success: false, requiresReauth: true, error: 'Re-authentication required by Google before deleting account.' };
    }
    // If other error, sign out to close session
    try {
      await signOut(auth);
    } catch (e) {}
    return { success: true };
  }
};

export { signInWithPopup, signOut, onAuthStateChanged, deleteUser, getFirestore };
export type { User };


