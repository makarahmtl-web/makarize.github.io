export type MessageRole = 'user' | 'assistant';

export type FileTypeCategory = 'image' | 'video' | 'audio' | 'pdf' | 'document' | 'code' | 'other';

export interface Attachment {
  id: string;
  name: string;
  size: number;
  data: string; // base64
  mimeType: string;
  type?: string;
  previewUrl?: string;
  typeCategory?: FileTypeCategory;
  duration?: string;
  file?: File;
}

export type FileAttachment = Attachment;

export interface ChatMessage {
  id: string;
  role: MessageRole;
  text: string;
  attachments?: Attachment[];
  timestamp?: number;
  liked?: boolean;
  disliked?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  model: string;
  isPinned?: boolean;
}

export interface ModelOption {
  id: string;
  name: string;
  tagline: string;
  badge?: string;
  category?: string;
  provider?: string;
  isThinking?: boolean;
  isPremium?: boolean;
  price?: string;
  isFree?: boolean;
  isLocked?: boolean;
  description?: string;
}

export interface AppSettings {
  language?: string;
  colorMode: 'dark' | 'midnight' | 'purple' | 'light' | 'system';
  backgroundMode: 'none' | 'rain' | 'snow' | 'matrix' | 'shooting-stars' | 'orbs' | 'aurora' | 'sunset';
  fontStyle: 'sans' | 'serif' | 'mono' | 'modern';
  voice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Aoede';
  hapticFeedback: boolean;
  capabilities: {
    codeExecution: boolean;
    webBrowsing: boolean;
    imageGeneration: boolean;
    extendedReasoning: boolean;
  };
  connectors: {
    googleDrive: boolean;
    github: boolean;
    notion: boolean;
    figma: boolean;
  };
  permissions: {
    microphone: boolean;
    camera: boolean;
    clipboard: boolean;
    notifications: boolean;
  };
  focusDuration: number;
  dataSharing: boolean;
}
